# GIBSON Chapter 10/13/14 cumulative validation

## Source of truth

The authoritative base for this build is the user-supplied `GIBSON-MAINFRAME-CH10-ZERT-SMF-PATCHED(1).zip` (SHA-256 `91e3363cd71653e89fffc89836e6c597e7803478e139410f4944e4dc61c67e48`).

Chapter 13 and Chapter 14 changes were merged into that code tree at source-code level. The later Markdown/TXT narrative files were not used as implementation truth.

## Chapter 10 validation

The authoritative Chapter 10 code already contained the JES2/NJE command model, PAYROLL.MASTER, TRANSMIT, NJE protocol interoperability, live SMF evidence, and the RACF/Z4CK persistence lab. The cumulative build additionally makes the direct `xeq_execute()` lab helper reproduce the read-only IKJEFT01 LISTUSER and BPXBATCH `SH id` examples used in the chapter.

Validated examples include:

- `$D NODE(HAL)` -> HAL plus `AUTH=(JOB=YES,NET=YES,DEVICE=NO,SYSTEM=NO)`
- `$D NJEDEF,NODENUM` -> `NODENUM=3`
- `$T NJEDEF,NODENUM=5`
- `$T NODE(5),NAME=H4CKR`
- `$ADD SOCKET(H4CKR),NODE=H4CKR,IPADDR=192.168.0.20`
- `$T NODE(H4CKR),AUTH=(DEVICE=YES,JOB=YES,NET=YES,SYSTEM=YES)`
- `TRANSMIT HAL.HACKER DATASET('PAYROLL.MASTER')`
- cross-node IKJEFT01 `LISTUSER` training output for RUARIV
- cross-node BPXBATCH `SH id` training output
- RACF/Z4CK NJE persistence chain and correlated SMF evidence (covered by existing Chapter 10 acceptance tests)

## Chapter 13 additions

- zERT profile/reference members and exact SYNTAXCHECK/OBEYFILE workflow
- active/inactive TCP/IP profile locations
- SMFPRM00 locations
- IKJTSO00 logon controls and activation
- CICS startup/security location and CEMT verification
- z/OS Connect server.xml training reference
- APF persistent/runtime distinction
- console definitions
- RRSF reference members
- APPL01 PTKTDATA review profile seeded for the book command
- DB2T.BATCH/DIST/SASS/REST DSNR review profiles seeded for the book commands

## Chapter 14 additions

- CICS monitoring settings and `CEMT INQUIRE MONITOR`
- Db2 `SMFSTAT`, `SMFACCT`, `AUDITST`, `-DISPLAY ZPARM`, and `-DISPLAY TRACE(*)`
- ICSF startup/reference path (`ICSF=00`, `ICSFPROC=CSF`, CSF PROC, CSFPRM00)
- `D ICSF,KDS`
- physically discoverable placeholder `SYS1.CKDS`, `SYS1.PKDS`, and `SYS1.TKDS` datasets containing no key material
- `PAYROLL.DATAKEY` CSFKEYS profile
- APISRV certificate metadata
- PWCONVERT training behavior
- SMF 82 subtype 49 on simulated master-key promotion
- fixed console routing so `F ICSF,REFRESH,TKDS` updates the ICSF state rather than being swallowed by the generic MODIFY handler

## Test results

Focused cumulative Chapter 10/13/14 acceptance and related subsystem tests:

`49 passed, 21 warnings in 4.89s`

A new `tests/test_ch10_13_14_cumulative_acceptance.py` adds exact book-facing checks for the merged build.

Python bytecode compilation completed cleanly with `python -m compileall -q gibson`.

The complete repository test suite was also started. It is too large for the execution window, but all failures encountered before timeout were independently reproduced in the untouched authoritative Chapter 10 source and are therefore pre-existing, not regressions introduced by this merge. Confirmed pre-existing failures include:

- `tests/lang/test_rexx_hostsvc.py::test_signal_on_error`
- `tests/test_book_enhancements.py::test_book_network_racf_apf_rexx_smoke`
- `tests/test_disconnect_and_audit_realism.py::test_smf80_panel_browse_shows_detailed_security_fields`

## Remaining intentional or external gaps

1. GIBSON ICSF remains a simulated control/evidence plane; it does not contain real HSM/CCA/EP11 key material or perform production dataset encryption.
2. TKE workstation/key-part ceremonies are conceptual; TKE workstation audit subtype 29 and PCI-coprocessor subtype 16 are not fully simulated. Subtype 49 master-key promotion is simulated.
3. Dataset catalog KEYLABEL/DSKEYLBL metadata is not yet modeled as a full LISTCAT ALL training display.
4. The external NJElib `iNJEctor.py`, `jcl.py`, and nmap NSE scripts are not bundled. Byte-level NJElib interoperability tests pass, and GIBSON's internal NJE/JES execution path produces the expected commands/results. The TCP NJE SYSOUT reply remains a minimal completion stream rather than a complete remote JES spool transport.
5. CICS monitoring and Db2 trace displays are intentionally compact training models, not complete subsystem implementations.
6. The z/OS Connect `server.xml` file is a discoverable training reference; the Python API simulator does not use Liberty `server.xml` as its runtime configuration.
7. The Chapter 10 manuscript itself contains a small narrative mismatch: the displayed `$D NJEDEF,NODENUM` example shows 3, while nearby prose says the response was 4. The authoritative GIBSON seed and command output are 3 before the chapter changes it to 5.
