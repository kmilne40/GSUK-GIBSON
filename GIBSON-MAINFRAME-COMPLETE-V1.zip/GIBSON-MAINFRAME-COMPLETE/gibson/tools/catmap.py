"""CATMAP - walk the catalog and map the datasets the caller can access.

GIBSON re-implementation of CATMAP by Phil Young (Soldier of Fortran),
https://github.com/mainframed/CATMAP (GPL-3.0).

The real tool walks the master catalog and every connected user catalog - the
REXX version with LISTCAT/LISTDSI, the HLASM versions (CATMAP3/CATMAP3J/
CATMAP3N) through the Catalog Search Interface IGGCSI00 - and issues
``RACROUTE REQUEST=AUTH,STATUS=ACCESS`` against every non-VSAM dataset to
report the *access the caller holds*.  Assembling the HLASM variants or running
the REXX against a live catalog needs a real z/OS, so GIBSON models the same
result against its simulated catalog and RACF: for the running user it lists
each catalogued dataset with the access level that user holds - NONE, READ,
UPDATE, CONTROL, ALTER, or NOTPROT for a dataset with no covering profile.

The point of the tool is the ACCESS column: it turns "what datasets exist?"
into "which datasets can *I* actually reach, and how far?" in a single pass.

Authorised GIBSON training use only.  No real catalog or security database is
read or modified.
"""
from __future__ import annotations

import re

_MASTER_CATALOG = "CATALOG.MASTER.GIBSON"

# RACROUTE STATUS=ACCESS return-order, low to high (matches racf_dynamic).
_ORDER = ["NONE", "READ", "UPDATE", "CONTROL", "ALTER"]

_HELP = """\
 CATMAP - walk the catalog and map the datasets you can access
 GIBSON re-implementation of CATMAP by Soldier of Fortran
 https://github.com/mainframed/CATMAP

 Usage (from the READY prompt):
   CATMAP              map the datasets your user can access
   CATMAP -all         also list datasets you have NO access to
   CATMAP -h           this help

 The ACCESS column reports the access your user holds for each dataset:
   NONE READ UPDATE CONTROL ALTER   - the RACF access level, or
   NOTPROT                          - the dataset has no covering profile

 Authorised GIBSON training use only."""


def _args(command: str) -> str:
    """Return the operand string from a bare command or an EX 'hlq.CATMAP' call.

    Real TSO passes the *contents* of a quoted operand to a program/exec, so
    ``EX 'RUARIV.CATMAP' '-all'`` gives ``-all`` and ``CATMAP -all`` gives the
    same.  ``CALL 'hlq.LOAD(CATMAP3)' '-all'`` is handled the same way.
    """
    cmd = (command or "").strip()
    up = cmd.upper()
    quoted = re.findall(r"'([^']*)'", cmd)
    if up.startswith(("EX ", "EXEC ", "CALL ")):
        if quoted:
            # quoted form: EX 'hlq.CATMAP' '-all' -> last operand is the args;
            # a single quoted operand (the exec/program name) means no args.
            return quoted[-1].strip() if len(quoted) >= 2 else ""
        # unquoted form: EX CATMAP -all -> drop the verb and the member name.
        toks = cmd.split()
        return " ".join(toks[2:]).strip() if len(toks) > 2 else ""
    if up.startswith("%"):
        # %CATMAP -all
        rest = cmd[1:].split(None, 1)
        return rest[1].strip() if len(rest) > 1 else ""
    # bare "CATMAP ...": everything after the verb
    parts = cmd.split(None, 1)
    return parts[1].strip() if len(parts) > 1 else ""


def _catalogued_datasets(state) -> list[tuple[str, str]]:
    """(dataset, volser) pairs from the simulated catalog, de-duplicated.

    Sources, first volume wins:
      1. the system datasets in DatasetCatalog.SYSTEM_DATASETS (with VOLUME);
      2. discrete (non-generic) RACF DATASET profiles, which carry a volume and
         name datasets that may not have a catalog stub of their own.
    """
    cat = state.datasets
    dr = state.dynamic_racf
    seen: dict[str, str] = {}
    for dsn, spec in getattr(cat, "SYSTEM_DATASETS", {}).items():
        vol = (spec or {}).get("VOLUME") or "WORK01"
        seen.setdefault(dsn.upper(), vol)
    for pname, prof in dr.profiles.get("DATASET", {}).items():
        if any(ch in pname for ch in "*%"):
            continue  # generic profile, not a dataset name
        seen.setdefault(pname.upper(), (getattr(prof, "volume", None) or "WORK01"))
    return sorted(seen.items())


def _access_for(state, userid: str, dsn: str) -> str:
    """The caller's access token for one dataset (RACROUTE STATUS=ACCESS)."""
    dr = state.dynamic_racf
    dec = dr.access_decision("DATASET", dsn, userid, "READ", state.racf)
    if dec.profile is None:
        # No covering RACF profile: RACROUTE reports the dataset as not
        # protected.  CATMAP prints NOTPROT for these.
        return "NOTPROT"
    return (dec.effective or "NONE").upper()


def catmap(state, userid: str, command: str = "CATMAP") -> str:
    userid = (userid or "").upper()
    arg = _args(command)
    au = arg.upper()
    if re.search(r"(^|\s)-?(-)?H(ELP)?(\s|$)", au) or "-?" in au or au.strip() == "?":
        return _HELP

    show_all = bool(re.search(r"(^|\s)-?(-)?(ALL|A|VERBOSE|V)(\s|$)", au))

    rows = []
    reachable = 0
    total = 0
    for dsn, vol in _catalogued_datasets(state):
        total += 1
        access = _access_for(state, userid, dsn)
        accessible = access != "NONE"
        if accessible:
            reachable += 1
        if accessible or show_all:
            rows.append((access, vol, dsn))

    # Sort most-privileged first so ALTER/CONTROL float to the top, then by name;
    # NOTPROT (unprotected) is listed after the graded levels.
    def _rank(access: str) -> int:
        if access in _ORDER:
            return -_ORDER.index(access)   # ALTER(-4) .. NONE(0)
        return 1                            # NOTPROT after NONE-graded set
    rows.sort(key=lambda r: (_rank(r[0]), r[2]))

    out = []
    out.append(f" CATMAP - walking the catalog for datasets {userid} can access ...")
    out.append(f" Master catalog: {_MASTER_CATALOG}")
    out.append("")
    out.append(" ACCESS  VOLSER DATA.SET.NAME")
    out.append(" ------- ------ -------------------------------------------")
    for access, vol, dsn in rows:
        out.append(f" {access:<7} {vol:<6} {dsn}")
    out.append("")
    if show_all:
        out.append(f" CATMAP complete: {reachable} of {total} catalogued datasets"
                   f" are reachable by {userid}.")
    else:
        out.append(f" CATMAP complete: {userid} can access {reachable} of {total}"
                   f" catalogued datasets (use CATMAP -all to see the rest).")
    return "\n".join(out)
