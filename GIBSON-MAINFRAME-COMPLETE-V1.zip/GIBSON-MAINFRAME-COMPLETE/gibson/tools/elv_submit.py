"""Route an in-stream (`SUBMIT *`) ELV assemble-and-run job to the Level B engine.

The real ELV.APF / ELV.SVC drivers QUEUE a small JCL job onto the REXX stack - an
assembler step whose SYSIN is the HLASM that flips the ACEE SPECIAL bit, plus a
linkage-edit step whose SYSLMOD points at the APF library the escalation depends on
- and then issue `SUBMIT * END($$)`.  GIBSON's host SUBMIT only reads JCL from a
dataset, so an in-stream job never reached the engine.  This module parses that
queued JCL, pulls out the HLASM and the real precondition (the target APF library,
or an SVC number), and hands them to run_exploit_hlasm, which assembles+runs the
program against the live control-block image and persists the escalation only if the
precondition actually holds - exactly as the standalone ELV path already does.

Authorised GIBSON training use only.
"""
from __future__ import annotations
import re
from typing import List, Optional, Tuple

# a line is "inline data" until a JES in-stream terminator (/*) or the next JCL card
_JCL_CARD = re.compile(r"^//")
_INSTREAM_END = re.compile(r"^/\*\s*$")
_SYSIN_DD = re.compile(r"^//\S*SYSIN\s+DD\s+(\*|DATA)(?:\s|,|$)", re.I)
_SYSLMOD_DSN = re.compile(r"^//\S*SYSLMOD\s+DD\b.*?\bDSN(?:AME)?\s*=\s*([^,\s]+)", re.I)
_SVC_IN_ASM = re.compile(r"\bSVC\s+(\d{1,3})\b", re.I)
_SVC_MARKER = re.compile(r"\bNUM\s*=\s*(\d{1,3})\b", re.I)
_APF_MARKER = re.compile(r"\bAPF\s*=\s*([A-Z0-9$#@.]+)", re.I)
# Cross-memory impersonation (ELV.SELF style): the driver resolves the target
# address space itself and plants its ASID in the assembler source as a halfword
# constant, then uses AXSET/SSAR to reach it. There is no TAR= in the JCL, so the
# target has to be recovered from RMTASID and mapped back to a jobname.
_XMEM_OPS = re.compile(r"\b(SSAR|AXSET)\b", re.I)
_RMTASID = re.compile(r"^\s*RMTASID\s+DC\s+H'(\d+)'", re.I | re.M)
_JOBNAME = re.compile(r"^//(\S+)\s+JOB\b", re.I | re.M)


def _job_end_line(jcl: str) -> Optional[str]:
    """A realistic JES2 job-end message for the assemble-and-run job, so the
    successful escalation shows the same ``hh.mm.ss JOBnnnnn $HASP165 ...
    MAXCC=0000`` line a real system prints for the compile step (e.g. CMPSVC1 for
    ELV.SVC). The timestamp and job number vary per run, like a live system."""
    m = _JOBNAME.search(jcl)
    if not m:
        return None
    import datetime, random
    ts = datetime.datetime.now().strftime("%H.%M.%S")
    jobid = random.randint(2000, 65000)
    return (f" {ts} JOB{jobid:05d}  $HASP165 {m.group(1).upper()}"
            f" ENDED AT N1  MAXCC=0000  CN(INTERNAL)")


def _impersonation_target_asid(hlasm: str) -> Optional[str]:
    """Target ASID of a cross-memory impersonation program, if it is one."""
    if not _XMEM_OPS.search(hlasm):
        return None
    m = _RMTASID.search(hlasm)
    return m.group(1) if m else None


def _looks_elv(jcl: str) -> bool:
    up = jcl.upper()
    return "CSECT" in up and ("ACEE" in up or "MODESET" in up or "ELV" in up
                              or _SVC_IN_ASM.search(jcl) is not None
                              or "X'26'" in up or 'X"26"' in up)


def _extract_sysin_blocks(lines: List[str]) -> List[str]:
    """Return the text of each in-stream SYSIN DD * block in the JCL."""
    blocks: List[str] = []
    i, n = 0, len(lines)
    while i < n:
        if _SYSIN_DD.match(lines[i]):
            i += 1
            body: List[str] = []
            while i < n and not _INSTREAM_END.match(lines[i]) and not _JCL_CARD.match(lines[i]):
                body.append(lines[i])
                i += 1
            blocks.append("\n".join(body))
        else:
            i += 1
    return blocks


def _clean_dsn(raw: str) -> str:
    dsn = raw.strip().strip("'").upper()
    dsn = re.sub(r"\(.*?\)$", "", dsn)          # drop (MEMBER)
    return dsn


def parse_elv_job(jcl: str) -> Tuple[Optional[str], Optional[str], Optional[str]]:
    """(hlasm, apf_dsn, svc) from a queued ELV job, or (None, None, None) if not one."""
    lines = jcl.splitlines()
    blocks = _extract_sysin_blocks(lines)
    hlasm = next((b for b in blocks if "CSECT" in b.upper()), None)
    if hlasm is None:
        # Fallback for the realistic dataset-source ASMACL build (e.g. book Listing 8-16):
        # the SVISOR source is a member such as RUARIV.SOURCE.ASM(SVISOR) rather than
        # inline HLASM. Recognise it by an APF-library SYSLMOD + SETCODE AC(1) + a
        # C.SYSIN member whose name looks like an ELV/SVISOR/ACEE source, and synthesise
        # the SVISOR ACEE-flip so the assemble-and-run engine can proceed as if the source
        # had been supplied inline.
        _apf = None
        for ln in lines:
            m = _SYSLMOD_DSN.match(ln)
            if m:
                _apf = _clean_dsn(m.group(1)); break
        _has_setcode = re.search(r"\bSETCODE\s+AC\s*\(\s*1\s*\)", jcl, re.I) is not None
        _src = re.search(r"//\S*C\.SYSIN\s+DD\b[^\n]*\(\s*(SVISOR|ELV\w*|ACEE\w*)\s*\)", jcl, re.I)
        if _apf and _has_setcode and _src:
            synth = (
                "SVISOR   CSECT\n"
                "         MODESET KEY=ZERO,MODE=SUP\n"
                "         L 5,X'224'\n"
                "         L 5,X'6C'(5)\n"
                "         L 5,X'C8'(5)\n"
                "         OI X'26'(5),X'80'\n"
                "         BR 14\n"
                "         END\n"
            )
            svc = None
            m = _SVC_IN_ASM.search(synth) or _SVC_MARKER.search(jcl)
            if m:
                svc = m.group(1)
            return synth, _apf, svc
        return None, None, None
    if not _looks_elv(hlasm):
        return None, None, None

    apf_dsn: Optional[str] = None
    for ln in lines:
        m = _SYSLMOD_DSN.match(ln)
        if m:
            apf_dsn = _clean_dsn(m.group(1))
            break
    if apf_dsn is None:                          # allow an explicit //* ELV APF=... marker
        m = _APF_MARKER.search(jcl)
        if m:
            apf_dsn = _clean_dsn(m.group(1))

    svc: Optional[str] = None
    m = _SVC_IN_ASM.search(hlasm) or _SVC_MARKER.search(jcl)
    if m:
        svc = m.group(1)

    return hlasm, apf_dsn, svc


def route_submitted_jcl(state, userid: str, jcl_lines: List[str]) -> Optional[List[str]]:
    """If the queued JCL is an ELV assemble-and-run job, run it and return the report.

    Returns None when the JCL is not an ELV job, so the caller can fall back to
    ordinary SUBMIT handling.
    """
    jcl = "\n".join(jcl_lines)
    hlasm, apf_dsn, svc = parse_elv_job(jcl)
    if hlasm is None:
        return None
    header = ["IKJ56250I IN-STREAM JOB SUBMITTED (ELV assemble-and-run)"]
    # A cross-memory impersonation program never sets SPECIAL in its own ACEE, so
    # judging it by that bit would always report failure. Evaluate it as an
    # impersonation against the same precondition instead.
    target_asid = _impersonation_target_asid(hlasm)
    if target_asid is not None:
        from gibson.tools.elv_engine import apply_impersonation, resolve_asid
        target = resolve_asid(state, userid, target_asid)
        report = apply_impersonation(state, userid, target, apf_dsn=apf_dsn, svc=svc)
        return header + report.splitlines()
    from gibson.tools.elv_engine import run_exploit_hlasm
    # Choose the precondition. A magic/auth SVC IS the authorization source, so
    # when the exploit issues one the holding PDS (SYSLMOD) need not be APF - the
    # SVC path wins. Only a non-magic exploit falls back to the APF-library check.
    magic = {str(s) for s in getattr(state, "magic_svcs", {"233"})}
    if svc and str(svc) in magic:
        kwargs = {"svc": svc}
    elif apf_dsn:
        kwargs = {"apf_dsn": apf_dsn}
    elif svc:
        kwargs = {"svc": svc}
    else:
        kwargs = {}
    report = run_exploit_hlasm(state, userid, hlasm, **kwargs)
    lines = header + report.splitlines()
    # On a successful escalation, echo the compile job's JES end message so the
    # transcript matches a real assemble-and-run (e.g. $HASP165 CMPSVC1 ... MAXCC=0000).
    if "escalation succeeded" in report:
        end = _job_end_line(jcl)
        if end:
            lines.append(end)
    return lines
