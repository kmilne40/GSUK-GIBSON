"""Sandboxed reverse-shell landing.

When a cicspwn reverse-shell job is submitted through the CICS SPOOL interface,
the JCL contains a REXX stub that connects back to the attacker's listener
(rh='<host>';rp='<port>') and serves a shell.  On a real z/OS box that stub runs
and yields a genuine shell.  GIBSON reproduces the *observable* behaviour for the
student - it connects back to the listener and drives an interactive shell - but
that shell is GIBSON's fully-simulated OMVS/TSO session over fake data, so nothing
on the host is ever exposed.

Safety rails:
  * only ever *connects out* to the callback the payload names - it never binds,
    listens or accepts;
  * the callback host must be loopback or RFC1918 (the lab network) - public
    addresses are refused, so GIBSON can't be turned into an outbound relay;
  * the served shell is OmvsShellSession against simulated state - no real
    command ever executes;
  * it can be disabled entirely with GIBSON_REVSHELL_LANDING=0.
"""
from __future__ import annotations

import ipaddress
import re
import socket
import threading
from typing import Optional, Tuple

_CALLBACK_RE = re.compile(r"rh\s*=\s*'([^']+)'\s*;\s*rp\s*=\s*'([^']+)'", re.IGNORECASE)
# cicspwn direct_(tso|unix) bind shell: the REXX BINDs a listening socket on the
# mainframe - Socket('BIND',s_id,'AF_INET' '<port>' MF_IP);Socket('Listen',...)
_BIND_RE = re.compile(r"Socket\(\s*'BIND'[^)]*'AF_INET'\s*'?(\d+)'?", re.IGNORECASE)


def extract_bind_port(jcl: str) -> Optional[int]:
    """Pull the listen port out of a cicspwn direct (bind) shell payload."""
    up = jcl or ""
    if "'LISTEN'" not in up.upper() and "LISTEN" not in up.upper():
        return None
    m = _BIND_RE.search(up)
    if not m:
        return None
    try:
        port = int(m.group(1))
    except ValueError:
        return None
    return port if 0 < port < 65536 else None


def extract_callback(jcl: str) -> Optional[Tuple[str, int]]:
    """Pull (host, port) out of the cicspwn REXX stub, if present."""
    m = _CALLBACK_RE.search(jcl or "")
    if not m:
        return None
    host = m.group(1).strip()
    try:
        port = int(re.sub(r"\D", "", m.group(2)))
    except ValueError:
        return None
    if not host or not (0 < port < 65536):
        return None
    return host, port


def _in_lab_scope(host: str) -> bool:
    """Only loopback / RFC1918 / link-local callbacks are allowed."""
    try:
        ip = ipaddress.ip_address(socket.gethostbyname(host))
    except Exception:
        return False
    return ip.is_loopback or ip.is_private or ip.is_link_local


class _SockShellIO:
    """Adapt a connected socket to OmvsShellSession's reader/writer contract."""

    class _Result:
        __slots__ = ("text", "key")

        def __init__(self, text: str, key: str = ""):
            self.text = text
            self.key = key

    def __init__(self, sock: socket.socket):
        self.sock = sock
        self._buf = b""

    def write(self, text: str) -> None:
        if not text:
            return
        data = text.encode("latin-1", "replace") if isinstance(text, str) else text
        try:
            self.sock.sendall(data)
        except OSError:
            raise _Disconnected()

    def __call__(self, prompt: str = "", hidden: bool = False):
        # mainframe sends the prompt, then waits for the operator's command
        try:
            self.write(prompt)
        except _Disconnected:
            return self._Result("", "EOF")
        line = self._recv_line()
        if line is None:
            return self._Result("", "EOF")
        return self._Result(line, "")

    def _recv_line(self) -> Optional[str]:
        while b"\n" not in self._buf:
            try:
                chunk = self.sock.recv(4096)
            except OSError:
                chunk = b""
            if not chunk:
                if self._buf:
                    line, self._buf = self._buf, b""
                    return line.decode("latin-1", "replace").rstrip("\r")
                return None
            self._buf += chunk
        line, _, self._buf = self._buf.partition(b"\n")
        return line.decode("latin-1", "replace").rstrip("\r")


class _Disconnected(Exception):
    pass


def _serve_tso_shell(state, owner: str, io: "_SockShellIO") -> None:
    """Serve a simulated TSO command environment over the landed socket.

    Mirrors the cicspwn reverse_tso REXX stub: it sends a "TSO > " prompt, reads
    a command, runs it and sends the output back.  Here each line is executed by
    GIBSON's TsoCommandProcessor against simulated state (no host command ever
    runs), so the student's `nc -lvp 4445` session behaves like Listing 9-13 -
    LISTUSER, TIME, LISTDS, LISTGRP and the rest return authentic output."""
    from gibson.apps.tso import TsoCommandProcessor
    proc = TsoCommandProcessor(state, owner)
    prompt = "TSO > "
    while True:
        res = io(prompt)
        if getattr(res, "key", "") == "EOF":
            break
        line = (res.text or "").strip()
        if not line:
            continue
        if line.upper() in ("EXIT", "QUIT", "LOGOFF", "LOGOFF ", "=X", "END", "RETURN"):
            io.write("READY\nLOGOFF\n")
            break
        try:
            out = proc.run(line)
        except Exception:
            out = f"IKJ56500I COMMAND {line.split()[0].upper()} NOT FOUND"
        if out:
            io.write(out if out.endswith("\n") else out + "\n")


def land_reverse_shell(state, jcl: str, owner: str, record: Optional[dict] = None) -> bool:
    """If the JCL carries a reverse-shell callback, connect back (in a daemon
    thread) and serve the simulated shell.  Returns True if a landing started."""
    if not getattr(state.config, "reverse_shell_landing", True):
        return False
    cb = extract_callback(jcl)
    if not cb:
        return False
    host, port = cb
    if not _in_lab_scope(host):
        if record is not None:
            record["landing"] = f"refused (out-of-scope callback {host})"
        return False
    kind = "USS" if ("BPXWUNIX" in (jcl or "").upper() or "BPXBATCH" in (jcl or "").upper()) else "TSO"

    def _worker():
        try:
            s = socket.create_connection((host, port), timeout=8)
            s.settimeout(300)          # generous idle timeout for the interactive session
        except OSError:
            if record is not None:
                record["landing"] = f"no listener at {host}:{port}"
            return
        if record is not None:
            record["landing"] = f"connected to {host}:{port}"
            record["active"] = True
        try:
            _serve_shell(state, owner, _SockShellIO(s), kind)
        except Exception:
            pass
        finally:
            try:
                s.close()
            except OSError:
                pass
            if record is not None:
                record["active"] = False
                record["landing"] = record.get("landing", "") + " (closed)"

    threading.Thread(target=_worker, daemon=True, name="GibsonRevShell").start()
    return True


def _payload_kind(jcl: str) -> str:
    up = (jcl or "").upper()
    return "USS" if ("BPXWUNIX" in up or "BPXBATCH" in up) else "TSO"


def _serve_shell(state, owner: str, io: "_SockShellIO", kind: str) -> None:
    """Serve GIBSON's simulated interactive shell over a connected socket.

    kind == 'USS'  -> a simulated OMVS/USS shell; anything else -> a simulated
    TSO command environment ("TSO > " prompt).  Both run entirely against
    GIBSON's fake state via the standard processors - no host command executes."""
    if kind == "USS":
        from gibson.apps.omvs import OmvsShellSession
        from gibson.apps.tso import TsoCommandProcessor
        OmvsShellSession(state, owner, TsoCommandProcessor(state, owner),
                         mode="USS").run_interactive(io, io.write)
    else:
        _serve_tso_shell(state, owner, io)


def land_bind_shell(state, jcl: str, owner: str, record: Optional[dict] = None) -> bool:
    """cicspwn direct_(tso|unix): the payload BINDs a listening socket on the
    mainframe and the operator connects *in*.  GIBSON reproduces that - it opens
    a listener on the payload's port (on the lab interface only) and serves the
    same fully-simulated shell as the reverse case.  Returns True if a listener
    was started.

    Safety: the served shell is GIBSON's simulated TSO/USS session over fake data
    (no host command runs); the listener binds only to GIBSON's own service host
    /loopback; it is disabled with GIBSON_REVSHELL_LANDING=0."""
    if not getattr(state.config, "reverse_shell_landing", True):
        return False
    port = extract_bind_port(jcl)
    if not port:
        return False
    kind = _payload_kind(jcl)
    bind_host = getattr(getattr(state, "config", None), "host", "") or "127.0.0.1"
    # never bind to a public/wildcard-into-public address; keep it on the lab host
    probe = "127.0.0.1" if bind_host in ("", "0.0.0.0") else bind_host
    if not _in_lab_scope(probe):
        if record is not None:
            record["landing"] = f"refused (bind host {bind_host} out of lab scope)"
        return False

    def _worker():
        srv = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        srv.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            srv.bind((bind_host, port))
            srv.listen(2)
            srv.settimeout(300)          # bounded lifetime for the lab listener
        except OSError as exc:
            if record is not None:
                record["landing"] = f"bind failed on {bind_host}:{port} ({exc})"
            try: srv.close()
            except OSError: pass
            return
        if record is not None:
            record["landing"] = f"listening on {bind_host}:{port} (bind shell)"
        try:
            while True:
                try:
                    conn, addr = srv.accept()
                except (socket.timeout, OSError):
                    break
                if record is not None:
                    record["active"] = True
                    record["landing"] = f"connection from {addr[0]} on {bind_host}:{port}"
                conn.settimeout(300)
                try:
                    _serve_shell(state, owner, _SockShellIO(conn), kind)
                except Exception:
                    pass
                finally:
                    try: conn.close()
                    except OSError: pass
                    if record is not None:
                        record["active"] = False
        finally:
            try: srv.close()
            except OSError: pass
            if record is not None:
                record["landing"] = record.get("landing", "") + " (closed)"

    threading.Thread(target=_worker, daemon=True, name="GibsonBindShell").start()
    return True
