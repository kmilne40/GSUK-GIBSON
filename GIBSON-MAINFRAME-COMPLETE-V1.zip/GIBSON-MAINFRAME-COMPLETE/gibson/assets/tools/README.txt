Bundled working copies of the third-party assessment tools, installed into each
user's <user>.TOOLS PDS at startup so they always run even if nothing is
uploaded.  An uploaded or SMP/E-installed exec of the same name always takes
precedence over these copies (they are the last-resort fallback).

Sources (current versions as bundled):
  ENUM     - mainframed/Enumeration (ENUM)      MIT   github.com/mainframed/Enumeration
  ELVSVC   - ayoul3/Privesc (ELV.SVC)                 github.com/ayoul3/Privesc
  ELVSELF  - ayoul3/Privesc (ELV.SELF)               github.com/ayoul3/Privesc
  ELVAPF   - ayoul3/Privesc (ELV.APF)                github.com/ayoul3/Privesc
