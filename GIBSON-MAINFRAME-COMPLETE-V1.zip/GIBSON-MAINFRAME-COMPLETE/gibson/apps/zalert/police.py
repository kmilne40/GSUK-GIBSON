"""C2POLICE, the zSecure Alert started task, and the library operations.

C2POLICE reads the SMF stream as it is written, evaluates the selected alerts
once per reporting interval, and delivers what fires. It runs only from the
production members of the active configuration, so a change made in SE.A.A
does nothing until it has been verified, refreshed, and the started task has
been told with MODIFY C2POLICE,REFRESH. It also rebuilds its stage-one
environment (who has UID(0), which data sets are APF, the sensitive and
emergency lists) every Environment refresh interval, as the product does.

Operator commands:
    S C2POLICE                  start the started task
    P C2POLICE                  stop it
    F C2POLICE,REFRESH          reload the active configuration's production members
    F C2POLICE,STATUS           show what it is doing (a GIBSON convenience)
    F C2POLICE,COLLECT          take a CKFREEZE environment snapshot now
"""
from __future__ import annotations

import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple

from . import catalog
from .config import (AlertConfig, DEFAULT_EMAILDST, DEFAULT_EMERGNCY, DEFAULT_NAME,
                     DEFAULT_SENSREAD, DEFAULT_SENSUPDT, EMAILDST, EMERGNCY, LAB_NAME,
                     LIBRARY, PROMOTION, REPOSITORY, SENSREAD, SENSUPDT, default_config,
                     lab_config, member_lines, parse_configs, repository_text,
                     verify_members)
from .destinations import Deliverer, Sender, destination_allowed, hec_token, parse_addrs
from .engine import Engine, Environment, parse_line

SELF = "C2POLICE"
CMD_FILE = "c2police.cmd"      # MODIFY commands from a console in another process


def _cmd_path(state) -> Path:
    return Path(state.config.sim_root) / CMD_FILE


# ------------------------------------------------------------ dataset I/O
def _ds_read(state, dsn: str) -> Optional[str]:
    ds = getattr(state, "datasets", None)
    if ds is None:
        return None
    saved = getattr(ds, "security", None)
    try:
        ds.security = None
        return ds.read(SELF, dsn)
    except Exception:
        return None
    finally:
        ds.security = saved


def _ds_write(state, dsn: str, text: str) -> bool:
    ds = getattr(state, "datasets", None)
    if ds is None:
        return False
    saved = getattr(ds, "security", None)
    try:
        ds.security = None
        ds.write(SELF, dsn, text)
        return True
    except Exception:
        return False
    finally:
        ds.security = saved


def read_member(state, dsn: str) -> str:
    return _ds_read(state, dsn) or ""


def write_member(state, dsn: str, text: str) -> bool:
    return _ds_write(state, dsn, text)


# ------------------------------------------------------------ repository
_LOCK = threading.RLock()


def ensure_seeded(state) -> None:
    """First use: C2PDFL, GIBSON's own configuration, and the dialog lists."""
    with _LOCK:
        if _ds_read(state, REPOSITORY):
            return
        dfl, lab = default_config(), lab_config()
        configs = {dfl.name: dfl, lab.name: lab}
        for dsn, lines in ((SENSREAD, DEFAULT_SENSREAD), (SENSUPDT, DEFAULT_SENSUPDT),
                           (EMERGNCY, DEFAULT_EMERGNCY), (EMAILDST, DEFAULT_EMAILDST)):
            if not _ds_read(state, dsn):
                _ds_write(state, dsn, "\n".join(lines) + "\n")
        _write_members(state, verify_members(lab, environment_lists(state)))
        _promote(state, lab.name)
        stamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        lab.verified_at = lab.refreshed_at = stamp
        _ds_write(state, REPOSITORY, repository_text(configs, lab.name))


def load(state) -> Tuple[Dict[str, AlertConfig], str]:
    ensure_seeded(state)
    with _LOCK:
        configs, active = parse_configs(_ds_read(state, REPOSITORY) or "")
        if DEFAULT_NAME not in configs:
            configs[DEFAULT_NAME] = default_config()
        return configs, active


def save(state, configs: Dict[str, AlertConfig], active: str) -> bool:
    with _LOCK:
        return _ds_write(state, REPOSITORY, repository_text(configs, active))


def _write_members(state, members: Dict[str, str]) -> None:
    for member, text in members.items():
        _ds_write(state, f"{LIBRARY}({member})", text + "\n")


def _promote(state, name: str) -> List[str]:
    done = []
    for src, dst in PROMOTION:
        text = _ds_read(state, f"{LIBRARY}({name}{src})")
        if text is None:
            continue
        _ds_write(state, f"{LIBRARY}({name}{dst})", text)
        done.append(f"{name}{dst}")
    return done


# ------------------------------------------------------------- environment
def environment_lists(state) -> Dict[str, List[str]]:
    racf = getattr(state, "racf", None)
    users = getattr(racf, "users", {}) or {}
    uid0 = []
    for uid, u in users.items():
        seg = getattr(u, "omvs_segment", {}) or {}
        if str(seg.get("UID", "")).strip() == "0":
            uid0.append(uid)
    return {
        "EMERGENCY": member_lines(_ds_read(state, EMERGNCY)),
        "UID0USERS": sorted(uid0),
        "APFLIST": [a.upper() for a in (getattr(state, "apf_libraries", []) or [])],
        "SENSREAD": member_lines(_ds_read(state, SENSREAD)),
        "SENSUPDT": member_lines(_ds_read(state, SENSUPDT)),
    }


def build_environment(state) -> Environment:
    lists = environment_lists(state)
    racf = getattr(state, "racf", None)
    return Environment(
        users={u.upper() for u in (getattr(racf, "users", {}) or {})},
        uid0=set(lists["UID0USERS"]), emergency=set(lists["EMERGENCY"]),
        apf=lists["APFLIST"], sensread=lists["SENSREAD"], sensupdt=lists["SENSUPDT"])


# ---------------------------------------------------------- verify/refresh
def verify(state, name: str) -> Tuple[bool, List[str]]:
    """Generate the V-suffixed members. Returns (ok, messages)."""
    configs, active = load(state)
    cfg = configs.get(name.upper())
    if cfg is None:
        return False, [f"C2P0920E CONFIGURATION {name.upper()} NOT FOUND"]
    if cfg.readonly:
        return False, [f"C2P0921E {cfg.name} IS IBM'S DEFAULT - COPY IT (LINE COMMAND C) FIRST"]
    missing = cfg.ready_to_verify()
    if missing:
        return False, [f"C2P0922E COMPLETE {'/'.join(m.title() for m in missing)} "
                       f"BEFORE VERIFYING {cfg.name}"]
    msgs: List[str] = []
    warnings = 0
    if not cfg.selected:
        msgs.append("C2P0923W NO ALERTS ARE SELECTED")
        warnings += 1
    if not (cfg.wto or cfg.email or cfg.textmsg or cfg.syslog or cfg.hec or cfg.cti):
        msgs.append("C2P0924W NO DESTINATIONS - ALERTS WILL BE EVALUATED BUT NOT SENT")
        warnings += 1
    if cfg.snmp:
        msgs.append("C2P0925W SNMP TRAPS ARE NOT SUPPORTED BY THIS TRAINING SYSTEM - IGNORED")
        warnings += 1
    if cfg.syslog and not cfg.c2rsyslg:
        addrs = parse_addrs(cfg.syslog_addrs)
        if not addrs:
            msgs.append("C2P0926W UNIX SYSLOG SELECTED BUT NO ADDRESSES GIVEN")
            warnings += 1
        for host, port in addrs:
            ok, why = destination_allowed(host)
            if not ok:
                msgs.append(f"C2P0927W SYSLOG {host}:{port} WILL BE REFUSED - {why}")
                warnings += 1
    if cfg.hec:
        if not hec_token():
            msgs.append("C2P0928W SPLUNK HEC SELECTED BUT NO TOKEN ON THE HOST "
                        "(GIBSON_SIEM_HEC_TOKEN)")
            warnings += 1
        from urllib.parse import urlparse
        host = urlparse(cfg.hec_url or "").hostname or ""
        ok, why = destination_allowed(host) if host else (False, "NO URL")
        if not ok:
            msgs.append(f"C2P0927W HEC {cfg.hec_url or '(no url)'} WILL BE REFUSED - {why}")
            warnings += 1
    if cfg.extmon:
        msgs.append("C2P0929W EXTENDED MONITORING IS NOT MODELLED - SNAPSHOT ONLY")
        warnings += 1
    if 1102 in cfg.selected and not member_lines(_ds_read(state, EMERGNCY)):
        msgs.append("C2P0930W ALERT 1102 SELECTED BUT NO EMERGENCY USERS IN EMERGNCY")
        warnings += 1
    members = verify_members(cfg, environment_lists(state))
    _write_members(state, members)
    cfg.verified_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cfg.mark("VER")
    save(state, configs, active)
    msgs.insert(0, f"C2P0931I VERIFY OF {cfg.name} COMPLETE, {warnings} WARNING(S) - "
                   f"MEMBERS {', '.join(sorted(members))} WRITTEN")
    return True, msgs


def refresh(state, name: str) -> Tuple[bool, List[str]]:
    """Promote the verified members to production and make this the active one."""
    configs, active = load(state)
    cfg = configs.get(name.upper())
    if cfg is None:
        return False, [f"C2P0920E CONFIGURATION {name.upper()} NOT FOUND"]
    if cfg.status.get("VER") != "OK":
        return False, [f"C2P0932E VERIFY {cfg.name} (LINE COMMAND V) BEFORE REFRESHING IT"]
    promoted = _promote(state, cfg.name)
    cfg.refreshed_at = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    cfg.mark("REF")
    save(state, configs, cfg.name)
    msgs = [f"C2P0933I {cfg.name} PROMOTED TO PRODUCTION: {', '.join(promoted)}"]
    police = getattr(state, "c2police", None)
    if police is not None and police.running:
        msgs.append("C2P0934I NOW TELL THE STARTED TASK: F C2POLICE,REFRESH "
                    "(OR ENTER / ON THE COMMAND LINE)")
    else:
        msgs.append("C2P0935W C2POLICE IS NOT RUNNING - START IT WITH S C2POLICE")
    return True, msgs


def production_config(state, name: str) -> Optional[AlertConfig]:
    text = _ds_read(state, f"{LIBRARY}({name}P)")
    if not text:
        return None
    configs, _active = parse_configs(text)
    return configs.get(name.upper())


# ---------------------------------------------------------------- the STC
class C2Police:
    """The started task. ServiceManager stops it through shutdown()."""

    POLL_SECONDS = 1.0

    def __init__(self, state):
        self.state = state
        self.sender = Sender(state)
        self.deliverer = Deliverer(state, self.sender)
        self.cfg: Optional[AlertConfig] = None
        self.engine: Optional[Engine] = None
        self.running = False
        self.started_at = ""
        self.refreshed_at = ""
        self.alerts_issued = 0
        self.per_alert: Dict[int, int] = {}
        self.records_read = 0
        self._buffer: list = []
        self._offset = 0
        self._inode = None
        self._last_report = 0.0
        self._last_stage1 = 0.0
        self._stop = threading.Event()
        self._lock = threading.RLock()
        self._thread: Optional[threading.Thread] = None

    @property
    def audit_path(self) -> Path:
        return Path(self.state.config.sim_root) / "audit.log"

    def _say(self, line: str, severity: str = "INFO") -> None:
        try:
            self.state.notify_console(line, severity=severity)
        except Exception:
            pass

    # lifecycle ---------------------------------------------------------------
    def start(self) -> "C2Police":
        ensure_seeded(self.state)
        self._load()
        try:
            st = self.audit_path.stat()
            self._offset, self._inode = st.st_size, getattr(st, "st_ino", None)
        except OSError:
            self._offset, self._inode = 0, None
        self._stop.clear()
        self.running = True
        self.started_at = datetime.now().strftime("%H:%M:%S")
        self._last_report = self._last_stage1 = time.time()
        self._thread = threading.Thread(target=self._run, daemon=True, name=SELF)
        self._thread.start()
        if self.cfg is not None:
            self._say(f"C2P0901I ZSECURE ALERT ACTIVE - CONFIGURATION {self.cfg.name}, "
                      f"INTERVAL {self.cfg.interval}S, {len(self.cfg.selected)} ALERTS SELECTED")
        else:
            self._say("C2P0903W ZSECURE ALERT ACTIVE BUT NO REFRESHED CONFIGURATION - "
                      "NOTHING WILL BE ALERTED", "WARNING")
        return self

    def shutdown(self) -> None:
        self._stop.set()
        self.running = False
        if self._thread is not None:
            self._thread.join(timeout=3)
        self._flush()
        self._say("C2P0902I ZSECURE ALERT ENDING")

    def server_close(self) -> None:
        self.sender.stop()

    def _load(self) -> None:
        configs, active = load(self.state)
        cfg = production_config(self.state, active) if active else None
        with self._lock:
            self.cfg = cfg
            self.engine = Engine(cfg, build_environment(self.state)) if cfg else None
            self.refreshed_at = datetime.now().strftime("%H:%M:%S")

    # operator commands ---------------------------------------------------------
    def modify(self, operand: str) -> str:
        op = (operand or "").strip().upper()
        if op == "REFRESH":
            self._flush()
            self._load()
            if self.cfg is None:
                return "C2P0905E REFRESH FAILED - NO PRODUCTION MEMBERS FOR THE ACTIVE CONFIGURATION"
            return (f"C2P0904I REFRESH COMPLETE - CONFIGURATION {self.cfg.name}, "
                    f"{len(self.cfg.selected)} ALERTS, INTERVAL {self.cfg.interval}S")
        if op == "COLLECT":
            try:
                from gibson.core.ckfreeze import get_ckfreeze
                get_ckfreeze(self.state).collect(SELF)
            except Exception:
                pass
            with self._lock:
                if self.engine is not None:
                    self.engine.env = build_environment(self.state)
            return "C2P0906I CKFREEZE COLLECT COMPLETE - ENVIRONMENT REFRESHED"
        if op in ("STATUS", "DISPLAY", "D"):
            return "\n".join(self.status_lines())
        return f"C2P0907E UNKNOWN MODIFY OPERAND {op} - USE REFRESH, COLLECT OR STATUS"

    def status_lines(self) -> List[str]:
        c = self.cfg
        lines = [f"C2P0908I C2POLICE STATUS - {'ACTIVE' if self.running else 'STOPPED'}"
                 f" SINCE {self.started_at or '-'}"]
        if c is None:
            lines.append("  NO REFRESHED CONFIGURATION")
        else:
            lines.append(f"  CONFIGURATION {c.name}  INTERVAL {c.interval}S  "
                         f"AVERAGE {c.average}S  FORWARD {c.forward}")
            lines.append(f"  ALERTS SELECTED {len(c.selected)}  ISSUED {self.alerts_issued}  "
                         f"SMF RECORDS READ {self.records_read}")
            dest = [n for n, f in (("WTO", c.wto), ("CTI", c.cti), ("EMAIL", bool(c.email)),
                                   ("SYSLOG", c.syslog), ("HEC", c.hec)) if f]
            lines.append("  DESTINATIONS " + (" ".join(dest) or "NONE")
                         + ("  (SYSLOG TO C2RSYSLG)" if c.syslog and c.c2rsyslg else ""))
        for name, s in sorted(self.sender.stats.items()):
            lines.append(f"  {name}: SENT {s['sent']} FAILED {s['failed']}"
                         + (f" LAST ERROR {s['last_error']}" if s['last_error'] else ""))
        if self.per_alert:
            top = sorted(self.per_alert.items(), key=lambda kv: -kv[1])[:6]
            lines.append("  BY ALERT " + " ".join(f"{k}={v}" for k, v in top))
        return lines

    # the loop ----------------------------------------------------------------
    def _read_new(self) -> List[str]:
        path = self.audit_path
        try:
            st = path.stat()
        except OSError:
            return []
        inode = getattr(st, "st_ino", None)
        if (self._inode is not None and inode != self._inode) or st.st_size < self._offset:
            self._offset = 0
        self._inode = inode
        if st.st_size == self._offset:
            return []
        try:
            with path.open("r", encoding="utf-8", errors="replace") as fh:
                fh.seek(self._offset)
                lines = fh.readlines()
                self._offset = fh.tell()
            return lines
        except OSError:
            return []

    def _queued_commands(self) -> None:
        """MODIFY commands left by a console running in another process.

        The answer goes to the console as the started task's own message, the
        way a real STC replies to MODIFY: the console accepts the command, and
        the reply arrives a moment later from the address space itself.
        """
        path = _cmd_path(self.state)
        try:
            if not path.exists() or path.stat().st_size == 0:
                return
            lines = path.read_text(encoding="utf-8", errors="replace").splitlines()
            path.write_text("", encoding="utf-8")
        except OSError:
            return
        for operand in (l.strip() for l in lines if l.strip()):
            for reply in self.modify(operand).splitlines():
                self._say(reply)

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                self._queued_commands()
                for line in self._read_new():
                    rec = parse_line(line)
                    if rec is not None:
                        self._buffer.append(rec)
                now = time.time()
                cfg = self.cfg
                if cfg is not None and now - self._last_report >= max(1, cfg.interval):
                    self._last_report = now
                    self._flush()
                if cfg is not None and now - self._last_stage1 >= max(60, cfg.stage1 * 60):
                    self._last_stage1 = now
                    with self._lock:
                        if self.engine is not None:
                            self.engine.env = build_environment(self.state)
            except Exception as exc:          # the monitor must not die quietly
                self._say(f"C2P0909E C2POLICE LOOP ERROR {type(exc).__name__}: {exc}"[:120],
                          "WARNING")
            self._stop.wait(self.POLL_SECONDS)

    def _flush(self) -> None:
        with self._lock:
            records, self._buffer = self._buffer, []
            if not records or self.engine is None or self.cfg is None:
                self.records_read += len(records)
                return
            self.records_read += len(records)
            cfg = self.cfg
            if cfg.forward == "ALL" and (cfg.syslog or cfg.hec):
                for rec in records:
                    if rec.user != SELF:
                        self.deliverer.forward_record(cfg, rec)
            for fired in self.engine.feed(records):
                self.alerts_issued += 1
                self.per_alert[fired.alert.aid] = self.per_alert.get(fired.alert.aid, 0) + 1
                self.deliverer.deliver(cfg, fired)


# ----------------------------------------------------------- integration
def start_police(state) -> C2Police:
    police = getattr(state, "c2police", None)
    if police is not None and police.running:
        return police
    police = C2Police(state)
    state.c2police = police
    return police.start()


def modify_command(state, job: str, operand: str) -> Optional[str]:
    """Hook for F C2POLICE,xxx from the console, SDSF and TSO."""
    if (job or "").strip().upper() != SELF:
        return None
    operand = (operand or "STATUS").strip().upper()
    police = getattr(state, "c2police", None)
    if police is not None and police.running:
        return police.modify(operand)
    mgr = getattr(state, "service_manager", None)
    registered = mgr.get(SELF) if mgr is not None else None
    if registered is not None:
        # This is the process the started task lives in, and it is down.
        return "IEE341I C2POLICE NOT ACTIVE - START IT WITH S C2POLICE"
    # A console in another process: hand the command to the started task and
    # let its reply arrive through OPERLOG, as it would on z/OS.
    try:
        with _cmd_path(state).open("a", encoding="utf-8") as fh:
            fh.write(operand + "\n")
    except OSError:
        return "IEE341I C2POLICE NOT ACTIVE"
    return f"IEE295I MODIFY C2POLICE COMMAND ACCEPTED - {operand}"
