"""zSecure Alert for GIBSON.

A training model of IBM Security zSecure Alert: the SE.A setup dialogs, alert
configurations kept in a customisation library, the verify and refresh cycle,
the C2POLICE started task that watches the SMF stream, and alert delivery to
the operator console, the CTI consoles, e-mail and a SIEM such as Splunk.

Where the product's behaviour is documented it is followed: the SE.A menu
(A Alert, E E-mail, P PCI, S Sensitive), the configuration overview columns
(Set, Des, Sel, Ver, Ref, Act) and line commands, copying C2PDFL as the starting
point, verify writing the V-suffixed members and refresh promoting them, the
MODIFY C2POLICE,REFRESH that makes a refresh take effect, the predefined alert
numbers and titles, installation-defined alerts in the 4000 range, the general
settings (Interval, Environment refresh, Average, Buffer size, Number of
buffers, Extended Monitoring) with the product's defaults, WTO message ids
built from the alert number, and UNIX syslog delivery in RFC 3164 format, which
is how zSecure Alert feeds QRadar and Splunk.

Where GIBSON goes further than the product, it says so: the Splunk HTTP Event
Collector destination models what a forwarder or IBM Z Common Data Provider
would do rather than anything zSecure Alert itself does, and the CTI SENTRY
destination is GIBSON's own.
"""
