"""Delivering an alert: console, CTI, e-mail, syslog and Splunk.

The product's destinations are e-mail, text message, WTO, SNMP trap and UNIX
syslog, and UNIX syslog in RFC 3164 format is how zSecure Alert feeds Splunk
and QRadar. GIBSON implements all of those except SNMP, and adds two of its
own: the CTI SENTRY consoles, and a Splunk HTTP Event Collector sender that
models what a forwarder or IBM Z Common Data Provider would do, since zSecure
Alert itself does not speak HEC.

Two safety rules apply to anything that leaves the machine. Network sends are
made by a background thread, so an unreachable SIEM can slow nothing down, let
alone stop detection. And every network destination must pass a host-side
allowlist, GIBSON_SIEM_ALLOW, which by default admits loopback and private
addresses only. Changing alert destinations is a SPECIAL-level action in the
lab, which students reach as a matter of course, so without the allowlist a
student could point the forwarder at any host on the internet and use the lab
to exfiltrate its own audit trail or to spray traffic at a third party.

The HEC token is read from the host too, from GIBSON_SIEM_HEC_TOKEN or the file
named by GIBSON_SIEM_HEC_TOKEN_FILE, never from the customisation library, for
the same reason the mail relay's password is: everything in the simulated
catalogue should be treated as published.
"""
from __future__ import annotations

import ipaddress
import json
import os
import queue
import socket
import ssl
import threading
import time
import urllib.request
from datetime import datetime, timezone
from typing import Dict, List, Optional, Tuple
from urllib.parse import urlparse

from .catalog import SEVERITIES
from .config import AlertConfig, EMAILDST, SYSLOG_TEST_DSN, member_lines

FACILITY_AUTH = 4            # syslog facility 4: security/authorization messages
SD_ID = "gibson@32473"       # RFC 5424 SD-ID; 32473 is the RFC 5612 example PEN
SELF = "C2POLICE"
HEC_TOKEN_ENV = "GIBSON_SIEM_HEC_TOKEN"
HEC_TOKEN_FILE_ENV = "GIBSON_SIEM_HEC_TOKEN_FILE"
ALLOW_ENV = "GIBSON_SIEM_ALLOW"


# ------------------------------------------------------------- allowlist
def _allow_rules() -> List[str]:
    raw = (os.getenv(ALLOW_ENV, "") or "loopback,private").strip()
    return [r.strip().lower() for r in raw.split(",") if r.strip()]


def _ip_allowed(ip: ipaddress._BaseAddress, rules: List[str]) -> bool:
    for rule in rules:
        if rule == "any":
            return True
        if rule == "loopback" and ip.is_loopback:
            return True
        if rule == "private" and (ip.is_private or ip.is_link_local) and not ip.is_loopback:
            return True
        if "/" in rule or rule.replace(".", "").isdigit() or ":" in rule:
            try:
                if ip in ipaddress.ip_network(rule, strict=False):
                    return True
            except ValueError:
                pass
    return False


def destination_allowed(host: str) -> Tuple[bool, str]:
    """(allowed, reason). Every address the name resolves to must be allowed."""
    rules = _allow_rules()
    if "any" in rules:
        return True, ""
    host = (host or "").strip().strip("[]")
    if not host:
        return False, "NO HOST"
    if host.lower() in rules:
        return True, ""
    try:
        infos = socket.getaddrinfo(host, None)
    except OSError:
        return False, f"{host} DOES NOT RESOLVE"
    addrs = {info[4][0] for info in infos}
    for a in addrs:
        try:
            ip = ipaddress.ip_address(a.split("%")[0])
        except ValueError:
            return False, f"{host} RESOLVES TO AN UNPARSEABLE ADDRESS"
        if not _ip_allowed(ip, rules):
            return False, f"{host} ({a}) IS OUTSIDE {ALLOW_ENV}"
    return True, ""


def parse_addrs(text: str, default_port: int = 514) -> List[Tuple[str, int]]:
    out = []
    for item in (text or "").split(","):
        item = item.strip()
        if not item:
            continue
        host, port = item, default_port
        if item.startswith("["):                       # [v6]:port
            end = item.find("]")
            host = item[1:end]
            rest = item[end + 1:]
            if rest.startswith(":") and rest[1:].isdigit():
                port = int(rest[1:])
        elif item.count(":") == 1:
            h, p = item.split(":")
            if p.isdigit():
                host, port = h, int(p)
        out.append((host, port))
    return out


def hec_token() -> str:
    tok = (os.getenv(HEC_TOKEN_ENV, "") or "").strip()
    if tok:
        return tok
    path = (os.getenv(HEC_TOKEN_FILE_ENV, "") or "").strip()
    if path:
        try:
            return open(os.path.expanduser(path), encoding="utf-8").read().strip()
        except OSError:
            return ""
    return ""


# --------------------------------------------------------------- formats
def _sys_name(state) -> str:
    return (getattr(state, "system_hostname", "") or "GIBSON").upper()


def _sd_escape(value: str) -> str:
    return str(value).replace("\\", "\\\\").replace('"', '\\"').replace("]", "\\]")


def _kv_text(fields: Dict[str, object]) -> str:
    parts = []
    for k, v in fields.items():
        s = str(v)
        if any(c in s for c in ' ="'):
            s = '"' + s.replace('"', "'") + '"'
        parts.append(f"{k}={s}")
    return " ".join(parts)


def syslog_message(fmt: str, sev_letter: str, host: str, msgid: str,
                   fields: Dict[str, object], text: str, when: Optional[float] = None) -> str:
    when = when or time.time()
    sevcode = SEVERITIES.get(sev_letter, ("INFO", 6))[1]
    pri = FACILITY_AUTH * 8 + sevcode
    if (fmt or "").upper() == "RFC5424":
        ts = datetime.fromtimestamp(when, timezone.utc).isoformat(timespec="milliseconds")
        ts = ts.replace("+00:00", "Z")
        sd = "[" + SD_ID + " " + " ".join(
            f'{k}="{_sd_escape(v)}"' for k, v in fields.items()) + "]"
        return f"<{pri}>1 {ts} {host} {SELF} - {msgid} {sd} {text}"
    dt = datetime.fromtimestamp(when)
    stamp = f"{dt:%b} {dt.day:2d} {dt:%H:%M:%S}"
    msg = f"<{pri}>{stamp} {host} {SELF}: {msgid} {_kv_text(fields)} text=\"{text}\""
    return msg[:1024]          # RFC 3164 caps a packet at 1024 octets


def alert_fields(state, fired) -> Dict[str, object]:
    a = fired.alert
    r = fired.record
    return {"alert": a.aid, "msgid": a.msgid, "sev": a.severity,
            "desc": a.title, "sys": _sys_name(state), "user": fired.user or "-",
            "addr": fired.addr or "-", "resource": fired.resource or "-",
            "smftype": r.smftype or "-", "event": r.event or "-"}


def record_fields(state, rec) -> Dict[str, object]:
    return {"smftype": rec.smftype or "-", "event": rec.event or "-",
            "outcome": rec.outcome or "-", "sys": _sys_name(state),
            "user": rec.user or "-", "addr": rec.addr or "-",
            "port": rec.port or "-", "service": rec.service or "-",
            "resource": rec.resource or "-", "access": rec.access or "-"}


# ---------------------------------------------------------------- sender
class Sender:
    """Background delivery for everything that crosses the network."""

    def __init__(self, state):
        self.state = state
        self.q: "queue.Queue" = queue.Queue(maxsize=5000)
        self.stats: Dict[str, Dict[str, object]] = {}
        self._refusals: Dict[str, float] = {}
        self._stop = threading.Event()
        self._thread = threading.Thread(target=self._run, daemon=True, name="C2POLICE-OUT")
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()
        try:
            self.q.put_nowait(None)
        except queue.Full:
            pass

    def _stat(self, dest: str, ok: bool, err: str = "") -> None:
        s = self.stats.setdefault(dest, {"sent": 0, "failed": 0, "last_error": "", "last": ""})
        if ok:
            s["sent"] += 1
            s["last"] = datetime.now().strftime("%H:%M:%S")
        else:
            s["failed"] += 1
            s["last_error"] = err[:120]

    def refused(self, dest: str, reason: str) -> None:
        """Say once every five minutes per destination, not once per alert."""
        self._stat(dest, False, reason)
        now = time.time()
        if now - self._refusals.get(dest, 0) < 300:
            return
        self._refusals[dest] = now
        try:
            self.state.notify_console(f"C2P0910W DESTINATION {dest} REFUSED - {reason}",
                                      severity="WARNING")
        except Exception:
            pass

    def submit(self, kind: str, **job) -> None:
        try:
            self.q.put_nowait((kind, job))
        except queue.Full:
            self._stat(kind, False, "SEND QUEUE FULL")

    def _run(self) -> None:
        while not self._stop.is_set():
            item = self.q.get()
            if item is None:
                break
            kind, job = item
            try:
                if kind == "SYSLOG":
                    self._send_syslog(**job)
                elif kind == "HEC":
                    self._send_hec(**job)
            except Exception as exc:            # never let one bad send kill the thread
                self._stat(kind, False, f"{type(exc).__name__}: {exc}")

    def _send_syslog(self, host: str, port: int, transport: str, message: str) -> None:
        dest = f"SYSLOG {host}:{port}/{transport}"
        data = message.encode("utf-8", "replace")
        try:
            if transport == "TCP":
                with socket.create_connection((host, port), timeout=5) as s:
                    s.sendall(data + b"\n")     # non-transparent framing, LF delimited
            else:
                family = socket.AF_INET6 if ":" in host else socket.AF_INET
                with socket.socket(family, socket.SOCK_DGRAM) as s:
                    s.settimeout(5)
                    s.sendto(data, (host, port))
            self._stat(dest, True)
        except OSError as exc:
            self._stat(dest, False, f"{type(exc).__name__}: {exc}")

    def _send_hec(self, url: str, token: str, body: bytes, verify: bool) -> None:
        dest = f"HEC {urlparse(url).netloc}"
        req = urllib.request.Request(url, data=body, method="POST", headers={
            "Authorization": f"Splunk {token}",
            "Content-Type": "application/json",
        })
        ctx = None
        if url.lower().startswith("https"):
            ctx = ssl.create_default_context()
            if not verify:
                ctx.check_hostname = False
                ctx.verify_mode = ssl.CERT_NONE
        try:
            # The proxy settings of the host are deliberately ignored: a SIEM in
            # the lab is a local service, and routing it through a corporate
            # proxy is how alerts quietly go missing.
            opener = urllib.request.build_opener(
                urllib.request.ProxyHandler({}),
                urllib.request.HTTPSHandler(context=ctx) if ctx else urllib.request.HTTPHandler())
            with opener.open(req, timeout=8) as resp:
                ok = 200 <= resp.status < 300
                self._stat(dest, ok, "" if ok else f"HTTP {resp.status}")
        except Exception as exc:
            self._stat(dest, False, f"{type(exc).__name__}: {exc}")


# ------------------------------------------------------------- delivery
class Deliverer:
    """Fans one alert out to the destinations its configuration names."""

    HISTORY = 200

    def __init__(self, state, sender: Sender):
        self.state = state
        self.sender = sender
        self.history: List[Dict[str, object]] = []

    # local destinations ----------------------------------------------------
    def _wto(self, fired) -> None:
        sev = SEVERITIES.get(fired.alert.severity, ("INFO", 6))[0]
        self.state.notify_console(fired.wto, severity=sev)

    def _cti(self, fired) -> None:
        sev = SEVERITIES.get(fired.alert.severity, ("INFO", 6))[0]
        try:
            self.state.raise_dashboard_alert(fired.wto, severity=sev, addr=fired.addr or "",
                                             event_type="ZSECURE_ALERT")
        except Exception:
            pass

    def _mail_recipients(self, spec: str) -> Tuple[List[str], List[str]]:
        """Expand SE.A.E list names; split into local userids and external addresses."""
        lists: Dict[str, List[str]] = {}
        try:
            text = self._read(EMAILDST)
            for line in member_lines(text):
                parts = line.split(None, 2)
                if len(parts) >= 3 and parts[0].upper() == "LIST":
                    lists[parts[1].upper()] = [p.strip() for p in parts[2].split(",") if p.strip()]
        except Exception:
            pass
        local, external = [], []
        for token in (t.strip() for t in (spec or "").split(",") if t.strip()):
            members = lists.get(token.upper(), [token])
            for m in members:
                if "@" not in m:
                    local.append(m.upper())
                elif m.upper().endswith("@GIBSON.LOCAL"):
                    local.append(m.split("@")[0].upper())
                else:
                    external.append(m)
        return sorted(set(local)), sorted(set(external))

    def _read(self, dsn: str) -> str:
        ds = getattr(self.state, "datasets", None)
        if ds is None:
            return ""
        saved = getattr(ds, "security", None)
        try:
            ds.security = None
            return ds.read(SELF, dsn) or ""
        except Exception:
            return ""
        finally:
            ds.security = saved

    def _write(self, dsn: str, text: str) -> bool:
        ds = getattr(self.state, "datasets", None)
        if ds is None:
            return False
        saved = getattr(ds, "security", None)
        try:
            ds.security = None
            ds.write(SELF, dsn, text)
            return True
        except Exception:
            return False
        finally:
            ds.security = saved

    def _email(self, fired, spec: str) -> List[str]:
        """Subject 'Alert nnnn: text', as the product sends it."""
        from gibson.apps.mail3270.mail_store import Message, _now, parse, serialise
        subject = f"Alert {fired.alert.aid}: {fired.text}"[:120]
        body = [f"zSecure Alert {fired.alert.aid} {fired.alert.msgid}",
                f"Alert      : {fired.alert.title}",
                f"System     : {_sys_name(self.state)}",
                f"User       : {fired.user or '-'}",
                f"From       : {fired.addr or 'unknown'}",
                f"Resource   : {fired.resource or '-'}",
                f"SMF record : type {fired.record.smftype or '-'} {fired.record.event}",
                f"Time       : {fired.record.ts}",
                "", fired.text]
        local, external = self._mail_recipients(spec)
        done = []
        for user in local:
            # Written directly as C2POLICE rather than through MailStore, whose
            # mailbox provisioning issues RACF commands as IBMUSER. Those land in
            # SMF and count towards alert 1120, so each alert mail would have fed
            # the next alert.
            dsn = f"{user}.MAIL.IN"
            msgs = parse(self._read(dsn))
            msgs.insert(0, Message(f"{SELF}@{_sys_name(self.state)}", user, subject,
                                   _now(), "NEW", body))
            if self._write(dsn, serialise(msgs[:500])):
                done.append(user)
        for addr in external:
            try:
                from gibson.apps.mail3270 import mail_relay
                ok, _status = mail_relay.send_external(self.state, addr, subject, body,
                                                       userid=SELF)
                if ok:
                    done.append(addr)
            except Exception:
                pass
        return done

    def _c2rsyslg(self, line: str) -> None:
        existing = self._read(SYSLOG_TEST_DSN)
        lines = existing.splitlines() if existing else []
        lines.append(line)
        self._write(SYSLOG_TEST_DSN, "\n".join(lines[-2000:]) + "\n")

    # network destinations ---------------------------------------------------
    def _syslog(self, cfg: AlertConfig, message: str) -> List[str]:
        if cfg.c2rsyslg:
            self._c2rsyslg(message)
            return ["C2RSYSLG"]
        out = []
        transport = "TCP" if cfg.syslog_transport.upper() == "TCP" else "UDP"
        for host, port in parse_addrs(cfg.syslog_addrs):
            allowed, why = destination_allowed(host)
            dest = f"SYSLOG {host}:{port}/{transport}"
            if not allowed:
                self.sender.refused(dest, why)
                continue
            self.sender.submit("SYSLOG", host=host, port=port, transport=transport,
                               message=message)
            out.append(dest)
        return out

    def _hec(self, cfg: AlertConfig, event: Dict[str, object], sourcetype: str,
             when: float) -> List[str]:
        url = (cfg.hec_url or "").strip()
        if not url:
            return []
        host = urlparse(url).hostname or ""
        dest = f"HEC {urlparse(url).netloc}"
        allowed, why = destination_allowed(host)
        if not allowed:
            self.sender.refused(dest, why)
            return []
        token = hec_token()
        if not token:
            self.sender.refused(dest, f"NO HEC TOKEN - SET {HEC_TOKEN_ENV} ON THE HOST")
            return []
        payload = {"time": round(when, 3), "host": _sys_name(self.state), "source": SELF,
                   "sourcetype": sourcetype or cfg.hec_sourcetype, "index": cfg.hec_index or "main",
                   "event": event}
        self.sender.submit("HEC", url=url, token=token,
                           body=json.dumps(payload).encode("utf-8"), verify=cfg.hec_verify)
        return [dest]

    # entry points -----------------------------------------------------------
    def deliver(self, cfg: AlertConfig, fired) -> List[str]:
        where: List[str] = []
        if cfg.wto:
            self._wto(fired)
            where.append("WTO")
        if cfg.cti:
            self._cti(fired)
            where.append("CTI")
        spec = ",".join(x for x in (cfg.email, cfg.textmsg) if x)
        if spec:
            where += [f"MAIL {r}" for r in self._email(fired, spec)]
        when = fired.record.epoch or time.time()
        fields = alert_fields(self.state, fired)
        if cfg.syslog:
            msg = syslog_message(cfg.syslog_format, fired.alert.severity,
                                 _sys_name(self.state), fired.alert.msgid, fields,
                                 fired.text, when)
            where += self._syslog(cfg, msg)
        if cfg.hec:
            event = dict(fields, text=fired.text, title=fired.alert.title)
            where += self._hec(cfg, event, cfg.hec_sourcetype, when)
        self.history.append({
            "time": datetime.now().strftime("%Y-%m-%d %H:%M:%S"), "alert": fired.alert.aid,
            "msgid": fired.alert.msgid, "severity": fired.alert.severity,
            "title": fired.alert.title, "text": fired.text, "user": fired.user,
            "addr": fired.addr, "resource": fired.resource, "delivered": where,
        })
        del self.history[:-self.HISTORY]
        return where

    def forward_record(self, cfg: AlertConfig, rec) -> None:
        """FORWARD(ALL): every SMF record to the SIEM, as a SIEM adapter would."""
        fields = record_fields(self.state, rec)
        msgid = f"SMF{rec.smftype or '00'}"
        sev = "W" if rec.failed else "I"
        text = f"{rec.event} {rec.outcome}".strip()
        if cfg.syslog and not cfg.c2rsyslg:
            msg = syslog_message(cfg.syslog_format, sev, _sys_name(self.state), msgid,
                                 fields, text, rec.epoch)
            self._syslog(cfg, msg)
        if cfg.hec:
            self._hec(cfg, dict(fields, raw=rec.raw[:2000]), f"zos:smf:{rec.smftype or 'x'}",
                      rec.epoch)
