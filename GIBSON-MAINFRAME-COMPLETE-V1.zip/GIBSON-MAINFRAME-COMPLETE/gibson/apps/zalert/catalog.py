"""The alert catalogue: predefined RACF alerts and GIBSON's installation alerts.

Numbers and titles of the predefined alerts are IBM's, from the zSecure Alert
User Reference Manual. Only alerts the simulator can genuinely observe are
offered; an alert that could never fire would teach the wrong lesson. Alerts
4000-4999 are the range the product reserves for installation-defined RACF
alerts, which is where a site puts alerts of its own, so GIBSON's scan and
watched-user alerts live there rather than borrowing an IBM number.

The CARLa shown for each alert is illustrative: it is the selection a site
would write to express the same condition, so a learner sees the language, not
a transcript of IBM's internal skeletons.
"""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

# Severity, as the letter that ends the WTO message id and the word the
# consoles use. z/OS convention: I information, W warning, E error, A action.
SEVERITIES = {
    "I": ("INFO", 6),       # syslog informational
    "W": ("WARNING", 4),    # syslog warning
    "E": ("ALERT", 3),      # syslog error
    "A": ("ALERT", 1),      # syslog alert, immediate action required
}

CATEGORIES = [
    ("USER", "User alerts"),
    ("DATASET", "Data set alerts"),
    ("UNIX", "UNIX alerts"),
    ("RACF", "RACF control alerts"),
    ("INSTALL", "Installation-defined alerts"),
]


@dataclass
class AlertDef:
    aid: int
    category: str
    title: str
    severity: str           # I W E A
    text: str               # message text; {user} {addr} {resource} {count} {detail} {window}
    kind: str               # matcher name, see engine.py
    carla: Tuple[str, ...]  # illustrative CARLa selection
    params: Dict[str, str] = field(default_factory=dict)
    predefined: bool = True

    @property
    def msgid(self) -> str:
        """WTO id built from the alert number, e.g. alert 4801 issues C2P4801I."""
        return f"C2P{self.aid:04d}{self.severity}"

    def copy(self) -> "AlertDef":
        return AlertDef(self.aid, self.category, self.title, self.severity,
                        self.text, self.kind, tuple(self.carla), dict(self.params),
                        self.predefined)


PREDEFINED: List[AlertDef] = [
    # ---------------------------------------------------------------- user
    AlertDef(1101, "USER", "Logon by unknown user", "W",
             "Logon by unknown user {user} from {addr}", "logon_unknown",
             ("NEWLIST TYPE=SMF NAME=A1101",
              "  SELECT EVENT=RACINIT(1) INTENT=NONE",
              "  SORTLIST DATE TIME USER TERMINAL")),
    AlertDef(1102, "USER", "Logon with emergency user ID", "A",
             "Logon with emergency user ID {user} from {addr}", "logon_emergency",
             ("NEWLIST TYPE=SMF NAME=A1102",
              "  SELECT EVENT=RACINIT(0) USER=(&EMERGENCY)",
              "  SORTLIST DATE TIME USER NAME TERMINAL")),
    AlertDef(1103, "USER", "Logon of a user ID with uid(0) (UNIX superuser)", "E",
             "Logon of UID(0) user {user} from {addr}", "logon_uid0",
             ("NEWLIST TYPE=SMF NAME=A1103",
              "  SELECT EVENT=RACINIT(0) USER=(&UID0USERS)",
              "  SORTLIST DATE TIME USER UID TERMINAL")),
    AlertDef(1105, "USER", "System authority granted", "E",
             "System authority {detail} granted to {resource} by {user}", "auth_granted",
             ("NEWLIST TYPE=SMF NAME=A1105",
              "  SELECT EVENT=ALTUSER(0) SPECIFIED=(SPECIAL,OPERATIONS,AUDITOR)",
              "  SORTLIST DATE TIME USER RACFCMD_NAME SPECIFIED")),
    AlertDef(1106, "USER", "System authority removed", "W",
             "System authority {detail} removed from {resource} by {user}", "auth_removed",
             ("NEWLIST TYPE=SMF NAME=A1106",
              "  SELECT EVENT=ALTUSER(0) SPECIFIED=(NOSPECIAL,NOOPERATIONS,NOAUDITOR)",
              "  SORTLIST DATE TIME USER RACFCMD_NAME SPECIFIED")),
    AlertDef(1111, "USER", "Invalid password attempts exceed limit", "E",
             "Invalid password attempts for {user} exceed limit: {count} in {window} from {addr}",
             "pw_limit",
             ("NEWLIST TYPE=SMF NAME=A1111",
              "  SELECT EVENT=RACINIT(2)          /* invalid password */",
              "  SUMMARY USER COUNT(5) WITHIN(360)  /* 5 per 6 minutes */"),
             {"count": "5", "within": "360"}),
    AlertDef(1115, "USER", "Too many violations", "E",
             "Too many violations by {user}: {count} in {window}", "violations",
             ("NEWLIST TYPE=SMF NAME=A1115",
              "  SELECT VIOLATION",
              "  SUMMARY USER COUNT(&VIOLLIMIT) WITHIN(&AVERAGE)"),
             {"count": "10"}),
    AlertDef(1120, "USER", "Major administrative activity", "W",
             "Major administrative activity by {user}: {count} RACF commands in {window}",
             "admin_burst",
             ("NEWLIST TYPE=SMF NAME=A1120",
              "  SELECT EVENT=(ADDUSER,ALTUSER,DELUSER,PERMIT,ADDSD,ALTDSD,RDEFINE,RALTER,SETROPTS)",
              "  SUMMARY USER COUNT(&ADMINLIMIT) WITHIN(&AVERAGE)"),
             {"count": "10"}),
    # ------------------------------------------------------------- data set
    AlertDef(1201, "DATASET", "WARNING mode access on data set", "W",
             "WARNING mode access to {resource} by {user}", "warning_access",
             ("NEWLIST TYPE=SMF NAME=A1201",
              "  SELECT EVENT=ACCESS(0) CLASS=DATASET QUAL=WARNING",
              "  SORTLIST DATE TIME USER RESOURCE INTENT")),
    AlertDef(1202, "DATASET", "UACC>=UPDATE on a DATASET profile", "E",
             "UACC({detail}) set on DATASET profile {resource} by {user}", "uacc_update",
             ("NEWLIST TYPE=SMF NAME=A1202",
              "  SELECT EVENT=(ADDSD,ALTDSD) UACC>=UPDATE",
              "  SORTLIST DATE TIME USER RESOURCE UACC")),
    AlertDef(1203, "DATASET", "UACC>NONE on a DATASET profile", "W",
             "UACC({detail}) set on DATASET profile {resource} by {user}", "uacc_read",
             ("NEWLIST TYPE=SMF NAME=A1203",
              "  SELECT EVENT=(ADDSD,ALTDSD) UACC>NONE UACC<UPDATE",
              "  SORTLIST DATE TIME USER RESOURCE UACC")),
    AlertDef(1204, "DATASET", "Update on APF data set", "A",
             "Update on APF data set {resource} by {user}", "apf_update",
             ("NEWLIST TYPE=SMF NAME=A1204",
              "  SELECT EVENT=ACCESS(0) INTENT>=UPDATE RESOURCE=(&APFLIST)",
              "  SORTLIST DATE TIME USER RESOURCE INTENT")),
    AlertDef(1212, "DATASET", "Access>=READ on site sensitive data set", "E",
             "Access {detail} to sensitive data set {resource} by {user} from {addr}",
             "sens_read",
             ("NEWLIST TYPE=SMF NAME=A1212",
              "  SELECT EVENT=ACCESS(0) INTENT>=READ RESOURCE=(&SENSREAD)",
              "  SORTLIST DATE TIME USER RESOURCE INTENT")),
    AlertDef(1213, "DATASET", "Access>=UPDATE on site sensitive data set", "A",
             "Access {detail} to sensitive data set {resource} by {user} from {addr}",
             "sens_update",
             ("NEWLIST TYPE=SMF NAME=A1213",
              "  SELECT EVENT=ACCESS(0) INTENT>=UPDATE RESOURCE=(&SENSUPDT)",
              "  SORTLIST DATE TIME USER RESOURCE INTENT")),
    # ------------------------------------------------------------------ UNIX
    AlertDef(1410, "UNIX", "UID(0) assigned", "A",
             "UID(0) assigned to {resource} by {user}", "uid0_assigned",
             ("NEWLIST TYPE=SMF NAME=A1410",
              "  SELECT EVENT=ALTUSER(0) SPECIFIED=OMVS UID=0",
              "  SORTLIST DATE TIME USER RACFCMD_NAME")),
    AlertDef(1411, "UNIX", "Permit issued on BPX.SUPERUSER", "A",
             "Permit on BPX.SUPERUSER issued by {user}: {detail}", "bpx_superuser",
             ("NEWLIST TYPE=SMF NAME=A1411",
              "  SELECT EVENT=PERMIT(0) CLASS=FACILITY RESOURCE=BPX.SUPERUSER",
              "  SORTLIST DATE TIME USER RACFCMD_PARMS")),
    # ------------------------------------------------------------ RACF control
    AlertDef(1503, "RACF", "Global security countermeasure or option changed", "W",
             "SETROPTS issued by {user}: {detail}", "setropts_change",
             ("NEWLIST TYPE=SMF NAME=A1503",
              "  SELECT EVENT=SETROPTS(0)",
              "  SORTLIST DATE TIME USER RACFCMD_PARMS")),
    AlertDef(1504, "RACF", "RACF Resource class activated", "W",
             "RACF class {detail} activated by {user}", "class_activated",
             ("NEWLIST TYPE=SMF NAME=A1504",
              "  SELECT EVENT=SETROPTS(0) SPECIFIED=CLASSACT",
              "  SORTLIST DATE TIME USER RACFCMD_PARMS")),
    AlertDef(1505, "RACF", "RACF Resource class deactivated", "E",
             "RACF class {detail} deactivated by {user}", "class_deactivated",
             ("NEWLIST TYPE=SMF NAME=A1505",
              "  SELECT EVENT=SETROPTS(0) SPECIFIED=NOCLASSACT",
              "  SORTLIST DATE TIME USER RACFCMD_PARMS")),
]

# Installation-defined alerts GIBSON ships in its own configuration. They are
# ordinary custom alerts and are edited, copied and deleted exactly as a site's
# own would be, which is also what the tutorial teaches.
INSTALLATION: List[AlertDef] = [
    AlertDef(4001, "INSTALL", "Logon by watched user", "W",
             "Logon by watched user {user} to {service} from {addr}", "custom",
             ("NEWLIST TYPE=SMF NAME=A4001",
              "  SELECT EVENT=RACINIT(0) USER=(IBMUSER,GUEST)",
              "  SORTLIST DATE TIME USER TERMINAL"),
             {"event": "LOGON", "result": "SUCCESS", "user": "IBMUSER,GUEST",
              "resource": "*", "addr": "*", "service": "*",
              "count": "1", "within": "0", "groupby": "NONE"},
             predefined=False),
    AlertDef(4002, "INSTALL", "Network scan from a single address", "A",
             "Possible port scan from {addr}: {count} distinct ports in {window}", "custom",
             ("NEWLIST TYPE=SMF NAME=A4002",
              "  SELECT SMFTYPE=(80,119) EVENT=(CONNECT,CONNECTION,UNKNOWN_HIGH_PORT)",
              "  SUMMARY ADDR DISTINCT(PORT) COUNT(3) WITHIN(60)"),
             {"event": "CONNECT,CONNECTION,UNKNOWN_HIGH_PORT", "result": "*", "user": "*",
              "resource": "*", "addr": "*", "service": "*",
              "count": "3", "within": "60", "groupby": "ADDR", "distinct": "PORT"},
             predefined=False),
    AlertDef(4003, "INSTALL", "Probe of the mail listener", "E",
             "Connection to mail listener SMTPD from {addr}", "custom",
             ("NEWLIST TYPE=SMF NAME=A4003",
              "  SELECT SMFTYPE=80 EVENT=CONNECT USER=SMTPD",
              "  SORTLIST DATE TIME ADDR"),
             {"event": "CONNECT", "result": "*", "user": "SMTPD",
              "resource": "*", "addr": "*", "service": "SMTP",
              "count": "1", "within": "0", "groupby": "NONE"},
             predefined=False),
]

# What C2PDFL, IBM's default configuration, selects. A real site copies it and
# changes the selection; GIBSON's own configuration does exactly that.
DEFAULT_SELECTED = (1101, 1102, 1103, 1105, 1111, 1115, 1202, 1204, 1410, 1411, 1505)
GIBSON_SELECTED = DEFAULT_SELECTED + (1106, 1120, 1203, 1212, 1213, 1503, 1504,
                                      4001, 4002, 4003)


def by_id() -> Dict[int, AlertDef]:
    return {a.aid: a for a in PREDEFINED}


def lookup(aid: int, custom: Optional[Dict[int, AlertDef]] = None) -> Optional[AlertDef]:
    if custom and aid in custom:
        return custom[aid]
    return by_id().get(aid)


def custom_carla(params: Dict[str, str], aid: int) -> Tuple[str, ...]:
    """The CARLa a site would write for a form-defined custom alert."""
    sel = []
    ev = params.get("event", "*")
    if ev and ev != "*":
        events = [e.strip() for e in ev.split(",") if e.strip()]
        sel.append("EVENT=" + (events[0] if len(events) == 1 else "(" + ",".join(events) + ")"))
    for key, word in (("user", "USER"), ("resource", "RESOURCE"),
                      ("addr", "ADDR"), ("service", "APPL")):
        val = params.get(key, "*")
        if val and val != "*":
            vals = [v.strip() for v in val.split(",") if v.strip()]
            sel.append(f"{word}=" + (vals[0] if len(vals) == 1 else "(" + ",".join(vals) + ")"))
    res = params.get("result", "*")
    if res and res != "*":
        sel.append("VIOLATION" if res.upper() in ("FAILURE", "VIOLATION") else "SUCCESS")
    lines = [f"NEWLIST TYPE=SMF NAME=A{aid}", "  SELECT " + (" ".join(sel) or "ALL")]
    count = params.get("count", "1")
    within = params.get("within", "0")
    group = params.get("groupby", "NONE")
    distinct = (params.get("distinct", "") or "").upper()
    if str(count) not in ("", "0", "1") and str(within) not in ("", "0"):
        dist = f" DISTINCT({distinct})" if distinct and distinct != "*" else ""
        lines.append(f"  SUMMARY {group if group != 'NONE' else 'ALL'}{dist} "
                     f"COUNT({count}) WITHIN({within})")
    else:
        lines.append("  SORTLIST DATE TIME USER ADDR RESOURCE")
    return tuple(lines)
