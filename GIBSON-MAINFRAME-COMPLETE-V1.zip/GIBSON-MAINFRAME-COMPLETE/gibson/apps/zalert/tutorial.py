"""The built-in tutorial: how this is done on z/OS, and a guided exercise.

Two parts. The pages explain the real system: where SMF records come from, how
SMFPRMxx selects them, what zSecure Alert adds on top, the configuration
cycle, CARLa, the destinations, and how alerts reach a SIEM. The exercise is a
series of steps shown at the bottom of every SE.A panel. Each step checks the
system to see whether it has actually been done, rather than waiting for the
learner to say so, so it advances when the work is real and not before.
"""
from __future__ import annotations

from typing import Callable, List, Optional, Tuple

TUTORIAL_CONFIG = "LAB1"

PAGES: List[Tuple[str, List[str]]] = [
    ("Where the records come from", [
        "Every security decision RACF makes can be written as an SMF type 80 record:",
        "a logon, a failed password, an access to a data set, an ALTUSER, a PERMIT.",
        "TCP/IP writes type 119 for connections, and job accounting writes type 30.",
        "",
        "What SMF collects is set in SYS1.PARMLIB(SMFPRMxx). The SYS statement names",
        "the record types, for example SYS(TYPE(30,80,119)), or excludes them with",
        "NOTYPE. You activate a member from the console with SET SMF=xx, and check",
        "what is live with D SMF, or D SMF,O for every option in effect.",
        "",
        "Records land in SYS1.MANx data sets or, on a modern system, in log streams",
        "through System Logger. Getting them back out is a batch job: IFASMFDP dumps",
        "MANx data sets, IFASMFDL dumps log streams, and for RACF records IRRADU00",
        "unloads type 80 to a flat file you can sort and report on.",
        "",
        "That is the important point. SMF is a recording facility, and by itself it",
        "alerts nobody. The ICH408I you see on the console for a violation comes",
        "from RACF, not from SMF. Turning the SMF stream into alerts in real time",
        "is what zSecure Alert is for.",
    ]),
    ("What zSecure Alert does", [
        "zSecure Alert runs as a started task, C2POLICE. It reads SMF records as they",
        "are written, holds them in memory buffers, and every reporting interval it",
        "evaluates the alerts you selected and sends whatever fired. A second task,",
        "C2PCOLL, takes a CKFREEZE snapshot of the system so alerts can ask questions",
        "such as who has UID(0) or which libraries are APF authorised.",
        "",
        "IBM ships predefined alerts with fixed numbers. 1101 is a logon by an",
        "unknown user, 1102 a logon with an emergency user ID, 1111 invalid password",
        "attempts exceeding the limit, 1204 an update to an APF data set, 1410 UID(0)",
        "being assigned. Numbers 4000 to 4999 are reserved for alerts a site defines",
        "itself, and in this lab 4001 to 4003 are examples of exactly that.",
        "",
        "Each alert issues a console message built from its number: alert 1111 is",
        "C2P1111 followed by a letter for its severity, I W E or A. The same alert",
        "can go to e-mail as 'Alert 1111: ...', to a text message, an SNMP trap,",
        "or to UNIX syslog, which is how it reaches a SIEM.",
    ]),
    ("The configuration cycle", [
        "Alerting is configured in ISPF under SE.A, and SE.A.A lists configurations.",
        "Each one passes through five steps, shown as columns on that list:",
        "",
        "  Set  general settings: interval, averaging, buffers   (line command E)",
        "  Des  destinations: console, mail, syslog, SIEM        (line command W)",
        "  Sel  which alerts are switched on                     (line command S)",
        "  Ver  verify: generate and check the members           (line command V)",
        "  Ref  refresh: promote the members to production       (line command F)",
        "",
        "You never edit C2PDFL, IBM's default. You copy it (C) and change the copy.",
        "Verify writes members with the suffixes VS, VO, V, VE and VP. Refresh copies",
        "them to the production members that C2POLICE actually runs. Even then",
        "nothing changes until you tell the started task: F C2POLICE,REFRESH.",
        "",
        "That last step is the one people forget, and the lesson is real: an alert",
        "you configured but never refreshed is an alert that does not exist.",
    ]),
    ("Writing your own alert in CARLa", [
        "Alerts are expressed in CARLa, the zSecure query language. A site-defined",
        "alert reads like this:",
        "",
        "  NEWLIST TYPE=SMF NAME=A4002",
        "    SELECT EVENT=(CONNECT,CONNECTION) ",
        "    SUMMARY ADDR DISTINCT(PORT) COUNT(3) WITHIN(60)",
        "",
        "SELECT says which records matter. SUMMARY turns many records into one alert",
        "when a threshold is crossed, which is how 'many probes from one address' or",
        "'five bad passwords for one user' becomes a single message, not a flood.",
        "",
        "In this lab, line command I on the alert selection panel creates a new",
        "4xxx alert from a form, and the panel shows the CARLa it corresponds to.",
        "Line command B shows the CARLa behind any alert, predefined or your own.",
    ]),
    ("Getting alerts into Splunk", [
        "zSecure Alert sends to a SIEM as UNIX syslog in RFC 3164 format. In the",
        "product that is the 'QRadar UNIX syslog' destination, and Splunk receives it",
        "the same way, on a UDP or TCP input or through Splunk Connect for Syslog.",
        "A line looks like this:",
        "",
        "  <35>Oct 21 09:56:18 GIBSON C2POLICE: C2P1111E alert=1111 user=GUEST ...",
        "",
        "The <35> is the priority: facility 4 (security) times eight plus severity 3.",
        "Splunk extracts the key=value pairs on its own. RFC 5424 is offered too.",
        "",
        "Splunk's HTTP Event Collector is the other route: an HTTPS POST of JSON to",
        "/services/collector/event with the header 'Authorization: Splunk <token>'.",
        "zSecure Alert does not use HEC itself; a forwarder or IBM Z Common Data",
        "Provider does. GIBSON offers it so you can practise both. The token lives",
        "on the host in GIBSON_SIEM_HEC_TOKEN, never in the lab's data sets.",
    ]),
    ("Testing without a SIEM", [
        "Set 'Write messages to C2RSYSLG DD' to Y and syslog output is written to",
        "the data set C2P.C2RSYSLG instead of being sent. Browse it from ISPF 3.4 to",
        "see exactly what a SIEM would receive. This mirrors the product's own test",
        "option, and it is how the GIBSON configuration ships.",
        "",
        "To receive real traffic, run scripts/siem-sink.py on the lab host or any",
        "machine near it. It listens for syslog on UDP and TCP 5514 and for HEC on",
        "8088, and prints each event as it arrives, as a stand-in for Splunk.",
        "",
        "Network destinations must be allowed by GIBSON_SIEM_ALLOW on the host,",
        "which admits loopback and private addresses by default. Anyone who reaches",
        "SPECIAL in this lab can change destinations, so without that limit a",
        "student could point the forwarder at the internet and exfiltrate the",
        "audit trail. That is itself a finding worth discussing.",
    ]),
]


def _cfg(state, name: str):
    try:
        from .police import load
        configs, active = load(state)
        return configs.get(name), active
    except Exception:
        return None, ""


def _tutorial_config(state):
    """The learner's copy: LAB1 if it exists, else the first non-IBM, non-lab one."""
    try:
        from .police import load
        configs, active = load(state)
    except Exception:
        return None, ""
    if TUTORIAL_CONFIG in configs:
        return configs[TUTORIAL_CONFIG], active
    for name, cfg in sorted(configs.items()):
        if name not in ("C2PDFL", "GIBSON"):
            return cfg, active
    return None, active


Check = Callable[[object, dict], bool]


def _copied(state, ctx) -> bool:
    cfg, _ = _tutorial_config(state)
    return cfg is not None


def _step(name: str) -> Check:
    def check(state, ctx) -> bool:
        cfg, _ = _tutorial_config(state)
        return cfg is not None and cfg.status.get(name) == "OK"
    return check


def _refreshed_and_running(state, ctx) -> bool:
    cfg, active = _tutorial_config(state)
    police = getattr(state, "c2police", None)
    ok = (cfg is not None and cfg.status.get("REF") == "OK" and active == cfg.name
          and police is not None and police.cfg is not None and police.cfg.name == cfg.name)
    if ok and "baseline" not in ctx:
        ctx["baseline"] = police.alerts_issued
    return ok


def _fired(state, ctx) -> bool:
    police = getattr(state, "c2police", None)
    if police is None or "baseline" not in ctx:
        return False
    return police.alerts_issued > ctx["baseline"]


STEPS: List[Tuple[str, Check]] = [
    ("Type C next to C2PDFL on SE.A.A and name the copy LAB1. You never edit "
     "IBM's default; you copy it.", _copied),
    ("Type E next to LAB1. Set Interval to 10 seconds and press ENTER to save "
     "the general settings.", _step("SET")),
    ("Type W next to LAB1. Keep WTO and CTI at Y, set UNIX syslog Y and C2RSYSLG "
     "Y, then ENTER.", _step("DES")),
    ("Type S next to LAB1. 1111 is already on. Type I on any row to add a scan "
     "alert: event CONNECT,CONNECTION, count 3 within 60, group ADDR, distinct PORT. "
     "PF3 saves.", _step("SEL")),
    ("Type V next to LAB1 to verify. Read the C2P09xx messages: that is what "
     "verify checked.", _step("VER")),
    ("Type F next to LAB1 to refresh it into production, then enter / on the "
     "command line to issue F C2POLICE,REFRESH.", _refreshed_and_running),
    ("Trigger it: from Kali, nmap -sV -p 21,23,175,2525 <lab address>, or "
     "fail GUEST's TSO password five times.", _fired),
    ("Done. See the C2P lines on the Master Console, /cti/zalert in CTI "
     "SENTRY, mail in M.8, and C2P.C2RSYSLG in 3.4.", lambda s, c: False),
]


def current(state, ctx: dict) -> Tuple[int, str]:
    """(step number from 1, text). Steps are checked in order every time."""
    for i, (text, check) in enumerate(STEPS):
        try:
            done = check(state, ctx)
        except Exception:
            done = False
        if not done:
            return i + 1, text
    return len(STEPS), STEPS[-1][0]


def progress_lines(state, ctx: dict) -> List[str]:
    n, _ = current(state, ctx)
    out = []
    for i, (text, _check) in enumerate(STEPS, start=1):
        mark = "DONE" if i < n else ("NEXT" if i == n else "    ")
        out.append(f"{mark}  {i}. {text}")
    return out


def wrap(text: str, width: int) -> List[str]:
    words, lines, cur = text.split(), [], ""
    for w in words:
        if len(cur) + len(w) + (1 if cur else 0) > width:
            lines.append(cur)
            cur = w
        else:
            cur = f"{cur} {w}" if cur else w
    if cur:
        lines.append(cur)
    return lines
