"""Alert configurations and the customisation library C2P.C2PCUST.

The product keeps its alert configurations in a customisation library (C2PCUST
or CKACUST), and the dialog walks each one through five steps shown as columns
on the SE.A.A overview: Set (general settings), Des (destinations), Sel (alert
selection), Ver (verify) and Ref (refresh). A step shows Req until done and OK
after, and changing anything after verification sends Ver and Ref back to Req,
because what runs is only ever what was last verified and refreshed.

Verify writes the configuration's V-suffixed members: VS stage one, VO the
environment-dependent selection criteria, V the report, VE Extended Monitoring
and VP the parameters. Refresh promotes them to the production members S,
(none), E and P. The started task runs from production, so an edit has no
effect until it has been verified, refreshed and C2POLICE has been told with
MODIFY C2POLICE,REFRESH. GIBSON keeps that discipline because it is the
lesson: a monitoring change nobody refreshed is a monitoring change that did
not happen.

Member names are eight characters, so a configuration name is at most six,
leaving room for the two-character suffix.
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Dict, Iterable, List, Optional, Set

from . import catalog
from .catalog import AlertDef

LIBRARY = "C2P.C2PCUST"
REPOSITORY = f"{LIBRARY}(C2PCFGS)"     # the dialog's own record of configurations
DEFAULT_NAME = "C2PDFL"                 # IBM's default configuration, copy it, never edit it
LAB_NAME = "GIBSON"
SYSLOG_TEST_DSN = "C2P.C2RSYSLG"        # "Write messages to C2RSYSLG DD"
STEPS = ("SET", "DES", "SEL", "VER", "REF")

# Lists the dialogs maintain as members, named as the product names them.
SENSREAD = f"{LIBRARY}(SENSREAD)"       # alert 1212, access >= READ
SENSUPDT = f"{LIBRARY}(SENSUPDT)"       # alert 1213, access >= UPDATE
EMERGNCY = f"{LIBRARY}(EMERGNCY)"       # alert 1102, emergency user ids
EMAILDST = f"{LIBRARY}(EMAILDST)"       # SE.A.E e-mail address lists

_NAME_RE = re.compile(r"^[A-Z@#$][A-Z0-9@#$]{0,5}$")


def valid_name(name: str) -> bool:
    return bool(_NAME_RE.match((name or "").upper()))


@dataclass
class AlertConfig:
    name: str
    desc: str = ""
    # General settings, with the product's defaults.
    interval: int = 60          # REPORT INTERVAL, seconds
    stage1: int = 60            # STAGE1INTERVAL, minutes (Environment refresh)
    average: int = 300          # AVERAGEINTERVAL, seconds
    bufsize: int = 1024         # OPTION BUFSIZE, KB
    numbufs: int = 2            # OPTION NUMBUFS
    extmon: bool = False        # Extended Monitoring
    retention: int = 24         # snapshot retention, hours
    forward: str = "ALERTS"     # SIEM forwarding: ALERTS or ALL SMF records
    # Destinations.
    wto: bool = True
    email: str = ""
    textmsg: str = ""
    snmp: str = ""
    syslog: bool = False
    syslog_addrs: str = ""
    syslog_transport: str = "UDP"
    syslog_format: str = "RFC3164"
    c2rsyslg: bool = False
    hec: bool = False
    hec_url: str = ""
    hec_index: str = "main"
    hec_sourcetype: str = "zos:zsecure:alert"
    hec_verify: bool = True
    cti: bool = True
    # Selection and custom alerts.
    selected: Set[int] = field(default_factory=set)
    custom: Dict[int, AlertDef] = field(default_factory=dict)
    status: Dict[str, str] = field(default_factory=lambda: {s: "Req" for s in STEPS})
    readonly: bool = False
    verified_at: str = ""
    refreshed_at: str = ""

    # ------------------------------------------------------------ status
    def mark(self, step: str) -> None:
        """Complete a step. Any change before Ver invalidates Ver and Ref."""
        self.status[step] = "OK"
        if step in ("SET", "DES", "SEL"):
            self.status["VER"] = "Req"
            self.status["REF"] = "Req"
        elif step == "VER":
            self.status["REF"] = "Req"

    def ready_to_verify(self) -> List[str]:
        return [s for s in ("SET", "DES", "SEL") if self.status.get(s) != "OK"]

    def alerts(self) -> List[AlertDef]:
        out = []
        for aid in sorted(self.selected):
            a = catalog.lookup(aid, self.custom)
            if a is not None:
                out.append(a)
        return out

    def all_alerts(self) -> List[AlertDef]:
        merged = {a.aid: a for a in catalog.PREDEFINED}
        merged.update(self.custom)
        return [merged[k] for k in sorted(merged)]

    def copy(self, name: str, desc: str = "") -> "AlertConfig":
        twin = AlertConfig(name=name.upper(), desc=desc or f"Copy of {self.name}")
        for attr in ("interval", "stage1", "average", "bufsize", "numbufs", "extmon",
                     "retention", "forward", "wto", "email", "textmsg", "snmp", "syslog",
                     "syslog_addrs", "syslog_transport", "syslog_format", "c2rsyslg",
                     "hec", "hec_url", "hec_index", "hec_sourcetype", "hec_verify", "cti"):
            setattr(twin, attr, getattr(self, attr))
        twin.selected = set(self.selected)
        twin.custom = {k: v.copy() for k, v in self.custom.items()}
        return twin


# ---------------------------------------------------------------- serialise
def _q(value: str) -> str:
    return "'" + str(value).replace("'", "''") + "'"


def _yn(flag: bool) -> str:
    return "YES" if flag else "NO"


def _custom_line(a: AlertDef) -> str:
    p = a.params
    keys = ("event", "result", "user", "resource", "addr", "service", "count", "within",
            "groupby", "distinct")
    parts = " ".join(f"{k.upper()}({_q(p.get(k, '*'))})" for k in keys)
    return (f"  CUSTOM {a.aid} SEV({a.severity}) TITLE({_q(a.title)}) "
            f"TEXT({_q(a.text)}) {parts}")


def config_statements(cfg: AlertConfig) -> List[str]:
    lines = [f"CONFIG {cfg.name}",
             f"  DESC({_q(cfg.desc)}) READONLY({_yn(cfg.readonly)})",
             f"  SET INTERVAL({cfg.interval}) STAGE1INTERVAL({cfg.stage1}) "
             f"AVERAGEINTERVAL({cfg.average}) BUFSIZE({cfg.bufsize}) NUMBUFS({cfg.numbufs}) "
             f"EXTMON({_yn(cfg.extmon)}) RETENTION({cfg.retention}) FORWARD({cfg.forward})",
             f"  DEST WTO({_yn(cfg.wto)}) EMAIL({_q(cfg.email)}) TEXTMSG({_q(cfg.textmsg)}) "
             f"SNMP({_q(cfg.snmp)}) CTI({_yn(cfg.cti)})",
             f"  SYSLOG ACTIVE({_yn(cfg.syslog)}) ADDR({_q(cfg.syslog_addrs)}) "
             f"TRANSPORT({cfg.syslog_transport}) FORMAT({cfg.syslog_format}) "
             f"C2RSYSLG({_yn(cfg.c2rsyslg)})",
             f"  HEC ACTIVE({_yn(cfg.hec)}) URL({_q(cfg.hec_url)}) INDEX({_q(cfg.hec_index)}) "
             f"SOURCETYPE({_q(cfg.hec_sourcetype)}) VERIFY({_yn(cfg.hec_verify)})",
             "  SELECT " + " ".join(str(a) for a in sorted(cfg.selected))]
    for aid in sorted(cfg.custom):
        lines.append(_custom_line(cfg.custom[aid]))
    lines.append("  STATUS " + " ".join(f"{s}({cfg.status.get(s, 'Req')})" for s in STEPS)
                 + f" VERIFIED({_q(cfg.verified_at)}) REFRESHED({_q(cfg.refreshed_at)})")
    lines.append("ENDCONFIG")
    return lines


_KV = re.compile(r"([A-Z0-9_]+)\(('(?:[^']|'')*'|[^)]*)\)")


def _kv(text: str) -> Dict[str, str]:
    out = {}
    for key, raw in _KV.findall(text):
        if raw.startswith("'") and raw.endswith("'") and len(raw) >= 2:
            raw = raw[1:-1].replace("''", "'")
        out[key.upper()] = raw
    return out


def _yes(v: str) -> bool:
    return str(v).strip().upper() in ("YES", "Y", "1", "TRUE")


def _int(v: str, default: int) -> int:
    try:
        return int(str(v).strip())
    except (TypeError, ValueError):
        return default


def parse_configs(text: str):
    """Return (configs by name, active name) from repository or P-member text."""
    configs: Dict[str, AlertConfig] = {}
    active = ""
    cur: Optional[AlertConfig] = None
    for raw in (text or "").splitlines():
        line = raw.strip()
        if not line or line.startswith("*"):
            continue
        word, _, rest = line.partition(" ")
        word = word.upper()
        if word == "ACTIVE":
            active = rest.strip().upper()
            continue
        if word == "CONFIG":
            cur = AlertConfig(name=rest.strip().upper())
            continue
        if word == "ENDCONFIG":
            if cur is not None:
                configs[cur.name] = cur
            cur = None
            continue
        if cur is None:
            continue
        kv = _kv(rest)
        if word == "DESC" or line.upper().startswith("DESC("):
            kv = _kv(line)
            cur.desc = kv.get("DESC", cur.desc)
            cur.readonly = _yes(kv.get("READONLY", "NO"))
        elif word == "SET":
            cur.interval = _int(kv.get("INTERVAL"), cur.interval)
            cur.stage1 = _int(kv.get("STAGE1INTERVAL"), cur.stage1)
            cur.average = _int(kv.get("AVERAGEINTERVAL"), cur.average)
            cur.bufsize = _int(kv.get("BUFSIZE"), cur.bufsize)
            cur.numbufs = _int(kv.get("NUMBUFS"), cur.numbufs)
            cur.extmon = _yes(kv.get("EXTMON", "NO"))
            cur.retention = _int(kv.get("RETENTION"), cur.retention)
            cur.forward = (kv.get("FORWARD") or "ALERTS").upper()
        elif word == "DEST":
            cur.wto = _yes(kv.get("WTO", "YES"))
            cur.email = kv.get("EMAIL", "")
            cur.textmsg = kv.get("TEXTMSG", "")
            cur.snmp = kv.get("SNMP", "")
            cur.cti = _yes(kv.get("CTI", "YES"))
        elif word == "SYSLOG":
            cur.syslog = _yes(kv.get("ACTIVE", "NO"))
            cur.syslog_addrs = kv.get("ADDR", "")
            cur.syslog_transport = (kv.get("TRANSPORT") or "UDP").upper()
            cur.syslog_format = (kv.get("FORMAT") or "RFC3164").upper()
            cur.c2rsyslg = _yes(kv.get("C2RSYSLG", "NO"))
        elif word == "HEC":
            cur.hec = _yes(kv.get("ACTIVE", "NO"))
            cur.hec_url = kv.get("URL", "")
            cur.hec_index = kv.get("INDEX", "main")
            cur.hec_sourcetype = kv.get("SOURCETYPE", "zos:zsecure:alert")
            cur.hec_verify = _yes(kv.get("VERIFY", "YES"))
        elif word == "SELECT":
            cur.selected = {int(t) for t in rest.split() if t.isdigit()}
        elif word == "CUSTOM":
            aid_text, _, tail = rest.partition(" ")
            if aid_text.isdigit():
                kv = _kv(tail)
                aid = int(aid_text)
                params = {k.lower(): kv.get(k, "*") for k in
                          ("EVENT", "RESULT", "USER", "RESOURCE", "ADDR", "SERVICE",
                           "COUNT", "WITHIN", "GROUPBY")}
                params["distinct"] = kv.get("DISTINCT", "")
                cur.custom[aid] = AlertDef(
                    aid, "INSTALL", kv.get("TITLE", f"Installation alert {aid}"),
                    (kv.get("SEV") or "W").upper()[:1], kv.get("TEXT", "Alert {aid}"),
                    "custom", catalog.custom_carla(params, aid), params, predefined=False)
        elif word == "STATUS":
            for s in STEPS:
                if s in kv:
                    cur.status[s] = "OK" if kv[s].upper() == "OK" else "Req"
            cur.verified_at = kv.get("VERIFIED", "")
            cur.refreshed_at = kv.get("REFRESHED", "")
    return configs, active


def repository_text(configs: Dict[str, AlertConfig], active: str) -> str:
    lines = ["* zSecure Alert configurations - maintained by the SE.A.A dialog",
             "* Edit through ISPF option SE.A.A, not by hand: the dialog tracks",
             "* which steps each configuration has completed."]
    for name in sorted(configs, key=lambda n: (n != DEFAULT_NAME, n)):
        lines += config_statements(configs[name])
    lines.append(f"ACTIVE {active}")
    return "\n".join(lines) + "\n"


# --------------------------------------------------------------- defaults
def default_config() -> AlertConfig:
    cfg = AlertConfig(name=DEFAULT_NAME, desc="IBM default configuration - copy before use",
                      readonly=True)
    cfg.selected = set(catalog.DEFAULT_SELECTED)
    cfg.status = {s: "OK" for s in STEPS}
    return cfg


def lab_config() -> AlertConfig:
    """GIBSON's configuration: a copy of C2PDFL customised the way a site would."""
    cfg = default_config().copy(LAB_NAME, "GIBSON lab alerting")
    cfg.interval = 10                    # a lab wants alerts in seconds, not a minute
    cfg.email = "IBMUSER"                # delivered to IBMUSER's Office Mail inbox (M.8)
    cfg.syslog = True
    cfg.syslog_addrs = "127.0.0.1:5514"
    cfg.c2rsyslg = True                  # write to C2P.C2RSYSLG until a SIEM is named
    cfg.hec_url = "https://127.0.0.1:8088/services/collector/event"
    cfg.selected = set(catalog.GIBSON_SELECTED)
    cfg.custom = {a.aid: a.copy() for a in catalog.INSTALLATION}
    cfg.status = {s: "OK" for s in STEPS}
    return cfg


DEFAULT_SENSREAD = ["* Alert 1212 - access >= READ on these data sets (generic masks allowed)",
                    "KEV.PW.TEXT", "IBMUSER.PAYROLL.**", "SYS1.RACF*.BACKUP"]
DEFAULT_SENSUPDT = ["* Alert 1213 - access >= UPDATE on these data sets",
                    "SYS1.PARMLIB", "SYS1.PROCLIB", "SYS1.UADS", "SYS1.LINKLIB",
                    "SYS1.LPALIB"]
DEFAULT_EMERGNCY = ["* Alert 1102 - emergency (break-glass) user ids, one per line",
                    "* None defined in this lab. Add one here, then verify and",
                    "* refresh the active configuration for it to take effect."]
DEFAULT_EMAILDST = ["* SE.A.E e-mail address lists: LIST name address,address,...",
                    "LIST SECADMIN IBMUSER"]


def member_lines(text: Optional[str]) -> List[str]:
    out = []
    for raw in (text or "").splitlines():
        s = raw.strip()
        if s and not s.startswith("*"):
            out.append(s.upper() if "@" not in s else s)
    return out


def dataset_match(mask: str, dsn: str) -> bool:
    """RACF-style generic match: * within a qualifier, ** across qualifiers."""
    mask = (mask or "").upper().strip("'")
    dsn = (dsn or "").upper().strip("'")
    if not mask or not dsn:
        return False
    pattern = ""
    i = 0
    while i < len(mask):
        if mask.startswith("**", i):
            pattern += ".*"
            i += 2
        elif mask[i] == "*":
            pattern += "[^.]*"
            i += 1
        elif mask[i] == "%":
            pattern += "[^.]"
            i += 1
        else:
            pattern += re.escape(mask[i])
            i += 1
    # 'A.B.**' also covers 'A.B' itself.
    if pattern.endswith(r"\..*"):
        pattern = pattern[:-4] + r"(\..*)?"
    return re.fullmatch(pattern, dsn) is not None


# --------------------------------------------------------- verify members
def _stamp() -> str:
    return datetime.now().strftime("%Y-%m-%d %H:%M:%S")


def verify_members(cfg: AlertConfig, env: Dict[str, List[str]]) -> Dict[str, str]:
    """The text of the V-suffixed members verification writes."""
    n = cfg.name
    hdr = [f"* {n}%s  zSecure Alert configuration {n} - generated by verify {_stamp()}"]
    vs = [hdr[0] % "VS", "* Stage one: environment collection, rerun every "
          f"{cfg.stage1} minutes (STAGE1INTERVAL)",
          "ALLOC TYPE=CKFREEZE DSN=C2P.CKFREEZE.C2PCOLL",
          "NEWLIST TYPE=RACF NAME=ENVUSERS NOPAGE",
          "  SELECT CLASS=USER",
          "  SORTLIST KEY SPECIAL OPERATIONS AUDITOR UID"]
    vo = [hdr[0] % "VO", "* Environment-dependent selection criteria"]
    for key in ("EMERGENCY", "UID0USERS", "APFLIST", "SENSREAD", "SENSUPDT"):
        vals = env.get(key, [])
        vo.append(f"DEFINE &{key} = (" + ",".join(vals) + ")" if vals else f"DEFINE &{key} = ()")
    v = [hdr[0] % "V", f"* Report: {len(cfg.selected)} alerts selected"]
    for a in cfg.alerts():
        v.append(f"* Alert {a.aid} {a.msgid} {a.title}")
        v.extend(a.carla)
    ve = [hdr[0] % "VE"]
    if cfg.extmon:
        ve += ["* Extended Monitoring: snapshot to CKFREEZE every "
               f"{cfg.stage1} minutes, retained {cfg.retention} hours"]
    else:
        ve += ["* Extended Monitoring is not active for this configuration"]
    vp = [hdr[0] % "VP", f"OPTION BUFSIZE={cfg.bufsize} NUMBUFS={cfg.numbufs}",
          f"REPORT INTERVAL={cfg.interval} STAGE1INTERVAL={cfg.stage1} "
          f"AVERAGEINTERVAL={cfg.average}"]
    vp += config_statements(cfg)
    return {f"{n}VS": "\n".join(vs), f"{n}VO": "\n".join(vo), f"{n}V": "\n".join(v),
            f"{n}VE": "\n".join(ve), f"{n}VP": "\n".join(vp)}


PROMOTION = (("VS", "S"), ("V", ""), ("VE", "E"), ("VP", "P"))
