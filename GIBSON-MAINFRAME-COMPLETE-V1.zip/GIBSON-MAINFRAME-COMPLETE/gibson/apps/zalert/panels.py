"""The SE and SE.A dialogs, as a learner meets them in ISPF.

Layout follows the product: SE.A offers A Alert, E E-mail, P PCI and
S Sensitive; SE.A.A lists configurations with the Set, Des, Sel, Ver, Ref and
Act columns and the line commands C D I E W S V F B; "/" on the command line
refreshes the started task. GIBSON adds T Tutorial, marked as its own, and a
tutorial bar along the bottom of every alert panel showing the next step of
the guided exercise.

Changing anything needs SPECIAL or AUDITOR, as update access to the
customisation library would on a real system. Everyone else may look.
"""
from __future__ import annotations

from typing import Dict, List, Optional, Tuple

from gibson.render import colors
from gibson.render.panels import PanelInput
from gibson.render.screen3270 import ScreenBuffer

from . import catalog, tutorial
from .catalog import AlertDef, CATEGORIES
from .config import (AlertConfig, DEFAULT_NAME, EMAILDST, EMERGNCY, LIBRARY, SENSREAD,
                     SENSUPDT, SYSLOG_TEST_DSN, valid_name)
from .destinations import ALLOW_ENV, hec_token, _allow_rules
from . import police as P

_TURQ = getattr(colors, "TURQUOISE", colors.GREEN)
_ZVER = "zSecure Suite 3.1.0"
_LIST_ROWS = 13          # rows available for list bodies above the tutorial bar


class AlertDialog:
    """Owns the SE screens. handle() returns None to go back to the main menu."""

    def __init__(self, state, userid: str):
        self.state = state
        self.userid = (userid or "IBMUSER").upper()
        self.screen = "SE"
        self.message = ""
        self.top = 0
        self.cur = ""                      # configuration being worked on
        self.copy_from = ""
        self.edit_aid = 0
        self.browse_title = ""
        self.browse_lines: List[str] = []
        self.browse_back = "SEAA"
        self.tutor_on = True
        self.tutor_ctx: dict = {}
        self.page = 0
        self._row_map: Dict[str, object] = {}
        self._sel_dirty = False

    # ------------------------------------------------------------- helpers
    def _can_update(self) -> bool:
        racf = getattr(self.state, "racf", None)
        u = (getattr(racf, "users", {}) or {}).get(self.userid)
        attrs = {str(a).upper() for a in (getattr(u, "attributes", []) or [])}
        return bool(attrs & {"SPECIAL", "AUDITOR"})

    def _deny(self) -> str:
        return (f"C2P0940E {self.userid} IS NOT AUTHORIZED TO UPDATE {LIBRARY} "
                "(SPECIAL OR AUDITOR REQUIRED)")

    def _load(self):
        return P.load(self.state)

    def _save(self, configs, active) -> None:
        P.save(self.state, configs, active)

    def _base(self, title: str, right: str = "") -> ScreenBuffer:
        s = ScreenBuffer()
        s.extended_attributes = True
        s.put(1, 2, f"{_ZVER}  -  {title}"[:62], colors.BLUE)
        if right:
            s.put(1, 79 - len(right[:16]), right[:16], colors.GREEN)
        return s

    def _cmdline(self, s: ScreenBuffer, label: str = "Command ===>") -> None:
        s.put(2, 2, label, colors.WHITE)
        s.add_field("CMD", 2, 3 + len(label), 79 - (4 + len(label)), colour=_TURQ,
                    role="command")
        s.set_cursor(2, 3 + len(label))

    def _msg(self, s: ScreenBuffer, row: int = 3) -> None:
        if self.message:
            colour = colors.RED if "E " in self.message[:10] else colors.YELLOW
            s.put(row, 2, self.message[:77], colour)

    def _tutor_bar(self, s: ScreenBuffer) -> None:
        if not self.tutor_on:
            s.put(22, 2, "Tutorial off - enter TUTOR ON to show the guided exercise",
                  colors.BLUE)
            return
        n, text = tutorial.current(self.state, self.tutor_ctx)
        s.put(20, 1, "-" * 79, colors.BLUE)
        head = f"TUTORIAL {n}/{len(tutorial.STEPS)}  "
        lines = tutorial.wrap(text, 77 - len(head))
        s.put(21, 2, head + (lines[0] if lines else ""), colors.YELLOW)
        for i, line in enumerate(lines[1:3]):
            s.put(22 + i, 2 + len(head), line, colors.YELLOW)

    def _pf(self, s: ScreenBuffer, legend: str) -> None:
        s.put(24, 1, legend[:79], colors.BLUE)

    def _common_command(self, cmd: str) -> Optional[ScreenBuffer]:
        u = cmd.strip().upper()
        if u in ("TUTOR", "TUTORIAL"):
            self.screen, self.page = "TUTOR", 0
            return self._tutor()
        if u == "TUTOR OFF":
            self.tutor_on = False
            self.message = "TUTORIAL BAR HIDDEN - TUTOR ON TO RESTORE"
        elif u == "TUTOR ON":
            self.tutor_on = True
            self.message = "TUTORIAL BAR SHOWN"
        return None

    def _yn(self, v: str, default: bool) -> bool:
        v = (v or "").strip().upper()
        if v in ("Y", "YES"):
            return True
        if v in ("N", "NO"):
            return False
        return default

    # ------------------------------------------------------------- entry
    def initial(self) -> ScreenBuffer:
        self.screen = "SE"
        return self._se()

    def start(self, path: str = "SE") -> ScreenBuffer:
        """Open at SE, SE.A, SE.A.A, SE.A.S and so on, as an ISPF jump would."""
        parts = [x for x in (path or "SE").upper().split(".") if x]
        if parts and parts[0] == "SE":
            parts = parts[1:]
        if not parts:
            return self.initial()
        if parts[0] == "1":
            self.screen = "SE"
            return self._h_se_option("1")
        if parts[0] != "A":
            self.screen = "SE"
            self.message = f"INVALID OPTION '{parts[0]}'  (1 A)"
            return self._se()
        self.screen = "SEA"
        if len(parts) >= 2:
            return self._h_sea_option(parts[1])
        return self._sea()

    # The ISPF session drives nested dialogs through initial_screen() and
    # handle(), the same protocol SDSF and SYSVIEW use.
    def initial_screen(self) -> ScreenBuffer:
        return self.start(getattr(self, "_start_path", "SE"))

    def handle(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        fn = getattr(self, f"_h_{self.screen.lower()}", None)
        if fn is None:
            self.screen = "SE"
            return self._se()
        return fn(pi)

    def redraw(self) -> ScreenBuffer:
        return getattr(self, f"_{self.screen.lower()}")()

    # ================================================================ SE
    def _se(self) -> ScreenBuffer:
        s = self._base("Setup", self.userid)
        s.put(3, 2, "Option ===>", colors.WHITE)
        s.add_field("OPTION", 3, 14, 20, colour=_TURQ, role="command")
        self._msg(s, 4)
        s.put(6, 2, "Select an option and press ENTER:", colors.GREEN)
        s.put(8, 5, "1   Input files   Input data sets (RACF / SMF / CKFREEZE)", _TURQ)
        s.put(9, 5, "A   Alert         zSecure Alert configuration", _TURQ)
        self._pf(s, "F3=Return")
        s.set_cursor(3, 14)
        return s

    def _h_se(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        self.message = ""
        if pi.key in ("PF3", "PF15"):
            return None
        opt = pi.stripped("OPTION").upper()
        if opt.startswith("A."):
            return self._jump(opt[2:])
        return self._h_se_option(opt)

    def _h_se_option(self, opt: str) -> ScreenBuffer:
        if opt == "1":
            from gibson.apps.zsecure_engine import zsecure_command
            return self._open_browse("Setup - input data sets",
                                     zsecure_command(self.state, self.userid, "ZSEC SETUP").split("\n"),
                                     back="SE")
        if opt == "A":
            self.screen = "SEA"
            return self._sea()
        if opt:
            self.message = f"INVALID OPTION '{opt}'  (1 A)"
        self.screen = "SE"
        return self._se()

    def _jump(self, rest: str) -> ScreenBuffer:
        self.screen = "SEA"
        return self._h_sea_option(rest.split(".")[0])

    # =============================================================== SE.A
    def _sea(self) -> ScreenBuffer:
        s = self._base("Setup - Alert", self.userid)
        s.put(3, 2, "Option ===>", colors.WHITE)
        s.add_field("OPTION", 3, 14, 20, colour=_TURQ, role="command")
        self._msg(s, 4)
        rows = [("A", "Alert", "Select and customize alerts"),
                ("E", "E-mail", "Configure e-mail address lists"),
                ("P", "PCI", "Configure PCI data sets, userids, and groups"),
                ("S", "Sensitive", "Configure sensitive resources, userids, and groups"),
                ("T", "Tutorial", "How it works on z/OS, and a guided exercise  (GIBSON)")]
        for i, (code, name, desc) in enumerate(rows):
            s.put(6 + i, 5, f"{code}   {name:<11} {desc}", _TURQ)
        pol = getattr(self.state, "c2police", None)
        if pol is not None and pol.running and pol.cfg is not None:
            line = (f"C2POLICE ACTIVE  configuration {pol.cfg.name}  interval "
                    f"{pol.cfg.interval}s  alerts issued {pol.alerts_issued}")
            s.put(13, 2, line, colors.GREEN)
        elif pol is not None and pol.running:
            s.put(13, 2, "C2POLICE ACTIVE but no configuration refreshed", colors.YELLOW)
        else:
            s.put(13, 2, "C2POLICE NOT ACTIVE  (S C2POLICE from the console)", colors.YELLOW)
        s.put(15, 2, "Operator: F C2POLICE,REFRESH  F C2POLICE,STATUS  F C2POLICE,COLLECT",
              colors.BLUE)
        self._tutor_bar(s)
        self._pf(s, "F3=Return   TUTOR=Tutorial   TUTOR OFF/ON=hide/show the exercise")
        s.set_cursor(3, 14)
        return s

    def _h_sea(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        self.message = ""
        if pi.key in ("PF3", "PF15"):
            self.screen = "SE"
            return self._se()
        opt = pi.stripped("OPTION").upper()
        common = self._common_command(opt)
        if common is not None:
            return common
        if opt.startswith("TUTOR"):
            return self._sea()
        return self._h_sea_option(opt)

    def _h_sea_option(self, opt: str) -> ScreenBuffer:
        if opt == "A":
            self.screen, self.top = "SEAA", 0
            return self._seaa()
        if opt == "E":
            self.screen = "SEAE"
            return self._seae()
        if opt == "P":
            self.screen = "SEAP"
            return self._seap()
        if opt == "S":
            self.screen = "SEAS"
            return self._seas()
        if opt == "T":
            self.screen, self.page = "TUTOR", 0
            return self._tutor()
        if opt:
            self.message = f"INVALID OPTION '{opt}'  (A E P S T)"
        self.screen = "SEA"
        return self._sea()

    # ============================================================== SE.A.A
    def _seaa(self) -> ScreenBuffer:
        configs, active = self._load()
        names = sorted(configs, key=lambda n: (n != DEFAULT_NAME, n))
        total = len(names)
        s = self._base("Alert - Configurations", f"Row {self.top+1} of {total}")
        self._cmdline(s)
        self._msg(s)
        s.put(4, 2, "C Copy D Delete I Insert E Edit W Where S Select V Verify "
                    "F Refresh B Browse", colors.GREEN)
        s.put(5, 2, "Primary: / or REFRESH = F C2POLICE,REFRESH   TUTOR = tutorial",
              colors.GREEN)
        s.put(7, 2, "    Name    Description                        Set Des Sel Ver Ref Act",
              colors.WHITE)
        self._row_map = {}
        for i, name in enumerate(names[self.top:self.top + _LIST_ROWS]):
            cfg = configs[name]
            row = 8 + i
            field = f"LC{i}"
            s.add_field(field, row, 2, 2, colour=_TURQ, role="entry")
            self._row_map[field] = name
            cols = " ".join(f"{cfg.status.get(st, 'Req'):<3}" for st in ("SET", "DES", "SEL",
                                                                          "VER", "REF"))
            act = "Yes" if name == active else ""
            colour = colors.YELLOW if "Req" in cols else _TURQ
            s.put(row, 6, f"{name:<7} {cfg.desc[:33]:<33}  {cols} {act}", colour)
        self._tutor_bar(s)
        self._pf(s, "F3=Return  F7=Up  F8=Down")
        return s

    def _h_seaa(self, pi: PanelInput) -> Optional[ScreenBuffer]:
        self.message = ""
        if pi.key in ("PF3", "PF15"):
            self.screen = "SEA"
            return self._sea()
        if pi.key in ("PF7", "PF19"):
            self.top = max(0, self.top - _LIST_ROWS)
            return self._seaa()
        if pi.key in ("PF8", "PF20"):
            configs, _ = self._load()
            self.top = min(max(0, len(configs) - _LIST_ROWS), self.top + _LIST_ROWS)
            return self._seaa()
        cmd = pi.stripped("CMD").upper()
        common = self._common_command(cmd)
        if common is not None:
            return common
        if cmd in ("/", "REFRESH"):
            out = P.modify_command(self.state, "C2POLICE", "REFRESH") or ""
            self.message = out.splitlines()[0] if out else "C2POLICE NOT ACTIVE"
            return self._seaa()
        for field, name in list(self._row_map.items()):
            lc = pi.stripped(field).upper()
            if lc:
                return self._line_command(lc[:1], str(name))
        return self._seaa()

    def _line_command(self, lc: str, name: str) -> ScreenBuffer:
        configs, active = self._load()
        cfg = configs.get(name)
        if cfg is None:
            self.message = f"C2P0920E {name} NOT FOUND"
            return self._seaa()
        if lc == "B":
            return self._browse_config(cfg)
        if lc not in "CDIEWSVF":
            self.message = f"INVALID LINE COMMAND '{lc}'"
            return self._seaa()
        if not self._can_update():
            self.message = self._deny()
            return self._seaa()
        if lc in ("C", "I"):
            self.copy_from = DEFAULT_NAME if lc == "I" else name
            self.screen = "COPY"
            return self._copy()
        if lc == "D":
            if cfg.readonly:
                self.message = "C2P0941E C2PDFL IS IBM'S DEFAULT AND CANNOT BE DELETED"
            elif name == active:
                self.message = f"C2P0942E {name} IS ACTIVE - REFRESH ANOTHER BEFORE DELETING IT"
            else:
                del configs[name]
                self._save(configs, active)
                self.message = f"C2P0943I CONFIGURATION {name} DELETED"
            return self._seaa()
        if cfg.readonly and lc in "EWS":
            self.message = ("C2P0921E C2PDFL IS IBM'S DEFAULT - COPY IT WITH C AND "
                            "CHANGE THE COPY")
            return self._seaa()
        self.cur = name
        if lc == "E":
            self.screen = "SETTINGS"
            return self._settings()
        if lc == "W":
            self.screen = "DEST"
            return self._dest()
        if lc == "S":
            self.screen, self.top_sel, self._sel_dirty = "SELECT", 0, False
            return self._select()
        if lc == "V":
            ok, msgs = P.verify(self.state, name)
            if not ok:
                self.message = msgs[0]
                return self._seaa()
            lines: List[str] = []
            for m in msgs:
                wrapped = tutorial.wrap(m, 77)
                lines.append(wrapped[0])
                lines.extend("         " + w for w in wrapped[1:])
            lines += ["", "Ver is now OK. Next: line command F to refresh, then / to "
                          "tell C2POLICE.", "", "F3 to return"]
            return self._open_browse(f"Verify {name}", lines, back="SEAA")
        if lc == "F":
            ok, msgs = P.refresh(self.state, name)
            if not ok:
                self.message = msgs[0]
            elif getattr(self.state, "c2police", None) is not None and self.state.c2police.running:
                self.message = (f"C2P0933I {name} IN PRODUCTION - ENTER / TO ISSUE "
                                "F C2POLICE,REFRESH")
            else:
                self.message = f"C2P0935W {name} IN PRODUCTION BUT C2POLICE IS NOT RUNNING"
            return self._seaa()
        return self._seaa()

    def _browse_config(self, cfg: AlertConfig) -> ScreenBuffer:
        lines = [f"Configuration {cfg.name}: {cfg.desc}", ""]
        for suffix in ("P", "", "S", "E", "VP", "V", "VS", "VO", "VE"):
            member = f"{cfg.name}{suffix}"
            text = P.read_member(self.state, f"{LIBRARY}({member})")
            if text:
                lines.append(f"===== {LIBRARY}({member}) =====")
                lines.extend(text.rstrip("\n").split("\n"))
                lines.append("")
        if len(lines) == 2:
            lines.append("No members yet - verify (V) generates them, refresh (F) promotes them.")
        return self._open_browse(f"Browse {cfg.name}", lines, back="SEAA")

    # ------------------------------------------------------------------ copy
    def _copy(self) -> ScreenBuffer:
        s = self._base("Alert - Copy configuration", self.userid)
        self._msg(s)
        s.put(5, 2, f"Copy {self.copy_from} to a new configuration", colors.GREEN)
        s.put(7, 4, "New name  . . .", colors.GREEN)
        s.add_field("NAME", 7, 21, 6, value=tutorial.TUTORIAL_CONFIG, colour=_TURQ)
        s.put(7, 29, "1 to 6 characters, so the member suffixes fit", colors.BLUE)
        s.put(8, 4, "Description . .", colors.GREEN)
        s.add_field("DESC", 8, 21, 40, value="My alert configuration", colour=_TURQ)
        s.put(10, 2, "ENTER to copy, F3 to cancel", colors.BLUE)
        self._tutor_bar(s)
        self._pf(s, "ENTER=Copy  F3=Cancel")
        s.set_cursor(7, 21)
        return s

    def _h_copy(self, pi: PanelInput) -> ScreenBuffer:
        self.message = ""
        if pi.key in ("PF3", "PF15"):
            self.screen = "SEAA"
            return self._seaa()
        name = pi.stripped("NAME").upper()
        desc = pi.stripped("DESC") or f"Copy of {self.copy_from}"
        if not valid_name(name):
            self.message = "C2P0944E NAME MUST BE 1-6 CHARACTERS, STARTING WITH A LETTER"
            return self._copy()
        configs, active = self._load()
        if name in configs:
            self.message = f"C2P0945E {name} ALREADY EXISTS"
            return self._copy()
        src = configs.get(self.copy_from)
        twin = src.copy(name, desc)
        configs[name] = twin
        self._save(configs, active)
        self.message = f"C2P0946I {self.copy_from} COPIED TO {name} - NOW E, W AND S, THEN V AND F"
        self.screen = "SEAA"
        return self._seaa()

    # -------------------------------------------------------- general settings
    def _settings(self) -> ScreenBuffer:
        configs, _ = self._load()
        c = configs[self.cur]
        s = self._base("Alert - General settings", f"Config {c.name}")
        self._msg(s)
        rows = [
            ("Description . . . . .", "DESC", 40, c.desc, ""),
            ("Interval  . . . . . .", "INTERVAL", 5, str(c.interval),
             "seconds   REPORT INTERVAL, default 60"),
            ("Environment refresh .", "STAGE1", 5, str(c.stage1),
             "minutes   STAGE1INTERVAL, default 60"),
            ("Average . . . . . . .", "AVERAGE", 5, str(c.average),
             "seconds   AVERAGEINTERVAL, default 300"),
            ("Buffer size . . . . .", "BUFSIZE", 5, str(c.bufsize), "KB        1 to 16384"),
            ("Number of buffers . .", "NUMBUFS", 5, str(c.numbufs), "          2 to 32"),
            ("Extended Monitoring .", "EXTMON", 1, "Y" if c.extmon else "N", "Y or N"),
            ("Snapshot retention  .", "RETAIN", 5, str(c.retention), "hours     1 to 99"),
            ("SIEM forwarding . . .", "FORWARD", 6, c.forward,
             "ALERTS, or ALL to send every SMF record"),
        ]
        for i, (label, key, width, value, hint) in enumerate(rows):
            r = 5 + i
            s.put(r, 2, label, colors.GREEN)
            s.add_field(key, r, 25, width, value=value, colour=_TURQ)
            if hint:
                s.put(r, 27 + width, hint, colors.BLUE)
        s.put(15, 2, "ENTER saves the settings and marks Set OK. Verify again afterwards.",
              colors.BLUE)
        self._tutor_bar(s)
        self._pf(s, "ENTER=Save  F3=Return")
        s.set_cursor(5, 25)
        return s

    def _h_settings(self, pi: PanelInput) -> ScreenBuffer:
        self.message = ""
        if pi.key in ("PF3", "PF15"):
            self.screen = "SEAA"
            return self._seaa()
        configs, active = self._load()
        c = configs[self.cur]

        def num(key, lo, hi, cur):
            raw = pi.stripped(key)
            try:
                v = int(raw)
            except ValueError:
                raise ValueError(f"C2P0947E {key} MUST BE A NUMBER")
            if not lo <= v <= hi:
                raise ValueError(f"C2P0948E {key} MUST BE {lo} TO {hi}")
            return v
        try:
            c.interval = num("INTERVAL", 1, 3600, c.interval)
            c.stage1 = num("STAGE1", 1, 1440, c.stage1)
            c.average = num("AVERAGE", 10, 86400, c.average)
            c.bufsize = num("BUFSIZE", 1, 16384, c.bufsize)
            c.numbufs = num("NUMBUFS", 2, 32, c.numbufs)
            c.retention = num("RETAIN", 1, 99, c.retention)
        except ValueError as exc:
            self.message = str(exc)
            return self._settings()
        fwd = pi.stripped("FORWARD").upper() or "ALERTS"
        if fwd not in ("ALERTS", "ALL"):
            self.message = "C2P0949E SIEM FORWARDING IS ALERTS OR ALL"
            return self._settings()
        c.forward = fwd
        c.desc = pi.stripped("DESC") or c.desc
        c.extmon = self._yn(pi.stripped("EXTMON"), c.extmon)
        c.mark("SET")
        self._save(configs, active)
        self.message = f"C2P0950I GENERAL SETTINGS FOR {c.name} SAVED - SET OK"
        self.screen = "SEAA"
        return self._seaa()

    # ------------------------------------------------------------ destinations
    def _dest(self) -> ScreenBuffer:
        configs, _ = self._load()
        c = configs[self.cur]
        s = self._base("Alert - Destinations", f"Config {c.name}")
        self._msg(s)
        yn = lambda b: "Y" if b else "N"

        def fld(row, label, key, width, value, col=24, hint=""):
            s.put(row, 2, label, colors.GREEN)
            s.add_field(key, row, col, width, value=value, colour=_TURQ)
            if hint:
                s.put(row, col + width + 2, hint, colors.BLUE)
        fld(4, "WTO . . . . . . . .", "WTO", 1, yn(c.wto), hint="console message C2Pnnnnx")
        fld(5, "CTI SENTRY  . . . .", "CTI", 1, yn(c.cti), hint="GIBSON CTI consoles (GIBSON)")
        fld(6, "E-mail  . . . . . .", "EMAIL", 50, c.email)
        fld(7, "Text message  . . .", "TEXTMSG", 50, c.textmsg)
        fld(8, "SNMP trap . . . . .", "SNMP", 20, c.snmp, hint="not supported here")
        fld(9, "UNIX syslog . . . .", "SYSLOG", 1, yn(c.syslog))
        s.put(9, 28, "Addresses", colors.GREEN)
        s.add_field("SYSADDR", 9, 39, 38, value=c.syslog_addrs, colour=_TURQ)
        fld(10, "  Transport . . . .", "TRANSPORT", 3, c.syslog_transport,
            hint="UDP or TCP")
        s.put(10, 43, "Format", colors.GREEN)
        s.add_field("FORMAT", 10, 51, 7, value=c.syslog_format, colour=_TURQ)
        s.put(10, 60, "RFC3164/RFC5424", colors.BLUE)
        fld(11, "  Write to C2RSYSLG", "C2RSYSLG", 1, yn(c.c2rsyslg),
            hint=f"Y = write {SYSLOG_TEST_DSN} instead of sending")
        fld(12, "Splunk HEC  . . . .", "HEC", 1, yn(c.hec))
        s.put(12, 28, "URL", colors.GREEN)
        s.add_field("HECURL", 12, 33, 45, value=c.hec_url, colour=_TURQ)
        s.put(13, 4, "Index", colors.GREEN)
        s.add_field("HECINDEX", 13, 11, 10, value=c.hec_index, colour=_TURQ)
        s.put(13, 23, "Sourcetype", colors.GREEN)
        s.add_field("HECST", 13, 35, 22, value=c.hec_sourcetype, colour=_TURQ)
        s.put(13, 59, "Verify TLS", colors.GREEN)
        s.add_field("HECVERIFY", 13, 71, 1, value=yn(c.hec_verify), colour=_TURQ)
        tok = "SET" if hec_token() else "NOT SET"
        s.put(14, 4, f"HEC token is held on the host in GIBSON_SIEM_HEC_TOKEN: {tok}",
              colors.YELLOW if tok == "NOT SET" else colors.GREEN)
        s.put(15, 4, f"Network destinations allowed by {ALLOW_ENV}: "
                     f"{','.join(_allow_rules())}"[:75], colors.BLUE)
        s.put(16, 4, "E-mail: userids or SE.A.E list names go to M.8 Office Mail; other "
                     "addresses", colors.BLUE)
        s.put(17, 4, "use the outbound relay, which is off unless enabled on the host.",
              colors.BLUE)
        self._tutor_bar(s)
        self._pf(s, "ENTER=Save  F3=Return")
        s.set_cursor(4, 24)
        return s

    def _h_dest(self, pi: PanelInput) -> ScreenBuffer:
        self.message = ""
        if pi.key in ("PF3", "PF15"):
            self.screen = "SEAA"
            return self._seaa()
        configs, active = self._load()
        c = configs[self.cur]
        transport = pi.stripped("TRANSPORT").upper() or "UDP"
        fmt = pi.stripped("FORMAT").upper() or "RFC3164"
        if transport not in ("UDP", "TCP"):
            self.message = "C2P0951E TRANSPORT IS UDP OR TCP"
            return self._dest()
        if fmt not in ("RFC3164", "RFC5424"):
            self.message = "C2P0952E FORMAT IS RFC3164 OR RFC5424"
            return self._dest()
        c.wto = self._yn(pi.stripped("WTO"), c.wto)
        c.cti = self._yn(pi.stripped("CTI"), c.cti)
        c.email = pi.stripped("EMAIL")
        c.textmsg = pi.stripped("TEXTMSG")
        c.snmp = pi.stripped("SNMP")
        c.syslog = self._yn(pi.stripped("SYSLOG"), c.syslog)
        c.syslog_addrs = pi.stripped("SYSADDR")
        c.syslog_transport, c.syslog_format = transport, fmt
        c.c2rsyslg = self._yn(pi.stripped("C2RSYSLG"), c.c2rsyslg)
        c.hec = self._yn(pi.stripped("HEC"), c.hec)
        c.hec_url = pi.stripped("HECURL")
        c.hec_index = pi.stripped("HECINDEX") or "main"
        c.hec_sourcetype = pi.stripped("HECST") or "zos:zsecure:alert"
        c.hec_verify = self._yn(pi.stripped("HECVERIFY"), c.hec_verify)
        if c.syslog and not c.c2rsyslg and not c.syslog_addrs:
            self.message = "C2P0953E UNIX SYSLOG NEEDS AT LEAST ONE ADDRESS, OR C2RSYSLG Y"
            return self._dest()
        c.mark("DES")
        self._save(configs, active)
        self.message = f"C2P0954I DESTINATIONS FOR {c.name} SAVED - DES OK"
        self.screen = "SEAA"
        return self._seaa()

    # --------------------------------------------------------------- selection
    def _sel_rows(self, c: AlertConfig) -> List[Tuple[str, object]]:
        rows: List[Tuple[str, object]] = []
        alerts = c.all_alerts()
        for cat, label in CATEGORIES:
            members = [a for a in alerts if a.category == cat]
            if not members:
                continue
            rows.append(("HDR", label))
            rows += [("ALERT", a) for a in members]
        return rows

    def _select(self) -> ScreenBuffer:
        configs, _ = self._load()
        c = configs[self.cur]
        rows = self._sel_rows(c)
        top = getattr(self, "top_sel", 0)
        s = self._base("Alert - Alert selection",
                       f"Row {top+1} of {len(rows)}")
        self._cmdline(s)
        self._msg(s)
        s.put(4, 2, f"Configuration {c.name}   S Select/deselect  B Browse CARLa", colors.GREEN)
        s.put(5, 2, "Installation alerts (4xxx): E Edit  D Delete  I Insert a new one",
              colors.GREEN)
        s.put(6, 2, "    Sel  Alert  Message   Description", colors.WHITE)
        self._row_map = {}
        for i, (kind, item) in enumerate(rows[top:top + _LIST_ROWS]):
            row = 7 + i
            if kind == "HDR":
                s.put(row, 6, f"--- {item} ---", colors.BLUE)
                continue
            a: AlertDef = item
            field = f"LC{i}"
            s.add_field(field, row, 2, 2, colour=_TURQ, role="entry")
            self._row_map[field] = a.aid
            sel = "Yes" if a.aid in c.selected else "   "
            colour = _TURQ if a.aid in c.selected else colors.GREEN
            s.put(row, 6, f"{sel}  {a.aid}   {a.msgid}  {a.title[:51]}", colour)
        self._tutor_bar(s)
        self._pf(s, "ENTER=Apply  F3=Save and return  F7=Up  F8=Down")
        return s

    def _h_select(self, pi: PanelInput) -> ScreenBuffer:
        self.message = ""
        configs, active = self._load()
        c = configs[self.cur]
        rows = self._sel_rows(c)
        top = getattr(self, "top_sel", 0)
        if pi.key in ("PF3", "PF15"):
            c.mark("SEL")
            self._save(configs, active)
            self.message = f"C2P0955I SELECTION FOR {c.name} SAVED - SEL OK ({len(c.selected)} ALERTS)"
            self.screen = "SEAA"
            return self._seaa()
        if pi.key in ("PF7", "PF19"):
            self.top_sel = max(0, top - _LIST_ROWS)
            return self._select()
        if pi.key in ("PF8", "PF20"):
            self.top_sel = min(max(0, len(rows) - _LIST_ROWS), top + _LIST_ROWS)
            return self._select()
        cmd = pi.stripped("CMD").upper()
        common = self._common_command(cmd)
        if common is not None:
            return common
        changed = 0
        for field, aid in list(self._row_map.items()):
            lc = pi.stripped(field).upper()[:1]
            if not lc:
                continue
            a = catalog.lookup(int(aid), c.custom)
            if lc == "S":
                if aid in c.selected:
                    c.selected.discard(aid)
                else:
                    c.selected.add(aid)
                changed += 1
            elif lc == "B":
                return self._open_browse(f"Alert {aid} {a.msgid}",
                                         [a.title, "", "CARLa:"] + list(a.carla) +
                                         ["", f"Message text: {a.text}"], back="SELECT")
            elif lc in ("E", "D", "I"):
                if lc == "I":
                    self.edit_aid = 0
                    self.screen = "CUSTOM"
                    return self._custom()
                if a is None or a.predefined:
                    self.message = (f"C2P0956E {aid} IS AN IBM PREDEFINED ALERT - ONLY "
                                    "4xxx ALERTS CAN BE EDITED OR DELETED")
                    return self._select()
                if lc == "D":
                    c.custom.pop(aid, None)
                    c.selected.discard(aid)
                    changed += 1
                else:
                    self.edit_aid = aid
                    self.screen = "CUSTOM"
                    return self._custom()
            else:
                self.message = f"INVALID LINE COMMAND '{lc}'"
        if changed:
            if not self._can_update():
                self.message = self._deny()
                return self._select()
            c.status["VER"] = c.status["REF"] = "Req"
            self._save(configs, active)
            self.message = f"{changed} CHANGE(S) APPLIED - F3 TO SAVE THE SELECTION"
        return self._select()

    # ---------------------------------------------------------- custom alert
    def _custom(self) -> ScreenBuffer:
        configs, _ = self._load()
        c = configs[self.cur]
        a = c.custom.get(self.edit_aid)
        if a is None:
            nxt = max([4000] + [k for k in c.custom if 4000 <= k <= 4999]) + 1
            a = AlertDef(nxt, "INSTALL", "", "W", "Alert {aid} for {user} from {addr}",
                         "custom", (), {"event": "LOGON", "result": "*", "user": "*",
                                        "resource": "*", "addr": "*", "service": "*",
                                        "count": "1", "within": "0", "groupby": "NONE",
                                        "distinct": ""}, predefined=False)
        p = a.params
        s = self._base("Alert - Installation-defined alert", f"Config {c.name}")
        self._msg(s)
        s.put(4, 2, "Number  . .", colors.GREEN)
        s.add_field("AID", 4, 14, 4, value=str(a.aid), colour=_TURQ)
        s.put(4, 20, "4000-4999", colors.BLUE)
        s.put(4, 32, "Severity", colors.GREEN)
        s.add_field("SEV", 4, 42, 1, value=a.severity, colour=_TURQ)
        s.put(4, 45, "I W E A", colors.BLUE)
        s.put(5, 2, "Title . . .", colors.GREEN)
        s.add_field("TITLE", 5, 14, 50, value=a.title, colour=_TURQ)
        s.put(6, 2, "Message . .", colors.GREEN)
        s.add_field("TEXT", 6, 14, 64, value=a.text, colour=_TURQ)
        s.put(7, 14, "{user} {addr} {resource} {count} {window} {service} {detail}",
              colors.BLUE)
        fields = [("Event . . .", "EVENT", 30, "event", "LOGON, CONNECT, DATASET ACCESS"),
                  ("Result  . .", "RESULT", 8, "result", "SUCCESS, FAILURE or *"),
                  ("User  . . .", "USER", 30, "user", "masks, comma separated"),
                  ("Resource  .", "RESOURCE", 30, "resource", "data set or profile masks"),
                  ("Address . .", "ADDR", 30, "addr", "masks or CIDR, 10.0.0.0/8"),
                  ("Service . .", "SERVICE", 12, "service", "TSO, SMTP, FTP ...")]
        for i, (label, key, width, pk, hint) in enumerate(fields):
            r = 8 + i
            s.put(r, 2, label, colors.GREEN)
            s.add_field(key, r, 14, width, value=p.get(pk, "*"), colour=_TURQ)
            s.put(r, 16 + width, hint, colors.BLUE)
        s.put(14, 2, "Count", colors.GREEN)
        s.add_field("COUNT", 14, 8, 4, value=p.get("count", "1"), colour=_TURQ)
        s.put(14, 14, "within", colors.GREEN)
        s.add_field("WITHIN", 14, 21, 5, value=p.get("within", "0"), colour=_TURQ)
        s.put(14, 28, "secs  group by", colors.GREEN)
        s.add_field("GROUPBY", 14, 43, 8, value=p.get("groupby", "NONE"), colour=_TURQ)
        s.put(14, 53, "distinct", colors.GREEN)
        s.add_field("DISTINCT", 14, 62, 8, value=p.get("distinct", ""), colour=_TURQ)
        s.put(15, 2, "CARLa:", colors.WHITE)
        for i, line in enumerate(catalog.custom_carla(p, a.aid)[:3]):
            s.put(16 + i, 4, line[:74], colors.TURQUOISE)
        self._tutor_bar(s)
        self._pf(s, "ENTER=Save  F3=Cancel   Count 1 = alert on every match")
        s.set_cursor(5, 14)
        return s

    def _h_custom(self, pi: PanelInput) -> ScreenBuffer:
        self.message = ""
        if pi.key in ("PF3", "PF15"):
            self.screen = "SELECT"
            return self._select()
        if not self._can_update():
            self.message = self._deny()
            return self._custom()
        configs, active = self._load()
        c = configs[self.cur]
        try:
            aid = int(pi.stripped("AID"))
        except ValueError:
            aid = 0
        if not 4000 <= aid <= 4999:
            self.message = "C2P0957E INSTALLATION ALERTS ARE NUMBERED 4000 TO 4999"
            return self._custom()
        if aid != self.edit_aid and aid in c.custom:
            self.message = f"C2P0958E ALERT {aid} ALREADY EXISTS"
            return self._custom()
        sev = (pi.stripped("SEV").upper() or "W")[:1]
        if sev not in "IWEA":
            self.message = "C2P0959E SEVERITY IS I, W, E OR A"
            return self._custom()
        title = pi.stripped("TITLE")
        if not title:
            self.message = "C2P0960E GIVE THE ALERT A TITLE"
            return self._custom()
        params = {k: (pi.stripped(k.upper()) or "*") for k in
                  ("event", "result", "user", "resource", "addr", "service")}
        for k, default in (("count", "1"), ("within", "0")):
            v = pi.stripped(k.upper()) or default
            if not v.isdigit():
                self.message = f"C2P0961E {k.upper()} MUST BE A NUMBER"
                return self._custom()
            params[k] = v
        params["groupby"] = (pi.stripped("GROUPBY").upper() or "NONE")
        if params["groupby"] not in ("NONE", "ADDR", "USER", "RESOURCE"):
            self.message = "C2P0962E GROUP BY IS NONE, ADDR, USER OR RESOURCE"
            return self._custom()
        params["distinct"] = pi.stripped("DISTINCT").upper()
        if self.edit_aid and self.edit_aid != aid:
            c.custom.pop(self.edit_aid, None)
            c.selected.discard(self.edit_aid)
        c.custom[aid] = AlertDef(aid, "INSTALL", title, sev,
                                 pi.stripped("TEXT") or title, "custom",
                                 catalog.custom_carla(params, aid), params, predefined=False)
        c.selected.add(aid)
        c.status["VER"] = c.status["REF"] = "Req"
        self._save(configs, active)
        self.message = f"C2P0963I ALERT {aid} SAVED AND SELECTED - VERIFY AND REFRESH {c.name}"
        self.screen = "SELECT"
        return self._select()

    # ----------------------------------------------------------- SE.A.E mail
    def _seae(self) -> ScreenBuffer:
        text = P.read_member(self.state, EMAILDST)
        lists = [l for l in text.splitlines() if l.strip().upper().startswith("LIST ")]
        s = self._base("Alert - E-mail address lists", self.userid)
        self._msg(s)
        s.put(4, 2, f"Stored in {EMAILDST}. Use a list name as an e-mail destination.",
              colors.GREEN)
        s.put(6, 2, "Name      Addresses (userids for M.8, or name@domain)", colors.WHITE)
        for i in range(10):
            name, addrs = "", ""
            if i < len(lists):
                parts = lists[i].split(None, 2)
                name = parts[1] if len(parts) > 1 else ""
                addrs = parts[2] if len(parts) > 2 else ""
            s.add_field(f"N{i}", 7 + i, 2, 8, value=name, colour=_TURQ)
            s.add_field(f"A{i}", 7 + i, 12, 66, value=addrs, colour=_TURQ)
        self._tutor_bar(s)
        self._pf(s, "ENTER=Save  F3=Return")
        s.set_cursor(7, 2)
        return s

    def _h_seae(self, pi: PanelInput) -> ScreenBuffer:
        self.message = ""
        if pi.key in ("PF3", "PF15"):
            self.screen = "SEA"
            return self._sea()
        if not self._can_update():
            self.message = self._deny()
            return self._seae()
        lines = ["* SE.A.E e-mail address lists: LIST name address,address,..."]
        for i in range(10):
            name = pi.stripped(f"N{i}").upper()
            addrs = pi.stripped(f"A{i}")
            if name and addrs:
                lines.append(f"LIST {name} {addrs}")
        P.write_member(self.state, EMAILDST, "\n".join(lines) + "\n")
        self.message = f"C2P0964I {len(lines) - 1} E-MAIL LIST(S) SAVED"
        return self._seae()

    # ------------------------------------------------------------ SE.A.P PCI
    def _seap(self) -> ScreenBuffer:
        s = self._base("Alert - PCI data sets", self.userid)
        lines = [
            "PCI alerts 1209 to 1211 fire on non-regular access to data sets holding",
            "card numbers (PAN) and authentication data, by anyone other than the",
            "userids and groups defined here. The product keeps these in members such",
            "as PCIPAN, PCIPANCL and PCIAUTH.",
            "",
            "This lab holds no card data, so no PCI data sets are defined and alerts",
            "1209 to 1211 are not offered. The same pattern is available for any",
            "data you choose to treat as sensitive: see option S, where SENSREAD and",
            "SENSUPDT drive alerts 1212 and 1213.",
        ]
        for i, line in enumerate(lines):
            s.put(4 + i, 2, line, colors.GREEN)
        self._tutor_bar(s)
        self._pf(s, "F3=Return")
        return s

    def _h_seap(self, pi: PanelInput) -> ScreenBuffer:
        self.screen = "SEA"
        return self._sea()

    # ------------------------------------------------------- SE.A.S sensitive
    def _seas(self) -> ScreenBuffer:
        s = self._base("Alert - Sensitive resources", self.userid)
        self._msg(s)
        blocks = [("SENSREAD", SENSREAD, "1212 access >= READ", 5),
                  ("SENSUPDT", SENSUPDT, "1213 access >= UPDATE", 5),
                  ("EMERGNCY", EMERGNCY, "1102 emergency user ids", 3)]
        row = 3
        for tag, dsn, what, n in blocks:
            vals = [l for l in P.read_member(self.state, dsn).splitlines()
                    if l.strip() and not l.strip().startswith("*")]
            s.put(row, 2, f"{tag:<9}{what:<26}{dsn}", colors.WHITE)
            row += 1
            for i in range(n):
                s.add_field(f"{tag}{i}", row, 4 + (i % 2) * 38, 36,
                            value=vals[i] if i < len(vals) else "", colour=_TURQ)
                if i % 2 == 1 or i == n - 1:
                    row += 1
        s.put(row, 2, "Generic masks allowed (*, **, %). Takes effect at the next "
                      "environment", colors.BLUE)
        s.put(row + 1, 2, "refresh, on F C2POLICE,COLLECT, or on F C2POLICE,REFRESH.",
              colors.BLUE)
        self._tutor_bar(s)
        self._pf(s, "ENTER=Save  F3=Return")
        s.set_cursor(4, 4)
        return s

    def _h_seas(self, pi: PanelInput) -> ScreenBuffer:
        self.message = ""
        if pi.key in ("PF3", "PF15"):
            self.screen = "SEA"
            return self._sea()
        if not self._can_update():
            self.message = self._deny()
            return self._seas()
        heads = {"SENSREAD": "* Alert 1212 - access >= READ on these data sets",
                 "SENSUPDT": "* Alert 1213 - access >= UPDATE on these data sets",
                 "EMERGNCY": "* Alert 1102 - emergency (break-glass) user ids"}
        for tag, dsn, n in (("SENSREAD", SENSREAD, 5), ("SENSUPDT", SENSUPDT, 5),
                            ("EMERGNCY", EMERGNCY, 3)):
            vals = [pi.stripped(f"{tag}{i}").upper().strip("'") for i in range(n)]
            P.write_member(self.state, dsn, "\n".join([heads[tag]] + [v for v in vals if v]) + "\n")
        self.message = "C2P0965I SENSITIVE LISTS SAVED - F C2POLICE,COLLECT TO APPLY NOW"
        return self._seas()

    # ------------------------------------------------------------ browse
    def _open_browse(self, title: str, lines: List[str], back: str = "SEAA",
                     message: str = "") -> ScreenBuffer:
        self.browse_title, self.browse_lines, self.browse_back = title, lines, back
        self.top = 0
        self.message = message
        self.screen = "BROWSE"
        return self._browse()

    def _browse(self) -> ScreenBuffer:
        total = len(self.browse_lines)
        s = self._base(self.browse_title, f"Line {self.top+1} of {total}")
        self._cmdline(s)
        self._msg(s)
        for i, line in enumerate(self.browse_lines[self.top:self.top + 19]):
            s.put(4 + i, 1, line[:79], _TURQ)
        self._pf(s, "F3=Return  F7=Up  F8=Down")
        return s

    def _h_browse(self, pi: PanelInput) -> ScreenBuffer:
        if pi.key in ("PF3", "PF15"):
            self.message = ""
            self.screen = self.browse_back
            self.top = 0
            return self.redraw()
        if pi.key in ("PF8", "PF20"):
            self.top = min(max(0, len(self.browse_lines) - 19), self.top + 18)
        elif pi.key in ("PF7", "PF19"):
            self.top = max(0, self.top - 18)
        return self._browse()

    # ----------------------------------------------------------- tutorial
    def _tutor(self) -> ScreenBuffer:
        pages = len(tutorial.PAGES) + 1
        p = max(0, min(self.page, pages - 1))
        s = self._base("Alert - Tutorial", f"Page {p+1} of {pages}")
        self._cmdline(s)
        if p < len(tutorial.PAGES):
            title, lines = tutorial.PAGES[p]
            s.put(3, 2, title, colors.WHITE)
            for i, line in enumerate(lines[:18]):
                s.put(5 + i, 2, line[:77], colors.GREEN)
        else:
            s.put(3, 2, "Guided exercise - progress is checked against the system",
                  colors.WHITE)
            row = 5
            for line in tutorial.progress_lines(self.state, self.tutor_ctx):
                for j, part in enumerate(tutorial.wrap(line, 76)[:3]):
                    if row > 22:
                        break
                    colour = (colors.GREEN if line.startswith("DONE")
                              else colors.YELLOW if line.startswith("NEXT") else _TURQ)
                    s.put(row, 2 if j == 0 else 11, part, colour)
                    row += 1
        self._pf(s, "F3=Return  F7=Previous page  F8=Next page")
        return s

    def _h_tutor(self, pi: PanelInput) -> ScreenBuffer:
        pages = len(tutorial.PAGES) + 1
        if pi.key in ("PF3", "PF15"):
            self.screen = "SEA"
            return self._sea()
        if pi.key in ("PF8", "PF20", "ENTER") and self.page < pages - 1:
            self.page += 1
        elif pi.key in ("PF7", "PF19"):
            self.page = max(0, self.page - 1)
        return self._tutor()
