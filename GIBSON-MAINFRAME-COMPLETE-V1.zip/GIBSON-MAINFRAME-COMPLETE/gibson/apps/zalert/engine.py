"""Matching SMF records against the selected alerts.

zSecure Alert reads SMF as it is written and evaluates its selections every
reporting interval; that is what this does with GIBSON's audit trail, which is
GIBSON's SMF. Two properties of that trail shape the code.

First, one logical event is often written more than once. A logon writes its
SMF 80 record twice with different trailers, and a SETROPTS three times. Left
alone, every alert would fire in duplicate or triplicate, so records are
collapsed on what happened (who, what, to what, from where) within a couple of
seconds, ignoring the trailer.

Second, a logon also writes GEO LOGON and GEO CONNECTION records. Logon alerts
read the plain LOGON record only, so a logon is one logon; connection counting
reads the connection records, so a scan is counted in ports, not in the
paperwork each probe generates.
"""
from __future__ import annotations

import fnmatch
import ipaddress
import re
import time
from collections import defaultdict, deque
from dataclasses import dataclass, field
from datetime import datetime
from typing import Deque, Dict, Iterable, List, Optional, Set, Tuple

from .catalog import AlertDef
from .config import AlertConfig, dataset_match

_LINE = re.compile(r"^(\S+)\s+(\S+)\s+([^:]+):\s+(.*?)\s+=>\s*(.*?)(?:\s+\[(.*)\])?$")
_KV = re.compile(r"([A-Z0-9_]+)=([^\]\s]+)")
_SRCIP = re.compile(r"\bSRCIP=([0-9A-Fa-f.:]+)")
_PORT = re.compile(r"\bPORT=(\d+)")
_DSN = re.compile(r"\bDATASET=(\S+)")
_ACCESS = re.compile(r"\bACCESS=(\S+)")
_UACC = re.compile(r"\bUACC\((\w+)\)", re.I)
_PROFILE_IN_CMD = re.compile(r"^(?:ADDSD|ALTDSD)\s+'?([^'\s]+)'?", re.I)
_SETROPTS = re.compile(r"SETROPTS\s+(.+?)(?:\s+RESULT=|$)", re.I)
_CLASSACT = re.compile(r"\b(NO)?CLASSACT\(([^)]*)\)", re.I)

_ACCESS_RANK = {"NONE": 0, "EXECUTE": 1, "READ": 2, "UPDATE": 3, "CONTROL": 4, "ALTER": 5}
_ADMIN_EVENTS = {"ALTUSER", "USER ALTER", "ADDUSER", "DELUSER", "PERMIT CHANGE",
                 "PROFILE DEFINE", "PROFILE ALTER", "GROUP ADMIN", "SETROPTS"}
_FAIL_WORDS = ("FAILURE", "FAILED", "VIOLATION", "DENIED")
SELF = "C2POLICE"


@dataclass
class SmfRecord:
    ts: str
    epoch: float
    smftype: str        # 80, 30, 119 ...
    user: str
    event: str          # LOGON, DATASET ACCESS, ALTUSER, GEO CONNECTION ...
    outcome: str        # SUCCESS, FAILURE ...
    detail: str         # the rest of the result field
    addr: str
    port: str
    service: str
    resource: str
    access: str
    extra: Dict[str, str]
    raw: str
    sig: str = ""           # which writer produced this line, from its trailer

    @property
    def failed(self) -> bool:
        text = f"{self.outcome} {self.extra.get('RESULT', '')}".upper()
        return any(w in text for w in _FAIL_WORDS) or "INSUFFICIENT" in self.detail.upper()

    def key(self) -> Tuple:
        subject = self.detail
        if self.event == "SETROPTS":
            m = _SETROPTS.search(self.detail)
            subject = m.group(1).strip() if m else self.detail
        elif self.event in ("PERMIT CHANGE", "PROFILE DEFINE", "PROFILE ALTER", "GROUP ADMIN"):
            subject = self.detail.split(" RESULT=")[0]
        elif self.event == "DATASET ACCESS":
            subject = f"{self.resource} {self.access}"
        return (self.user, self.event, self.outcome, self.addr, subject[:80])


def _epoch(ts: str) -> float:
    try:
        return datetime.fromisoformat(ts).timestamp()
    except (TypeError, ValueError):
        return time.time()


def parse_line(line: str) -> Optional[SmfRecord]:
    raw = (line or "").rstrip("\n")
    m = _LINE.match(raw)
    if not m:
        return None
    ts, comp, user, cmd, result, extra_text = m.groups()
    extra = {k.upper(): v for k, v in _KV.findall(extra_text or "")}
    smftype = re.sub(r"\D", "", comp) or ""
    event = re.sub(r"^SMF TYPE \d+\s+", "", cmd.strip(), flags=re.I).upper()
    words = (result or "").split(None, 1)
    outcome, detail = ("", result or "")
    if words and "=" not in words[0]:
        outcome = words[0].upper()
        detail = words[1] if len(words) > 1 else ""
    addr = extra.get("ADDR", "")
    if not addr:
        mm = _SRCIP.search(result or "")
        addr = mm.group(1) if mm else extra.get("SRCIP", "")
    pm = _PORT.search(result or "")
    port = pm.group(1) if pm else extra.get("PORT", "")
    if port == "0":
        port = ""
    service = extra.get("SERVICE", extra.get("APPL", ""))
    resource = extra.get("RESOURCE", "")
    dm = _DSN.search(result or "")
    if dm:
        resource = dm.group(1)
    am = _ACCESS.search(result or "")
    access = am.group(1).upper() if am else extra.get("ACCESS_REQUESTED", "").upper()
    first_key = (re.match(r"\s*([A-Z0-9_]+)=", extra_text or "") or [None, ""])[1]
    sig = f"{first_key}|{'CMD' if 'COMMAND=' in (result or '') else ''}"
    return SmfRecord(ts, _epoch(ts), smftype, user.strip().upper(), event, outcome,
                     detail.strip(), addr, port, service.upper(), resource.upper(), access,
                     extra, raw, sig)


@dataclass
class Fired:
    alert: AlertDef
    text: str
    record: SmfRecord
    user: str
    addr: str
    resource: str
    when: float = field(default_factory=time.time)

    @property
    def msgid(self) -> str:
        return self.alert.msgid

    @property
    def wto(self) -> str:
        return f"{self.alert.msgid} {self.text}"


@dataclass
class Environment:
    """Stage-one data: refreshed every Environment refresh interval."""
    users: Set[str] = field(default_factory=set)
    uid0: Set[str] = field(default_factory=set)
    emergency: Set[str] = field(default_factory=set)
    apf: List[str] = field(default_factory=list)
    sensread: List[str] = field(default_factory=list)
    sensupdt: List[str] = field(default_factory=list)


def _mask_match(masks: str, value: str) -> bool:
    masks = (masks or "*").strip()
    if masks in ("", "*"):
        return True
    value = (value or "").upper()
    for mask in (m.strip().upper() for m in masks.split(",") if m.strip()):
        if "/" in mask:
            try:
                if value and ipaddress.ip_address(value) in ipaddress.ip_network(mask, strict=False):
                    return True
            except ValueError:
                pass
            continue
        if fnmatch.fnmatchcase(value, mask.replace("%", "?")):
            return True
    return False


def _event_match(wanted: str, event: str) -> bool:
    wanted = (wanted or "*").strip()
    if wanted in ("", "*"):
        return True
    ev = event.replace("_", " ").upper()
    for w in (x.strip().replace("_", " ").upper() for x in wanted.split(",") if x.strip()):
        if ev == w or ev.endswith(" " + w):
            return True
    return False


def _fmt(alert: AlertDef, **values) -> str:
    values.setdefault("aid", alert.aid)
    for k in ("user", "addr", "resource", "detail", "service"):
        if not values.get(k):
            values[k] = "unknown" if k == "addr" else "-"
    try:
        return alert.text.format(**values)
    except (KeyError, IndexError, ValueError):
        return alert.title


class Engine:
    """Evaluates records against one refreshed configuration."""

    DEDUPE_SECONDS = 2.0

    def __init__(self, cfg: AlertConfig, env: Optional[Environment] = None):
        self.cfg = cfg
        self.env = env or Environment()
        self._recent: Dict[Tuple, tuple] = {}
        self._windows: Dict[Tuple, Deque] = defaultdict(deque)
        self._cooldown: Dict[Tuple, float] = {}
        self.records_seen = 0
        self.records_dropped_as_duplicate = 0

    # ---------------------------------------------------------------- dedupe
    def _duplicate(self, rec: SmfRecord) -> bool:
        """Is this line another copy of an event already counted?

        A time window alone cannot answer that. One logon writes two lines a
        few milliseconds apart, and five password guesses fired as fast as a
        tool can manage are five events, also milliseconds apart; a window wide
        enough to swallow the copies swallows the guesses too, and alert 1111
        then never sees its five. What does separate them is who wrote the
        line: each copy of one event comes from a different writer and carries
        a differently shaped trailer, while a repeated event repeats the same
        shapes. So a line opens a new event instance unless it matches an open
        instance with a writer that instance has not yet heard from.
        """
        k = rec.key()
        inst = self._recent.get(k)
        if inst is not None:
            started, sigs = inst
            if rec.epoch - started <= self.DEDUPE_SECONDS and rec.sig not in sigs:
                sigs.add(rec.sig)
                return True
        self._recent[k] = (rec.epoch, {rec.sig})
        if len(self._recent) > 5000:
            cutoff = rec.epoch - 30
            self._recent = {kk: v for kk, v in self._recent.items() if v[0] >= cutoff}
        return False

    # ------------------------------------------------------------ windowing
    def _window(self, key: Tuple, rec: SmfRecord, count: int, within: int,
                distinct: str = "") -> Optional[int]:
        """Add rec to a sliding window; return the count when the threshold trips."""
        dq = self._windows[key]
        tag = ""
        if distinct == "PORT":
            tag = rec.port or rec.service or rec.event
        elif distinct == "RESOURCE":
            tag = rec.resource
        elif distinct == "USER":
            tag = rec.user
        dq.append((rec.epoch, tag))
        while dq and rec.epoch - dq[0][0] > within:
            dq.popleft()
        n = len({t for _e, t in dq}) if distinct else len(dq)
        if n < count:
            return None
        if rec.epoch < self._cooldown.get(key, 0):
            return None
        self._cooldown[key] = rec.epoch + within
        dq.clear()
        return n

    @staticmethod
    def _window_text(seconds: int) -> str:
        if seconds and seconds % 60 == 0:
            m = seconds // 60
            return f"{m} minute" + ("s" if m != 1 else "")
        return f"{seconds} seconds"

    # --------------------------------------------------------------- matching
    def feed(self, records: Iterable[SmfRecord]) -> List[Fired]:
        fired: List[Fired] = []
        for rec in records:
            if rec is None or rec.user == SELF:
                continue
            self.records_seen += 1
            if self._duplicate(rec):
                self.records_dropped_as_duplicate += 1
                continue
            for alert in self.cfg.alerts():
                hit = self._match(alert, rec)
                if hit is not None:
                    fired.append(hit)
        return fired

    def _match(self, a: AlertDef, r: SmfRecord) -> Optional[Fired]:
        k = a.kind
        env = self.env
        is_logon = r.event == "LOGON"
        ok = r.outcome == "SUCCESS"

        def hit(text_values=None, *, resource=None, user=None):
            vals = {"user": r.user if user is None else user, "addr": r.addr,
                    "resource": r.resource if resource is None else resource,
                    "detail": r.detail[:60], "service": r.service}
            vals.update(text_values or {})
            return Fired(a, _fmt(a, **vals), r, vals["user"], r.addr, vals["resource"])

        if k == "logon_unknown":
            if is_logon and not ok:
                unknown = any(w in r.detail.upper() for w in
                              ("NOT FOUND", "NOT RACF-DEFINED", "NOT DEFINED", "UNKNOWN USER"))
                if unknown or (env.users and r.user not in env.users):
                    return hit()
            return None
        if k == "logon_emergency":
            return hit() if is_logon and ok and r.user in env.emergency else None
        if k == "logon_uid0":
            return hit() if is_logon and ok and r.user in env.uid0 else None
        if k in ("auth_granted", "auth_removed"):
            if r.event not in ("ALTUSER", "USER ALTER") or not ok:
                return None
            changes = r.detail.upper()
            target = r.extra.get("USER") or (re.search(r"\bUSER=(\S+)", changes) or [None, ""])[1]
            granted, removed = [], []
            for attr in ("SPECIAL", "OPERATIONS", "AUDITOR"):
                if re.search(rf"\bNO{attr}\b", changes):
                    removed.append(attr)
                elif re.search(rf"(?<!NO)\b{attr}\b", changes) and "CHANGES=" in changes:
                    granted.append(attr)
            attrs = granted if k == "auth_granted" else removed
            if attrs:
                return hit({"detail": ",".join(attrs)}, resource=target)
            return None
        if k == "pw_limit":
            if is_logon and not ok and "PASSWORD" in r.detail.upper():
                count = int(a.params.get("count", 5))
                within = int(a.params.get("within", 360))
                n = self._window((a.aid, r.user), r, count, within)
                if n:
                    return hit({"count": n, "window": self._window_text(within)})
            return None
        if k == "violations":
            if r.event in ("LOGON", "GEO LOGON") or not r.failed:
                return None
            count = int(a.params.get("count", 10))
            n = self._window((a.aid, r.user), r, count, self.cfg.average)
            if n:
                return hit({"count": n, "window": self._window_text(self.cfg.average)})
            return None
        if k == "admin_burst":
            if r.event not in _ADMIN_EVENTS or not ok:
                return None
            count = int(a.params.get("count", 10))
            n = self._window((a.aid, r.user), r, count, self.cfg.average)
            if n:
                return hit({"count": n, "window": self._window_text(self.cfg.average)})
            return None
        if k == "warning_access":
            if r.event == "DATASET ACCESS" and (r.extra.get("WARNING", "").upper() == "TRUE"
                                                or "WARNING MODE" in r.detail.upper()):
                return hit()
            return None
        if k in ("uacc_update", "uacc_read"):
            if r.event not in ("PROFILE DEFINE", "PROFILE ALTER") or not ok:
                return None
            cmd = r.detail.split("COMMAND=", 1)[-1]
            if not re.match(r"^(ADDSD|ALTDSD)\b", cmd.strip(), re.I):
                return None
            um = _UACC.search(cmd)
            if not um:
                return None
            uacc = um.group(1).upper()
            rank = _ACCESS_RANK.get(uacc, 0)
            pm = _PROFILE_IN_CMD.match(cmd.strip())
            profile = pm.group(1).upper() if pm else r.resource
            if k == "uacc_update" and rank >= _ACCESS_RANK["UPDATE"]:
                return hit({"detail": uacc}, resource=profile)
            if k == "uacc_read" and 0 < rank < _ACCESS_RANK["UPDATE"]:
                return hit({"detail": uacc}, resource=profile)
            return None
        if k in ("apf_update", "sens_read", "sens_update"):
            if r.event != "DATASET ACCESS" or not r.resource:
                return None
            rank = _ACCESS_RANK.get(r.access, 0)
            if k == "apf_update":
                if rank >= _ACCESS_RANK["UPDATE"] and any(
                        dataset_match(m, r.resource) for m in env.apf):
                    return hit({"detail": r.access})
                return None
            masks = env.sensread if k == "sens_read" else env.sensupdt
            floor = "READ" if k == "sens_read" else "UPDATE"
            if not any(dataset_match(m, r.resource) for m in masks):
                return None
            if k == "sens_read" and rank >= _ACCESS_RANK["UPDATE"] and any(
                    dataset_match(m, r.resource) for m in env.sensupdt):
                return None        # 1213 covers it
            return hit({"detail": r.access}) if rank >= _ACCESS_RANK[floor] else None
        if k == "uid0_assigned":
            if r.event in ("ALTUSER", "USER ALTER", "ADDUSER") and ok and \
                    re.search(r"UID\(\s*0\s*\)", r.detail, re.I):
                target = r.extra.get("USER") or (re.search(r"\bUSER=(\S+)", r.detail) or [None, "-"])[1]
                return hit(resource=target)
            return None
        if k == "bpx_superuser":
            if r.event == "PERMIT CHANGE" and ok and "BPX.SUPERUSER" in r.detail.upper():
                return hit({"detail": r.detail.split(' RESULT=')[0].replace('COMMAND=', '')[:60]},
                           resource="BPX.SUPERUSER")
            return None
        if k in ("setropts_change", "class_activated", "class_deactivated"):
            if r.event != "SETROPTS" or not ok:
                return None
            m = _SETROPTS.search(r.detail)
            operand = (m.group(1) if m else r.detail).strip()
            if operand.upper() in ("", "LIST", "LIST ALL"):
                return None
            classes = _CLASSACT.findall(operand)
            if k == "setropts_change":
                # 1504/1505 report class changes; 1503 is everything else.
                rest = _CLASSACT.sub("", operand).strip()
                return hit({"detail": rest[:60]}) if rest else None
            want_no = k == "class_deactivated"
            names = [c for no, c in classes if bool(no) == want_no]
            return hit({"detail": ",".join(names)}) if names else None
        if k == "custom":
            return self._custom(a, r, hit)
        return None

    def _custom(self, a: AlertDef, r: SmfRecord, hit) -> Optional[Fired]:
        p = a.params
        if not _event_match(p.get("event", "*"), r.event):
            return None
        res = (p.get("result", "*") or "*").upper()
        if res == "SUCCESS" and r.outcome != "SUCCESS":
            return None
        if res in ("FAILURE", "VIOLATION") and not r.failed:
            return None
        if not _mask_match(p.get("user", "*"), r.user):
            return None
        if not _mask_match(p.get("resource", "*"), r.resource):
            return None
        if not _mask_match(p.get("addr", "*"), r.addr):
            return None
        svc = p.get("service", "*")
        if svc not in ("", "*") and not _mask_match(svc, r.service) and \
                not _mask_match(svc, r.event):
            return None
        # A logon alert reads the logon itself, not its GEO companion records.
        if r.event.startswith("GEO ") and "LOGON" in (p.get("event", "") or "").upper() \
                and "CONNECTION" not in (p.get("event", "") or "").upper():
            return None
        try:
            count = int(p.get("count", "1") or 1)
            within = int(p.get("within", "0") or 0)
        except ValueError:
            count, within = 1, 0
        if count <= 1 or within <= 0:
            return hit()
        group = (p.get("groupby", "NONE") or "NONE").upper()
        gkey = {"ADDR": r.addr, "USER": r.user, "RESOURCE": r.resource}.get(group, "*")
        n = self._window((a.aid, gkey), r, count, within, (p.get("distinct") or "").upper())
        if n:
            # A summary speaks for the group, not for whichever record happened
            # to cross the threshold, so it names only what it was grouped by.
            return hit({"count": n, "window": self._window_text(within)},
                       user=r.user if group == "USER" else "",
                       resource=r.resource if group == "RESOURCE" else "")
        return None
