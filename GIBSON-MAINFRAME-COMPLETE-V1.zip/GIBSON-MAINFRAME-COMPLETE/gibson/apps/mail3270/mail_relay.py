"""Real outbound mail relay for the Gibson Office Mail facility.

This is deliberately a separate path from mail_transport.send_smtp, and the
reason is worth stating because it is the whole design.

mail_transport reads its credentials from SYS1.EMAIL, a simulated dataset in
the lab's own catalog that the mail facility creates so it can always be
browsed. That is correct for the lab: a mail password sitting in plain text in
a readable system dataset is an authentic finding and a good teaching artifact,
and this module does not interfere with it.

It is not correct for real credentials. GIBSON is a deliberately vulnerable
simulator whose exercises teach students to obtain RACF SPECIAL, abuse APF and
read protected datasets, so anything in SYS1.EMAIL should be treated as
published. Relaying real mail through credentials stored there would hand every
course attendee a working account on the operator's own domain.

So this module never reads a secret out of the simulated filesystem. Credentials
come from the host side only, through environment variables or a file outside
GIBSON_SIM_ROOT, and the relay refuses to start if it finds them anywhere the
simulated system could reach. SYS1.EMAIL keeps the non-secret settings, which is
authentic in its own right: real CSSMTP configuration names a target server
without carrying the mailbox password.

Everything here fails closed. Off unless enabled, deny unless the recipient
domain is allowlisted, no authentication over an unencrypted connection, a cap
on volume, and an audit record for every attempt whether it succeeded or not.
"""
from __future__ import annotations

import os
import re
import smtplib
import ssl
import time
from dataclasses import dataclass, field
from email.message import EmailMessage
from pathlib import Path
from typing import List, Optional, Tuple

ENV_PREFIX = "GIBSON_MAIL_"

# A relay that is merely misconfigured must look different from one that is
# switched off, so the operator can tell "I did not enable this" from "I
# enabled it and it is refusing".
DISABLED = "RELAY DISABLED"

_DEFAULT_PORT = 587
_DEFAULT_TLS = "STARTTLS"
_DEFAULT_MAX_PER_HOUR = 60

_ADDR = re.compile(r"^[^\s@,]+@[^\s@,]+\.[^\s@,]+$")

# Volume accounting for this process. A deliberately vulnerable lab that
# someone has taken over should not be able to become a mail cannon, so the
# cap applies even to a caller that is otherwise fully authorised.
_sent_times: List[float] = []


def _env(name: str, default: str = "") -> str:
    return (os.getenv(ENV_PREFIX + name, default) or "").strip()


def _truthy(value: str) -> bool:
    return value.strip().upper() in {"1", "YES", "Y", "TRUE", "ON", "ENABLED"}


@dataclass
class RelayConfig:
    """Resolved relay settings, with the reason when it cannot be used."""

    enabled: bool = False
    host: str = ""
    port: int = _DEFAULT_PORT
    tls: str = _DEFAULT_TLS
    user: str = ""
    password: str = field(default="", repr=False)
    sender: str = ""
    allow_domains: Tuple[str, ...] = ()
    max_per_hour: int = _DEFAULT_MAX_PER_HOUR
    problem: str = ""

    @property
    def usable(self) -> bool:
        return self.enabled and not self.problem

    def redacted(self) -> str:
        """A one-line description safe to put on a console or in a log."""
        if not self.enabled:
            return DISABLED
        if self.problem:
            return f"RELAY REFUSED - {self.problem}"
        who = self.user or "(no auth)"
        allow = ",".join(self.allow_domains) or "(none)"
        return (f"RELAY {self.host}:{self.port} TLS={self.tls} AS {who} "
                f"FROM {self.sender} ALLOW {allow}")


def _sim_root() -> Optional[Path]:
    raw = (os.getenv("GIBSON_SIM_ROOT", "") or "").strip()
    if not raw:
        return None
    try:
        return Path(raw).expanduser().resolve()
    except Exception:
        return None


def _is_inside(path: Path, parent: Path) -> bool:
    try:
        path.resolve().relative_to(parent)
        return True
    except Exception:
        return False


def _reject_reachable_creds(creds_path: Path) -> str:
    """Refuse a credentials file the simulated system could read.

    The simulated filesystem is browsable from TSO and ISPF and is the first
    place a student looks, so a credentials file inside it is the exact
    mistake this module exists to prevent. The kit directory matters too,
    because that is what gets zipped and shipped with the book.
    """
    root = _sim_root()
    if root is not None and _is_inside(creds_path, root):
        return f"CREDENTIALS FILE IS INSIDE GIBSON_SIM_ROOT ({root})"
    kit = Path(__file__).resolve().parents[3]
    if _is_inside(creds_path, kit):
        return f"CREDENTIALS FILE IS INSIDE THE GIBSON KIT ({kit})"
    return ""


def _load_creds_file(path_text: str) -> Tuple[str, str, str]:
    """Read SMTP_USER and SMTP_PASS from a host-side KEY=VALUE file."""
    try:
        path = Path(path_text).expanduser()
    except Exception:
        return ("", "", f"UNREADABLE CREDENTIALS PATH: {path_text}")
    if not path.is_file():
        return ("", "", f"CREDENTIALS FILE NOT FOUND: {path}")
    reachable = _reject_reachable_creds(path)
    if reachable:
        return ("", "", reachable)
    try:
        mode = path.stat().st_mode & 0o077
    except Exception:
        mode = 0
    if mode and os.name == "posix":
        return ("", "", f"CREDENTIALS FILE IS GROUP/WORLD READABLE: {path} (chmod 600)")
    user = pw = ""
    try:
        for raw in path.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, _, val = line.partition("=")
            key = key.strip().upper()
            val = val.strip().strip('"').strip("'")
            if key in {"SMTP_USER", "USER"}:
                user = val
            elif key in {"SMTP_PASS", "SMTP_PASSWORD", "PASS", "PASSWORD"}:
                pw = val
    except Exception as exc:
        return ("", "", f"CREDENTIALS FILE UNREADABLE ({type(exc).__name__})")
    return (user, pw, "")


def _normalise_tls(value: str) -> str:
    v = (value or "").strip().upper()
    if v in {"SSL", "IMPLICIT", "TLS_SSL"}:
        return "SSL"
    if v in {"NONE", "NO", "OFF", "PLAIN", "FALSE"}:
        return "NONE"
    return "STARTTLS"


def load_config() -> RelayConfig:
    """Resolve the relay from the host environment only.

    Nothing here consults SYS1.EMAIL or anything else the simulated system can
    write, so a student who edits mail configuration in M.8 cannot redirect
    real mail, change the sender, or downgrade the transport.
    """
    cfg = RelayConfig()
    cfg.enabled = _truthy(_env("RELAY"))
    if not cfg.enabled:
        return cfg

    cfg.host = _env("SMTP_HOST")
    cfg.sender = _env("FROM")
    cfg.tls = _normalise_tls(_env("TLS", _DEFAULT_TLS))
    try:
        cfg.port = int(_env("SMTP_PORT", str(_DEFAULT_PORT)) or _DEFAULT_PORT)
    except ValueError:
        cfg.problem = "SMTP PORT IS NOT A NUMBER"
        return cfg
    try:
        cfg.max_per_hour = int(_env("MAX_PER_HOUR", str(_DEFAULT_MAX_PER_HOUR))
                               or _DEFAULT_MAX_PER_HOUR)
    except ValueError:
        cfg.problem = "MAX_PER_HOUR IS NOT A NUMBER"
        return cfg

    creds_file = _env("CREDS")
    if creds_file:
        cfg.user, cfg.password, problem = _load_creds_file(creds_file)
        if problem:
            cfg.problem = problem
            return cfg
    else:
        cfg.user = _env("SMTP_USER")
        cfg.password = os.getenv(ENV_PREFIX + "SMTP_PASS", "") or ""

    cfg.allow_domains = tuple(
        d.strip().lower().lstrip("@")
        for d in _env("ALLOW_DOMAINS").split(",")
        if d.strip()
    )

    if not cfg.host:
        cfg.problem = f"NO RELAY HOST - SET {ENV_PREFIX}SMTP_HOST"
        return cfg
    if not cfg.sender:
        cfg.problem = f"NO SENDER ADDRESS - SET {ENV_PREFIX}FROM"
        return cfg
    if not cfg.allow_domains:
        cfg.problem = (f"NO RECIPIENT DOMAINS ALLOWED - SET {ENV_PREFIX}ALLOW_DOMAINS")
        return cfg
    # Authenticating over a cleartext connection would put the password on the
    # wire, which is the one failure this module must never allow, since the
    # lab it runs in is full of people with packet captures running.
    if cfg.password and cfg.tls == "NONE":
        cfg.problem = "REFUSING TO AUTHENTICATE WITHOUT TLS"
        return cfg
    return cfg


def domain_allowed(address: str, allow_domains: Tuple[str, ...]) -> bool:
    """Allow a recipient only on an exact or subdomain match of the allowlist."""
    addr = (address or "").strip().lower()
    if "@" not in addr:
        return False
    domain = addr.rsplit("@", 1)[1]
    for allowed in allow_domains:
        if domain == allowed or domain.endswith("." + allowed):
            return True
    return False


def split_recipients(to_text: str, allow_domains: Tuple[str, ...]):
    """Return (allowed, rejected) for a comma-separated recipient list."""
    allowed, rejected = [], []
    for raw in (to_text or "").split(","):
        addr = raw.strip()
        if not addr:
            continue
        if not _ADDR.match(addr):
            rejected.append((addr, "NOT A VALID ADDRESS"))
        elif not domain_allowed(addr, allow_domains):
            rejected.append((addr, "DOMAIN NOT ALLOWLISTED"))
        else:
            allowed.append(addr)
    return (allowed, rejected)


def _rate_limited(max_per_hour: int) -> bool:
    cutoff = time.time() - 3600
    _sent_times[:] = [t for t in _sent_times if t >= cutoff]
    return len(_sent_times) >= max_per_hour


def reset_rate_limit() -> None:
    """Clear the volume counter. For tests and for an operator restart."""
    _sent_times.clear()


def _audit(state, line: str, *, severity: str = "INFO", result: str = "INFO") -> None:
    """Put every relay attempt somewhere the operator will see it.

    Real mail leaving a training lab is exactly the kind of event that should
    never happen quietly, so this is best effort but unconditional.
    """
    try:
        state.notify_console(line, severity=severity)
    except Exception:
        pass
    try:
        from gibson.core import v26_features

        v26_features.security_event(
            state, "MAILRELAY", line, userid="SMTPD",
            severity=severity, resource="MAIL.RELAY", result=result)
    except Exception:
        pass


def status_line(state=None) -> str:
    """One line describing the relay, for the console and D SVC,L."""
    cfg = load_config()
    return cfg.redacted()


def send_external(state, to_text: str, subject: str, body: List[str],
                  *, userid: str = "") -> Tuple[bool, str]:
    """Relay one note to the outside world, or explain why not.

    Returns (ok, status) and never raises, because this is called straight from
    a 3270 panel handler and a traceback there would take the session down.
    """
    cfg = load_config()
    if not cfg.enabled:
        return (False, "EXTERNAL MAIL NOT ENABLED ON THIS SYSTEM")
    if cfg.problem:
        _audit(state, f"IEE305I MAIL RELAY REFUSED - {cfg.problem}",
               severity="WARNING", result="REFUSED")
        return (False, f"RELAY REFUSED - {cfg.problem}")

    allowed, rejected = split_recipients(to_text, cfg.allow_domains)
    for addr, why in rejected:
        _audit(state, f"IEE305I MAIL RELAY BLOCKED {addr} - {why}",
               severity="WARNING", result="BLOCKED")
    if not allowed:
        reasons = "; ".join(f"{a} {w}" for a, w in rejected) or "NO RECIPIENTS"
        return (False, f"NOTHING SENT - {reasons}"[:200])

    if _rate_limited(cfg.max_per_hour):
        _audit(state, f"IEE305I MAIL RELAY RATE LIMIT {cfg.max_per_hour}/HOUR REACHED",
               severity="WARNING", result="THROTTLED")
        return (False, f"RATE LIMIT {cfg.max_per_hour}/HOUR REACHED - NOTHING SENT")

    msg = EmailMessage()
    msg["From"] = cfg.sender
    msg["To"] = ", ".join(allowed)
    msg["Subject"] = subject or "(no subject)"
    # Say what this is. Mail arriving from a deliberately vulnerable training
    # lab should be identifiable as such by whoever receives it.
    msg["X-GIBSON-Relay"] = "GIBSON training simulator"
    if userid:
        msg["X-GIBSON-User"] = userid
    msg.set_content("\n".join(body or []))

    try:
        if cfg.tls == "SSL":
            server = smtplib.SMTP_SSL(cfg.host, cfg.port, timeout=30,
                                      context=ssl.create_default_context())
        else:
            server = smtplib.SMTP(cfg.host, cfg.port, timeout=30)
        with server as conn:
            conn.ehlo()
            if cfg.tls == "STARTTLS":
                conn.starttls(context=ssl.create_default_context())
                conn.ehlo()
            if cfg.user and cfg.password:
                conn.login(cfg.user, cfg.password)
            conn.send_message(msg, from_addr=cfg.sender, to_addrs=allowed)
    except smtplib.SMTPAuthenticationError:
        _audit(state, "IEE305I MAIL RELAY AUTHENTICATION FAILED",
               severity="ALERT", result="FAILED")
        return (False, "RELAY AUTHENTICATION FAILED - CHECK HOST-SIDE CREDENTIALS")
    except Exception as exc:
        _audit(state, f"IEE305I MAIL RELAY FAILED - {type(exc).__name__}",
               severity="ALERT", result="FAILED")
        return (False, f"RELAY FAILED ({type(exc).__name__}) - NOTE FILED IN SENT ONLY")

    _sent_times.append(time.time())
    who = f" BY {userid}" if userid else ""
    _audit(state, f"IEE306I MAIL RELAYED TO {', '.join(allowed)} VIA "
                  f"{cfg.host}:{cfg.port}{who}", result="SENT")
    blocked = f" ({len(rejected)} BLOCKED)" if rejected else ""
    return (True, f"NOTE RELAYED TO {', '.join(allowed)}{blocked}")
