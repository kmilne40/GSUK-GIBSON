"""GIBSON internal SMTP listener (RFC 5321 subset) with a z/OS persona.

A deliberately plain SMTP server for the training lab: no TLS, no AUTH, no
pipelining. That is the point, because the traffic is meant to be read off the
wire with Zniff or Wireshark and the protocol is meant to be driven by hand
over telnet or netcat.

It is a FRONT DOOR onto delivery machinery that already exists. The Office Mail
facility (ISPF M.8) keeps per-user mailbox datasets such as IBMUSER.MAIL.IN and
already knows how to classify a recipient and deposit a note into another
user's inbox. This listener parses an SMTP envelope and message, then hands
each local recipient to that same code, so mail that arrives over the wire and
mail composed in M.8 land in exactly the same place.

Deliberately NOT a relay. Only recipients that resolve to a local userid, or to
the configured internal domain, are accepted; everything else is refused with a
550. Without that an unauthenticated SMTP server would be an open relay sitting
on a student's laptop, which is a real-world problem rather than a training
one. The listener also binds to the loopback address by default.

By default it answers in the voice of IBM's classic z/OS Communications Server
SMTP address space, so a port scan of the lab identifies a mainframe mail
server; see the persona section below for what is attested and what is
reconstructed. Set GIBSON_SMTP_PERSONA=plain for a modern ESMTP greeting
instead.

Commands: HELO, MAIL FROM, RCPT TO, DATA, RSET, NOOP, VRFY, HELP, QUIT, plus
EHLO in the plain persona and VERB, TICK, QUEU and EXPN in the z/OS one.
"""
from __future__ import annotations

import os
import re
import socketserver
import threading
import time
from datetime import datetime
from typing import List, Optional

# Guard rails. A training listener should never be the reason a lab machine
# runs out of memory, so a message and a session are both bounded.
MAX_MESSAGE_BYTES = 1024 * 1024        # 1 MB per message
MAX_LINE_BYTES = 8192                  # a single protocol or data line
MAX_RECIPIENTS = 32

# Recognized by every SMTP server since RFC 821 and implemented by almost none
# of them. Answering 502 rather than 500 is what a real server does, and the
# distinction is itself a fingerprint.
OBSOLETE_VERBS = ("SEND", "SOML", "SAML", "TURN")


def _is_expected_disconnect(exc: BaseException) -> bool:
    return isinstance(exc, (ConnectionResetError, BrokenPipeError, TimeoutError, OSError))


def _addr(spec: str) -> str:
    """Pull the address out of a MAIL FROM / RCPT TO parameter.

    Accepts '<user@host>', 'user@host', and trailing ESMTP parameters such as
    'SIZE=1234', which are parsed and ignored.
    """
    s = (spec or "").strip()
    if "<" in s and ">" in s:
        return s[s.index("<") + 1:s.rindex(">")].strip()
    return s.split()[0].strip() if s else ""


# --------------------------------------------------------------------------- #
#  Personas: how the listener presents itself on the wire.
#
#  The protocol logic below is persona-independent; only the reply TEXT and the
#  decision to support ESMTP change. Two personas ship:
#
#  "zos"   (default) answers the way IBM's classic z/OS Communications Server
#          SMTP address space answers, so a scan of the lab reports a mainframe
#          mail server rather than a Python script. That is what makes GIBSON
#          usable as a research honeypot and what makes the Chapter 6 scan
#          lesson land, because nmap's own service-probe database carries the
#          fingerprint
#
#              match smtp m|^220 ([-\w_.]+) running IBM MVS SMTP CS (\w+) on
#              .*\r\n| p/IBM MVS smtpd/ v/$2/ o/MVS/ h/$1/ cpe:/o:ibm:mvs/
#
#          and a greeting of exactly that shape is therefore reported as
#          "IBM MVS smtpd" with cpe:/o:ibm:mvs/ and the OS guessed as MVS.
#
#          The replies marked VERIFIED are transcribed from real z/OS sessions
#          captured on public mailing lists and reference pages. The ones
#          marked RECONSTRUCTED are modelled on the documented command set and
#          on the house style of the verified ones, because no public capture
#          of them exists; they are plausible rather than attested, and that
#          distinction is recorded here rather than quietly hidden.
#
#  "plain" is the previous behaviour: a modern ESMTP greeting advertising SIZE
#          and 8BITMIME. Keep it when the exercise is about reading ordinary
#          SMTP rather than about fingerprinting a mainframe.
#
#  Choose with GIBSON_SMTP_PERSONA=zos|plain.
# --------------------------------------------------------------------------- #

def _zos_date() -> str:
    """RFC 822 two-digit-year stamp, the form the real banner carries.

    A real greeting reads "... on Sat, 21 Oct 00 17:00:52 CDT", so the year is
    two digits and the zone is an abbreviation rather than a numeric offset.
    """
    zone = time.strftime("%Z") or "GMT"
    return datetime.now().strftime("%a, %d %b %y %H:%M:%S ") + zone


class PlainPersona:
    """A modern, unremarkable ESMTP server."""

    name = "plain"
    esmtp = True

    def greeting(self, host: str) -> List[str]:
        return [f"220 {host} ESMTP Office Mail service ready"]

    def helo_ok(self, host: str, domain: str, is_mine: bool) -> List[str]:
        return [f"250 {host} Hello {domain}"]

    def ehlo_ok(self, host: str, domain: str, is_mine: bool) -> List[str]:
        return [f"250-{host} Hello {domain}",
                f"250-SIZE {MAX_MESSAGE_BYTES}",
                "250-8BITMIME",
                "250 HELP"]

    def noop_ok(self) -> List[str]:
        return ["250 2.0.0 Ok"]

    def rset_ok(self) -> List[str]:
        return ["250 2.0.0 Ok"]

    def mail_ok(self) -> List[str]:
        return ["250 2.1.0 Ok"]

    def rcpt_ok(self, user: str) -> List[str]:
        return [f"250 2.1.5 Ok <{user}>"]

    def data_intro(self) -> List[str]:
        return ["354 End data with <CR><LF>.<CR><LF>"]

    def data_ok(self, n: int) -> List[str]:
        return [f"250 2.0.0 Ok: queued for {n} recipient(s)"]

    def data_failed(self) -> List[str]:
        return ["451 4.3.0 Delivery failed"]

    def quit_ok(self, host: str) -> List[str]:
        return [f"221 2.0.0 {host} closing connection"]

    def vrfy_ok(self, user: str, domain: str) -> List[str]:
        return [f"250 2.1.5 {user} <{user.lower()}@{domain}>"]

    def vrfy_unknown(self, who: str) -> List[str]:
        return ["550 5.1.1 User unknown"]

    def relay_denied(self) -> List[str]:
        return ["550 5.7.1 Relaying denied - this host accepts local "
                "recipients only"]

    def unrecognized(self, verb: str) -> List[str]:
        return [f"500 5.5.2 Command unrecognized: {verb}"]

    def not_implemented(self, verb: str) -> List[str]:
        return [f"502 5.5.1 Command not implemented: {verb}"]

    def bad_syntax(self) -> List[str]:
        return ["500 5.5.2 Error: bad syntax"]

    def syntax_mail(self) -> List[str]:
        return ["501 5.5.4 Syntax: MAIL FROM:<address>"]

    def syntax_rcpt(self) -> List[str]:
        return ["501 5.5.4 Syntax: RCPT TO:<address>"]

    def need_mail(self) -> List[str]:
        return ["503 5.5.1 Error: need MAIL command"]

    def need_rcpt(self) -> List[str]:
        return ["503 5.5.1 Error: need MAIL and RCPT first"]

    def too_many_rcpt(self) -> List[str]:
        return ["452 4.5.3 Too many recipients"]

    def too_big(self) -> List[str]:
        return ["552 5.3.4 Message too large"]

    def help_ok(self, host: str) -> List[str]:
        return ["214 2.0.0 HELO EHLO MAIL RCPT DATA RSET NOOP VRFY QUIT"]

    def extra(self, verb: str, rest: str, host: str, session) -> Optional[List[str]]:
        return None


class ZosPersona(PlainPersona):
    """IBM z/OS Communications Server SMTP, as it looks from the outside.

    Two things make this convincing beyond the greeting. First, there are no
    enhanced status codes anywhere, because RFC 2034 enhanced codes arrive with
    ESMTP and a server that will not answer EHLO has no business emitting them;
    a scanner that sees "250 2.1.0 Ok" from a self-declared RFC 821 server has
    caught the disguise in one line. Second, EHLO is refused, which is the
    behaviour of the classic address space and is also what pushes a client
    down the HELO path, where the distinctive domain reply lives.
    """

    name = "zos"

    def __init__(self, level: str, esmtp: bool = True) -> None:
        self.level = level
        # Whether to answer EHLO at all. Refusing it is the behaviour of the
        # oldest address spaces and is the more distinctively pre-ESMTP answer,
        # but it also makes a scanner stop after one line, so a honeypot learns
        # less and the Chapter 6 scan lesson shows less. Answering is the
        # default, with GIBSON_SMTP_EHLO=refuse for the strict RFC 821 voice.
        self.esmtp = esmtp

    # VERIFIED: "220 mvshost.mydomain running IBM MVS SMTP CS V2R6 on
    #            Sat, 21 Oct 00 17:00:52 CDT"
    def greeting(self, host: str) -> List[str]:
        return [f"220 {host} running IBM MVS SMTP CS {self.level} on {_zos_date()}"]

    # VERIFIED, both arms:
    #   "250 TST1.CO.BK is my domain name.  Yours too, I see!"
    #   "250 MAINFRAME.xxxx is my domain name.  I've never heard of you!"
    # The double space after the full stop is in the real replies.
    def helo_ok(self, host: str, domain: str, is_mine: bool) -> List[str]:
        tail = "Yours too, I see!" if is_mine else "I've never heard of you!"
        return [f"250 {host} is my domain name.  {tail}"]

    def ehlo_ok(self, host: str, domain: str, is_mine: bool) -> List[str]:
        """ESMTP, but still in the mainframe's voice.

        The signature domain line leads, so the distinctive z/OS text survives
        even when the client never sends HELO, and only SIZE and 8BITMIME are
        advertised. ENHANCEDSTATUSCODES deliberately is not, which is what
        licenses every other reply here to carry a bare three-digit code.
        """
        return [self.helo_ok(host, domain, is_mine)[0].replace("250 ", "250-", 1),
                f"250-SIZE {MAX_MESSAGE_BYTES}",
                "250-8BITMIME",
                "250 HELP"]

    def noop_ok(self) -> List[str]:
        return ["250 OK"]

    def rset_ok(self) -> List[str]:
        return ["250 OK"]

    # VERIFIED: "250 OK", for MAIL FROM and for RCPT TO alike.
    def mail_ok(self) -> List[str]:
        return ["250 OK"]

    def rcpt_ok(self, user: str) -> List[str]:
        return ["250 OK"]

    # VERIFIED: "354 Enter mail body.  End by new line with just a '.'"
    def data_intro(self) -> List[str]:
        return ["354 Enter mail body.  End by new line with just a '.'"]

    # VERIFIED: "250 Mail Delivered"
    def data_ok(self, n: int) -> List[str]:
        return ["250 Mail Delivered"]

    def data_failed(self) -> List[str]:
        return ["451 Requested action aborted: local error in processing"]

    # VERIFIED: "221 MVSHOST running IBM MVS SMTP CS V1R7 closing connection"
    def quit_ok(self, host: str) -> List[str]:
        return [f"221 {host} running IBM MVS SMTP CS {self.level} "
                "closing connection"]

    # RECONSTRUCTED from here down.
    def vrfy_ok(self, user: str, domain: str) -> List[str]:
        return [f"250 {user} <{user.lower()}@{domain}>"]

    def vrfy_unknown(self, who: str) -> List[str]:
        return [f"550 Unknown user: {who}"]

    def relay_denied(self) -> List[str]:
        return ["550 Relaying not permitted - this host accepts local "
                "recipients only"]

    def unrecognized(self, verb: str) -> List[str]:
        return [f'500 Command unrecognized: "{verb}"']

    def not_implemented(self, verb: str) -> List[str]:
        return [f'502 Command not implemented: "{verb}"']

    def bad_syntax(self) -> List[str]:
        return ["500 Syntax error, command unrecognized"]

    def syntax_mail(self) -> List[str]:
        return ["501 Syntax error - usage: MAIL FROM:<address>"]

    def syntax_rcpt(self) -> List[str]:
        return ["501 Syntax error - usage: RCPT TO:<address>"]

    def need_mail(self) -> List[str]:
        return ["503 Bad sequence of commands - MAIL FROM required first"]

    def need_rcpt(self) -> List[str]:
        return ["503 Bad sequence of commands - MAIL FROM and RCPT TO "
                "required first"]

    def too_many_rcpt(self) -> List[str]:
        return ["452 Too many recipients"]

    def too_big(self) -> List[str]:
        return ["552 Requested mail action aborted: exceeded storage allocation"]

    def help_ok(self, host: str) -> List[str]:
        """Multi-line 214, the second fingerprint surface after the banner.

        nmap matches multi-line HELP output as readily as it matches greetings:
        its OS/400 entry is matched entirely on a 214- block whose last line
        names the operating system. The closing lines here do the same job for
        z/OS, and nmap's smtp-commands script reports the whole block.
        """
        known = ["HELO", "MAIL", "RCPT", "DATA", "RSET", "NOOP", "QUIT",
                 "HELP", "VRFY", "EXPN", "VERB", "TICK", "QUEU"]
        missing = ["SEND", "SOML", "SAML", "TURN"]
        if self.esmtp:
            known.insert(1, "EHLO")
        else:
            missing.append("EHLO")
        out = ["214-The following commands are recognized:"]
        out += ["214-  " + "".join(v.ljust(8) for v in known[i:i + 5]).rstrip()
                for i in range(0, len(known), 5)]
        out.append("214-Commands not implemented are:")
        out.append("214-  " + "".join(v.ljust(8) for v in missing).rstrip())
        out.append(f"214-{host} is running the z/OS operating system.")
        out.append("214 For assistance, contact your system programmer.")
        return out

    def extra(self, verb: str, rest: str, host: str, session) -> Optional[List[str]]:
        """The IBM-specific verbs that are not in RFC 5321 at all.

        QUEU is the one worth having, because the documented way to ask a z/OS
        SMTP address space about its spool is to telnet to port 25 and type it,
        so a student or a scanner who tries it should get a spool report rather
        than a syntax error.
        """
        if verb == "QUEU":
            return [f"250-Queue status for {host}",
                    "250-Spool files awaiting processing:         0",
                    "250-Notes queued for local delivery:         0",
                    "250-Notes queued for remote delivery:        0",
                    "250-Undeliverable notes held for retry:      0",
                    "250 Queue status complete"]
        if verb == "VERB":
            arg = (rest or "").strip().upper()
            if arg in ("ON", ""):
                session.verbose = True
                return ["250 Verbose mode ON"]
            if arg == "OFF":
                session.verbose = False
                return ["250 Verbose mode OFF"]
            return ["501 Syntax error - usage: VERB ON|OFF"]
        if verb == "TICK":
            arg = (rest or "").strip()
            if not arg:
                return ["501 Syntax error - usage: TICK <ticket-number>"]
            session.tick = arg.split()[0]
            return [f"250 Ticket {session.tick} accepted"]
        if verb == "EXPN":
            return [f"550 {(rest or '').strip()} is not a mailing list"]
        return None


def build_persona() -> PlainPersona:
    """Pick the persona from the environment, defaulting to z/OS."""
    which = (os.getenv("GIBSON_SMTP_PERSONA") or "zos").strip().lower()
    if which in ("plain", "esmtp", "generic", "off", "none"):
        return PlainPersona()
    level = (os.getenv("GIBSON_SMTP_CS_LEVEL") or "V2R5").strip().upper()
    ehlo = (os.getenv("GIBSON_SMTP_EHLO") or "accept").strip().lower()
    return ZosPersona(level, esmtp=ehlo not in ("refuse", "reject", "no", "off", "0"))


class SmtpHandler(socketserver.StreamRequestHandler):
    state = None                 # injected by serve_smtp
    persona = None               # built per connection unless set on the class
    timeout = 120

    # -- plumbing ---------------------------------------------------------
    def _send(self, line: str) -> None:
        self._send_all([line])

    def _send_all(self, lines: List[str]) -> None:
        """Write a whole reply in one go, multi-line replies included.

        One write per reply rather than one per line, which matters more than
        it looks. A client that asks its socket for "at least one line" and
        gets a single TCP segment per line reads only the first line of a
        multi-line reply and leaves the rest in the buffer, so every later
        reply it reads belongs to an earlier command. nmap's SMTP library works
        exactly that way, and the drift made its open-relay script read a
        trailing "250 HELP" from the EHLO reply as acceptance of a foreign
        recipient and report this listener as an open relay, which it is not.
        A real MTA sends the reply as one unit, so this one does too.
        """
        if not lines:
            return
        blob = "".join(line + "\r\n" for line in lines)
        try:
            self.wfile.write(blob.encode("utf-8", "replace"))
            self.wfile.flush()
        except Exception:
            pass

    def _readline(self) -> Optional[str]:
        try:
            raw = self.rfile.readline(MAX_LINE_BYTES + 2)
        except Exception:
            return None
        if not raw:
            return None
        return raw.decode("utf-8", "replace").rstrip("\r\n")

    def _hostname(self) -> str:
        st = self.state
        name = getattr(getattr(st, "network", None), "hostname", None) \
            or getattr(st, "system_hostname", None) or "GIBSON"
        return str(name).upper()

    def _wire_host(self) -> str:
        """The host name that goes in the greeting and the closing reply.

        It has to be a bare token, because nmap's MVS fingerprint captures the
        host with [-\\w_.]+ and a space or a bracket in there would stop the
        whole greeting matching. Anything else is stripped rather than trusted,
        and a dotted form is preferred because that is what a real system
        announces.
        """
        env = (os.getenv("GIBSON_SMTP_HOSTNAME") or "").strip()
        host = env.upper()
        if not host:
            base = self._hostname()
            dom = self._domain().upper()
            if "." in base or not dom:
                host = base
            elif dom == base or dom.startswith(base + "."):
                host = dom
            else:
                host = f"{base}.{dom}"
        host = re.sub(r"[^-\w.]", "", host)
        return host or "GIBSON"

    # -- mail plumbing ----------------------------------------------------
    def _store(self):
        """One shared MailStore per server, created on first use.

        MailStore is the trusted delivery agent: its mailbox I/O deliberately
        bypasses the per-user RACF check, exactly as a real MTA writing into a
        user's mailbox would.
        """
        srv = self.server
        store = getattr(srv, "_mail_store", None)
        if store is None:
            from gibson.apps.mail3270.mail_store import MailStore
            store = MailStore(self.state, "IBMUSER")
            srv._mail_store = store
        return store

    def _local_recipient(self, addr: str) -> Optional[str]:
        """Return the local USERID for an address, or None if it is not ours."""
        try:
            kind, who = self._store().classify(addr)
        except Exception:
            return None
        return who if kind == "internal" else None

    def _deliver(self, sender: str, recipients: List[str], data: str) -> int:
        """Parse the message and drop it into each recipient's inbox."""
        from email import message_from_string
        from gibson.apps.mail3270.mail_store import Message, _now

        try:
            em = message_from_string(data)
            subject = (em.get("Subject") or "(no subject)").strip()
            if em.is_multipart():
                parts = [p for p in em.walk() if p.get_content_type() == "text/plain"]
                text = parts[0].get_payload(decode=True).decode("utf-8", "replace") if parts else ""
            else:
                payload = em.get_payload(decode=True)
                text = payload.decode("utf-8", "replace") if payload else str(em.get_payload())
        except Exception:
            subject, text = "(no subject)", data

        body = [ln.rstrip() for ln in text.splitlines()] or [""]
        delivered = 0
        store = self._store()
        for user in recipients:
            try:
                msg = Message(sender, user, subject, _now(), "NEW", list(body))
                if store.deliver_internal(user, msg):
                    delivered += 1
            except Exception:
                continue
        return delivered

    def _audit(self, text: str) -> None:
        try:
            notify = getattr(self.state, "notify_console", None)
            if callable(notify):
                notify(text)
        except Exception:
            pass

    def _is_my_domain(self, domain: str) -> bool:
        """Did the client claim to be us? The z/OS HELO reply depends on it."""
        d = (domain or "").strip().strip("[]").rstrip(".").upper()
        if not d:
            return False
        return d in {self._wire_host(), self._hostname(), self._domain().upper()}

    # -- the conversation -------------------------------------------------
    def _record_connection(self) -> None:
        """Put the connecting address into the audit trail and SMF stream.

        Every other listener here records a security event carrying the peer
        address, which is how the Master Console comes to show a connection
        with its source IP. Mail recorded nothing, so a scan of the mail port
        was invisible on the console even though the listener answered it,
        which is the opposite of what a honeypot persona is for: the banner
        was realistic and the fact that anyone had read it was not reported.
        """
        state = self.state
        if state is None:
            return
        try:
            addr = self.client_address[0] if self.client_address else ""
        except Exception:
            addr = ""
        port = int(getattr(getattr(state, "config", None), "smtp_port", 0) or 0)
        try:
            state.record_security_event(
                "SMTPD", "CONNECT", f"SMTP CONNECTION PORT={port}",
                service="SMTP", addr=addr, terminal="TCPIP")
        except Exception:
            pass

    def handle(self) -> None:
        p = self.persona if self.persona is not None else build_persona()
        host = self._wire_host()
        self.verbose = False
        self.tick = ""
        self._record_connection()
        self._send_all(p.greeting(host))
        helo = ""
        sender = ""
        recipients: List[str] = []

        while True:
            line = self._readline()
            if line is None:
                return
            if not line.strip():
                self._send_all(p.bad_syntax())
                continue
            parts = line.split(None, 1)
            verb = parts[0].upper()
            rest = parts[1] if len(parts) > 1 else ""

            if verb == "QUIT":
                self._send_all(p.quit_ok(host))
                return

            if verb == "EHLO":
                if p.esmtp:
                    helo = rest.strip() or "unknown"
                    self._send_all(p.ehlo_ok(host, helo, self._is_my_domain(helo)))
                    sender, recipients = "", []
                else:
                    # The classic address space does not speak ESMTP, and a
                    # client that gets this falls back to HELO on its own.
                    self._send_all(p.unrecognized(verb))
                continue

            if verb == "HELO":
                helo = rest.strip() or "unknown"
                self._send_all(p.helo_ok(host, helo, self._is_my_domain(helo)))
                sender, recipients = "", []
                continue

            if verb == "NOOP":
                self._send_all(p.noop_ok())
                continue

            if verb == "RSET":
                sender, recipients = "", []
                self._send_all(p.rset_ok())
                continue

            if verb == "VRFY":
                # Deliberately informative: user enumeration over SMTP is one of
                # the things this listener exists to teach.
                asked = _addr(rest) or rest.strip()
                who = self._local_recipient(asked)
                if who:
                    self._send_all(p.vrfy_ok(who, self._domain()))
                else:
                    self._send_all(p.vrfy_unknown(asked))
                continue

            if verb == "HELP":
                self._send_all(p.help_ok(host))
                continue

            if verb == "MAIL":
                if not rest.upper().startswith("FROM:"):
                    self._send_all(p.syntax_mail())
                    continue
                sender = _addr(rest[5:]) or "unknown@local"
                recipients = []
                self._send_all(p.mail_ok())
                continue

            if verb == "RCPT":
                if not sender:
                    self._send_all(p.need_mail())
                    continue
                if not rest.upper().startswith("TO:"):
                    self._send_all(p.syntax_rcpt())
                    continue
                if len(recipients) >= MAX_RECIPIENTS:
                    self._send_all(p.too_many_rcpt())
                    continue
                target = _addr(rest[3:])
                who = self._local_recipient(target)
                if who is None:
                    # Not a local user: refuse rather than relay. This server is
                    # unauthenticated by design, so it must never forward mail.
                    self._send_all(p.relay_denied())
                    continue
                recipients.append(who)
                self._send_all(p.rcpt_ok(who))
                continue

            if verb == "DATA":
                if not sender or not recipients:
                    self._send_all(p.need_rcpt())
                    continue
                self._send_all(p.data_intro())
                chunks: List[str] = []
                total = 0
                too_big = False
                while True:
                    dline = self._readline()
                    if dline is None:
                        return
                    if dline == ".":
                        break
                    # RFC 5321 transparency: a leading dot is doubled on the wire.
                    if dline.startswith(".."):
                        dline = dline[1:]
                    total += len(dline) + 2
                    if total > MAX_MESSAGE_BYTES:
                        too_big = True
                        continue          # keep draining until the terminator
                    chunks.append(dline)
                if too_big:
                    self._send_all(p.too_big())
                    sender, recipients = "", []
                    continue
                n = self._deliver(sender, recipients, "\n".join(chunks))
                if n:
                    tick = f" TICKET {self.tick}" if self.tick else ""
                    self._audit(f"GIBSMTP001I MAIL FROM {sender} DELIVERED TO "
                                f"{', '.join(recipients)}{tick}")
                    self._send_all(p.data_ok(n))
                else:
                    self._send_all(p.data_failed())
                sender, recipients = "", []
                continue

            extra = p.extra(verb, rest, host, self)
            if extra is not None:
                self._send_all(extra)
                continue

            if verb in OBSOLETE_VERBS:
                self._send_all(p.not_implemented(verb))
                continue

            self._send_all(p.unrecognized(verb))

    def _domain(self) -> str:
        try:
            return str(self._store().config.get("INTERNAL_DOMAIN", "GIBSON.LOCAL")).lower()
        except Exception:
            return "gibson.local"


class ThreadedSmtpServer(socketserver.ThreadingMixIn, socketserver.TCPServer):
    allow_reuse_address = True
    daemon_threads = True

    def handle_error(self, request, client_address):
        import sys
        exc = sys.exc_info()[1]
        if exc is not None and _is_expected_disconnect(exc):
            return
        return super().handle_error(request, client_address)


def smtp_bind_host(state) -> str:
    """Face the network like every other listener here, unless told otherwise.

    This returned loopback unconditionally, on the reasoning that an
    unauthenticated MTA should not face a network. Sound for a mail server,
    wrong for this one. The z/OS persona exists to be found by a scan, and
    loopback made it invisible to every scan except one run on the lab host
    itself, while TN3270, FTP, the dashboard and the rest all bind
    config.host. Mail was the only service in the lab that vanished when a
    student scanned the box from the classroom, which read as a fault and was
    not one.

    Mail still refuses to relay whatever it binds, so what a visitor can do is
    post into the lab's own mailboxes: the same bargain every other
    deliberately vulnerable service here already makes. GIBSON_SMTP_BIND still
    wins when set, so a single lab can be pinned back to loopback, and the
    secure profile keeps mail on loopback regardless, since being the hardened
    comparison is that profile's entire job.
    """
    explicit = os.getenv("GIBSON_SMTP_BIND", "").strip()
    if explicit:
        return explicit
    try:
        from gibson.core.security_mode import SECURE

        if getattr(state.config, "security_mode", "") == SECURE:
            return "127.0.0.1"
    except Exception:
        pass
    return getattr(state.config, "host", "0.0.0.0") or "0.0.0.0"


SMTP_FALLBACK_PORT = 2525


def smtp_port_was_set_explicitly() -> bool:
    """True when the operator named a port, rather than taking the default.

    This decides whether a refused bind is something to work around or
    something to report. If somebody asked for a specific port, quietly
    using a different one would be worse than failing.
    """
    return bool(os.getenv("GIBSON_SMTP_PORT", "").strip())


def smtp_fallback_lines(wanted: int, actual: int) -> tuple[str, ...]:
    """Console voice for a privileged port the operating system refused."""
    return (
        f"IEE305I SMTPD CANNOT BIND PORT {wanted} - PERMISSION DENIED",
        f"IEE305I SMTPD IS LISTENING ON PORT {actual} INSTEAD",
        f"IEE305I MAIL WORKS, BUT A SCAN OF PORT {wanted} WILL FIND NOTHING",
        f"IEE305I FOR PORT {wanted} START GIBSON AS ROOT, OR RUN "
        "grant-port-capabilities.sh",
    )


def serve_smtp(state) -> ThreadedSmtpServer:
    SmtpHandler.state = state
    SmtpHandler.persona = build_persona()
    host = smtp_bind_host(state)
    wanted = int(getattr(state.config, "smtp_port", 2525) or 2525)
    port = wanted
    try:
        server = ThreadedSmtpServer((host, port), SmtpHandler)
    except PermissionError:
        # Ports below 1024 belong to root on both Linux and macOS, and the
        # frozen builds have no file capabilities to lean on, so an ordinary
        # user double-clicking the launcher cannot have port 25. Refusing
        # outright would leave the Office Mail client in M.8 with nothing to
        # talk to, so take a high port and say so loudly rather than dying
        # quietly. An explicitly requested port is never second-guessed.
        if port >= 1024 or smtp_port_was_set_explicitly():
            raise
        server = ThreadedSmtpServer((host, SMTP_FALLBACK_PORT), SmtpHandler)
        port = SMTP_FALLBACK_PORT
        for line in smtp_fallback_lines(wanted, port):
            print(line, flush=True)
            try:
                state.notify_console(line, severity="WARNING")
            except Exception:
                pass
    # Record where the listener actually landed. Everything that reports on
    # SMTPD (the service table, D SVC,L, the dashboard) reads the config, so
    # without this a fallback would be invisible and D SVC,L would name a
    # port nothing is listening on.
    state.smtp_effective_port = port
    try:
        state.config.smtp_port = port
    except Exception:
        pass
    threading.Thread(target=server.serve_forever, daemon=True, name="GibsonSMTP").start()
    return server
