"""
GIBSON pen-test browser shell (Phase 1).

An opt-in, localhost-bound, authenticated xterm.js terminal in the browser,
backed by an interactive shell in a pseudo-terminal. It is reached from the
8443 dashboard nav as "Tools" and runs on its own port (GIBSON_TOOLS_PORT,
default 8022) using the same websockets pattern as the 3270 web terminal.

Safety model (training lab):
  * Off unless GIBSON starts with --with-tools (or GIBSON_TOOLS_ENABLED=1).
  * Bound to 127.0.0.1 by default.
  * Behind HTTP Basic auth (the dashboard credentials).
  * Every session runs under ~/mfsim/pentest with a scope-restricted PATH:
    the bundled wrappers refuse any target that is not 127.0.0.1 / localhost
    / ::1 / sighberbank.com (+ subdomains), and print the authorised-targets
    banner on login.

Terminal backends:
  * Linux / macOS - the stdlib `pty` (fork + exec an interactive bash).
  * Windows        - ConPTY via the `pywinpty` package. GIBSON picks the best
                     available shell in this order: bash (Git for Windows / WSL
                     bash), BusyBox `ash`, PowerShell, then cmd.exe. Whichever
                     shell is used, the same target allowlist is enforced -
                     bash/BusyBox use the POSIX scope wrappers, PowerShell uses
                     generated scope functions, cmd.exe uses .cmd wrappers.
If the chosen platform has no usable PTY backend (for example Windows without
pywinpty installed), the service reports that cleanly over the socket instead
of failing silently.
"""
from __future__ import annotations

import base64
import json
import os
import secrets
import shutil
import subprocess
import sys
import threading
import time
from datetime import datetime
from pathlib import Path
from typing import Optional
from urllib.parse import parse_qs


def _dbg(msg: str) -> None:
    if os.getenv("GIBSON_SHELL_DEBUG"):
        try:
            sys.stderr.write(f"[tools_shell] {msg}\n")
            sys.stderr.flush()
        except Exception:
            pass


def _clean_child_env(base: Optional[dict] = None) -> dict:
    """Return an environment safe for launching a *system* program from inside
    a frozen (PyInstaller) GIBSON. PyInstaller points the dynamic loader at its
    own bundled libraries via LD_LIBRARY_PATH / DYLD_* while it runs, and saves
    the caller's original values with a _ORIG suffix. A shell or tool launched
    with the frozen values can fail to start or load the wrong libraries, so we
    restore the originals (or drop the var entirely when there was none) before
    handing the environment to the child."""
    env = dict(base if base is not None else os.environ)
    for var in ("LD_LIBRARY_PATH", "DYLD_LIBRARY_PATH", "DYLD_FRAMEWORK_PATH",
                "LD_PRELOAD", "DYLD_INSERT_LIBRARIES"):
        orig = env.pop(var + "_ORIG", None)
        if orig:
            env[var] = orig
        elif getattr(sys, "frozen", False):
            env.pop(var, None)
    return env

# Allowed targets for the sandbox wrappers.
SCOPE = ["127.0.0.1", "localhost", "::1", "sighberbank.com", "*.sighberbank.com"]

# Network tools that get a scope-guarded wrapper on every platform. The wrapper
# checks the targets and then runs the system binary of the same name; it is not
# a copy of that binary, so on a machine that does not have one the wrapper's
# job is to say so usefully.
_SANDBOX_TOOLS = ("nmap", "ping", "curl", "wget", "dig", "host", "nc", "hydra", "nikto")

# What to add after "run toolbox-setup" for the tools where the honest answer
# is more specific than that. macOS ships curl, nc, ping, dig and host, so the
# ones that actually go missing there are nmap, wget, hydra and nikto; Windows
# ships little beyond curl and ping.
_MISSING_TOOL_HINT = {
    # No "brew install" advice here: on a Mac this shell is usually root, and
    # Homebrew refuses root, which toolbox-setup handles and a bare brew does not.
    "nmap":  "; where no package has it, toolbox-setup builds it from GitHub.",
    "wget":  "; where no package has it, toolbox-setup builds it from GNU's source.",
    "hydra": "; where no package has it, toolbox-setup builds it from GitHub.",
    "nikto": "; where no package has it, toolbox-setup builds it from GitHub.",
}

# Bundled course tools: launcher name -> path under the workspace tools/ dir.
# Only runnable tools are listed; NJElib/njecli.py is a shared helper library
# with no entry point, so it is deliberately not exposed as a command.
_COURSE_TOOLS = {
    "ezrecon":    "EZRecon/EZrecon.py",
    "zniff":      "zniff/Zniff.py",
    "tshocker":   "TShOcker/TShOcker3.py",
    "cicspwn":    "cicspwn/cicspwn/cicspwn.py",
    "injector":   "NJElib/iNJEctor.py",
    "nje-assess": "NJElib/nje_assess.py",
    # Chapter 10 also drives these two from the NJElib clone.
    "njejcl":     "NJElib/jcl.py",
    "njeanalyze": "NJElib/analyze.py",
    # Chapter 8 PassTicket suite (Chad Rikansrud). Offline: they parse an
    # exfiltrated RACF database and compute keys, so they make no connection.
    "parse_db_ptkt":     "passTicket-tools/parse_db_ptkt.py",
    "unmask_passticket": "passTicket-tools/unmask_passticket.py",
    "gen_passticket":    "passTicket-tools/gen_passticket.py",
    # Core (terminal + audit) PHOSPHOR for Chapter 13. The desktop GUI / glass
    # CRT is not bundled (it needs pygame/moderngl); run_phosphor.py launches
    # phosphor's CLI inside GIBSON's own Python. `--client` needs no unlock;
    # `--scan` / `--menu` need the book unlock code.
    "phosphor":   "PHOSPHOR/run_phosphor.py",
    # GIBSON's own TCP connect scanner, so the chapter 6 discovery exercise
    # works on a machine with no nmap, which on macOS and Windows is every
    # machine until somebody installs it. It is not nmap and says so.
    "gibson-scan": "GIBSONscan/gibson_scan.py",
}


# Course tools that never open a network connection. They work on local files
# and values (an exfiltrated RACF database, a masked key, a capture), and their
# arguments include z/OS dataset names such as SYS1.RACFDS which look exactly
# like hostnames to the target checker. Scope-checking them would block valid
# use while protecting nothing, so their launchers skip the check.
_OFFLINE_TOOLS = {
    "parse_db_ptkt", "unmask_passticket", "gen_passticket", "njeanalyze",
}


def _scope_check_body() -> str:
    """Python source (no shebang) for the scope checker. One file, scope_check.py,
    serves every platform and every wrapper, run through the GIBSON binary's own
    Python rather than a system one. It treats only host-like
    arguments as targets: URLs are reduced to their host, local files and
    non-host filenames (wordlists, JCL, configs) are ignored, and the remaining
    host/IP tokens must match the allowlist or the process exits 7."""
    return (
        "import sys, os, fnmatch\n"
        "try:\n"
        "    from urllib.parse import urlparse\n"
        "except Exception:\n"
        "    urlparse = None\n"
        "SCOPE = " + repr(SCOPE) + "\n"
        "SKIP_EXT = ('.txt','.lst','.json','.csv','.tsv','.xml','.yaml','.yml','.cfg',\n"
        "            '.conf','.ini','.log','.py','.md','.html','.htm','.xlsx','.xls',\n"
        "            '.pcap','.jcl','.crt','.key','.pem','.cer')\n"
        "def host_of(a):\n"
        "    if '://' in a and urlparse:\n"
        "        u = urlparse(a); a = u.netloc or u.path\n"
        "    a = a.split('@')[-1].split('/')[0]\n"
        "    if a.count(':') == 1:\n"
        "        a = a.split(':')[0]\n"
        "    return a.strip().lower()\n"
        "def is_target(a):\n"
        "    if not a or a.startswith('-'): return False\n"
        "    if os.path.exists(a): return False\n"
        "    if a.lower().endswith(SKIP_EXT): return False\n"
        "    h = host_of(a)\n"
        "    return bool(h) and ('.' in h or ':' in h or h == 'localhost')\n"
        "def ok(t):\n"
        "    t = host_of(t)\n"
        "    if not t: return True\n"
        "    for s in SCOPE:\n"
        "        if t == s or fnmatch.fnmatch(t, s): return True\n"
        "    return False\n"
        # A target never contains whitespace, so an argument that does is split
        # and each piece judged on its own. That fixes a false positive, where
        # a format string such as -w 'code:%{http_code} time:%{time_total}'
        # was read as one host-like token because it holds two colons, and it
        # tightens the gate rather than loosening it, because a host smuggled
        # inside a whitespace-joined argument is now checked too.
        "cands = [p for a in sys.argv[1:] for p in a.split()]\n"
        "bad = [p for p in cands if is_target(p) and not ok(p)]\n"
        "if bad:\n"
        "    sys.stderr.write('[sandbox] BLOCKED out-of-scope target(s): ' + ', '.join(bad) + '\\n')\n"
        "    sys.stderr.write('[sandbox] allowed: 127.0.0.1, localhost, sighberbank.com (+subdomains)\\n')\n"
        "    sys.exit(7)\n"
        "sys.exit(0)\n"
    )

_IS_WINDOWS = os.name == "nt"

# POSIX PTY backend (Linux / macOS).
_HAS_PTY = False
try:
    if not _IS_WINDOWS:
        import pty as _pty  # noqa: F401  (Unix only)
        import select as _select
        import struct as _struct
        import fcntl as _fcntl
        import termios as _termios
        import signal as _signal
        _HAS_PTY = True
except Exception:
    _HAS_PTY = False


def _has_winpty() -> bool:
    """True when the Windows ConPTY backend (pywinpty) is importable."""
    if not _IS_WINDOWS:
        return False
    try:
        import winpty  # noqa: F401
        return True
    except Exception:
        return False


def _tools_port(state) -> int:
    try:
        return int(os.getenv("GIBSON_TOOLS_PORT", "8022") or 8022)
    except ValueError:
        return 8022


def _pentest_root(state) -> Path:
    base = os.getenv("GIBSON_SIM_ROOT")
    root = (Path(base).expanduser() if base else Path.home() / "mfsim") / "pentest"
    return root


_BANNER = r"""
============================================================================
  GIBSON PEN-TEST SHELL   (authorised training use only)

  AUTHORISED TARGETS ONLY
    127.0.0.1            the local GIBSON lab
    sighberbank.com      your educational FFS / FIBS bank (and *.sighberbank.com)
  All other targets are blocked by the sandbox wrappers.

  Wordlists in ./wordlists/  users.txt  passwords.txt  subdomains.txt
                             domains.txt  wordlist.txt
  Course tools on PATH       ezrecon  zniff  tshocker  cicspwn  injector
                             njejcl  nje-assess  phosphor  gibson-scan
                             (sources under ./tools/)
  Scanning                   gibson-scan 127.0.0.1 -sV   works with no install
                             nmap needs the system binary: run  toolbox-setup
  Type  scope  to see the target policy, or  tools  to list everything.
============================================================================
"""


def _sync_tool_trees(src_tools: Path, tools_dir: Path) -> None:
    """Bring the workspace's tools/ up to date with the bundled trees.

    This used to be a single copytree guarded by "only if tools/ does not
    exist", which is correct on a fresh machine and wrong on every upgrade. A
    workspace seeded by an earlier GIBSON keeps whatever trees that version
    shipped, so the tools added since (PHOSPHOR, the PassTicket suite, the z/OS
    Enumeration toolkit, CATMAP, Privesc, racfhound) never arrive, while the
    launchers for them are written regardless and point at paths that are not
    there. The student then gets "[sandbox] phosphor not found at ..." and no
    clue why.

    So: any tree that is missing is copied in, and inside a tree that is
    already there, missing files are added. An existing file is never
    overwritten, because the whole point of copying the tools into the
    workspace is that students can edit them, and an upgrade should not quietly
    revert someone's work. The cost of that choice is that an upstream fix to a
    file you already have does not reach you, so GIBSON_PENTEST_REFRESH=1
    forces a clean copy, moving the old tools/ aside rather than deleting it.
    """
    tools_dir.mkdir(parents=True, exist_ok=True)
    if os.getenv("GIBSON_PENTEST_REFRESH", "") in ("1", "true", "TRUE", "yes"):
        keep = tools_dir.with_name(
            f"{tools_dir.name}.bak-{datetime.now().strftime('%Y%m%d-%H%M%S')}")
        try:
            tools_dir.rename(keep)
            print(f"[GIBSON] pen-test tools refreshed; previous copy kept at {keep}",
                  flush=True)
        except Exception:
            pass
        tools_dir.mkdir(parents=True, exist_ok=True)

    for src in sorted(src_tools.iterdir()):
        dst = tools_dir / src.name
        if src.is_dir():
            if not dst.exists():
                shutil.copytree(src, dst)
                continue
            for sub in src.rglob("*"):
                rel = sub.relative_to(src)
                target = dst / rel
                if sub.is_dir():
                    target.mkdir(parents=True, exist_ok=True)
                elif not target.exists():
                    target.parent.mkdir(parents=True, exist_ok=True)
                    shutil.copyfile(sub, target)
        elif src.is_file() and not dst.exists():
            shutil.copyfile(src, dst)


def _seed_workspace(state) -> Path:
    """Create ~/mfsim/pentest with the wordlists, scope wrappers and banner."""
    root = _pentest_root(state)
    bind = root / "bin"
    wl = root / "wordlists"
    for d in (root, bind, wl):
        d.mkdir(parents=True, exist_ok=True)

    tools_dir = root / "tools"

    # Wordlists: copy the whole bundled wordlists/ set (users, passwords,
    # subdomains, domains, and the Chapter 6 wordlist.txt) into the workspace.
    try:
        assets = Path(state.config.assets_dir) / "pentest"
        src_wl = assets / "wordlists"
        if src_wl.is_dir():
            for src in src_wl.iterdir():
                if src.is_file():
                    dst = wl / src.name
                    if not dst.exists():
                        shutil.copyfile(src, dst)
        # Chapter 6 runs `--wordlist wordlist.txt` from the working directory,
        # so drop a copy at the workspace root for that exact command.
        wlist = src_wl / "wordlist.txt"
        if wlist.exists() and not (root / "wordlist.txt").exists():
            shutil.copyfile(wlist, root / "wordlist.txt")
    except Exception:
        pass

    # Bundled course tools: sync the trees into the workspace so students can
    # read, run and edit them. The launchers written below point straight at
    # these paths, so a tree that never arrives turns its tool into a
    # "[sandbox] not found" message.
    try:
        src_tools = Path(state.config.assets_dir) / "pentest" / "tools"
        if src_tools.is_dir():
            _sync_tool_trees(src_tools, tools_dir)
    except Exception:
        pass

    pyexe = sys.executable or "python3"
    # In a frozen PyInstaller build, sys.executable is the GIBSON binary, not a
    # Python interpreter, so a bundled .py is run via `gibson --run-tool <py>`,
    # which executes it inside GIBSON's bundled Python (with the tool deps). In a
    # normal (pip/venv) install, sys.executable is Python, so run it directly.
    _frozen = bool(getattr(sys, "frozen", False))
    run_prefix = f'"{pyexe}" --run-tool' if _frozen else f'"{pyexe}"'

    # scope-check: exits 0 if every target arg is in scope, else 7.
    #
    # It is a bash shim onto scope_check.py rather than a python script with a
    # "#!/usr/bin/env python3" line, because a stock macOS has no python3 on
    # PATH; typing it only offers to install the Xcode command line tools. With
    # the old shebang the checker could not start on such a Mac, and since the
    # wrappers refuse the command when the checker fails, EVERY system tool was
    # blocked with exit 7 whether or not it was installed. Routing through
    # run_prefix uses the GIBSON binary's own bundled Python in a frozen build,
    # which is always present, and the venv's Python in a source install.
    (bind / "scope_check.py").write_text(_scope_check_body(), encoding="utf-8")
    scope_check = bind / "scope-check"
    scope_check.write_text(
        "#!/usr/bin/env bash\n"
        f"exec {run_prefix} \"{bind}/scope_check.py\" \"$@\"\n",
        encoding="utf-8")
    os.chmod(scope_check, 0o755)

    # A 'scope' convenience and a 'tools' listing.
    (bind / "scope").write_text(
        "#!/usr/bin/env bash\n"
        "echo 'AUTHORISED TARGETS: 127.0.0.1, localhost, sighberbank.com (+ *.sighberbank.com)'\n"
        "echo 'Everything else is blocked by the sandbox wrappers.'\n",
        encoding="utf-8",
    )
    os.chmod(bind / "scope", 0o755)
    (bind / "tools").write_text(
        "#!/usr/bin/env bash\n"
        "echo 'Scope-guarded network helpers on PATH:'\n"
        "for t in " + " ".join(_SANDBOX_TOOLS) + "; do\n"
        "  if [ -x \"$(dirname \"$0\")/$t\" ]; then printf '  %-10s (scope-guarded)\\n' \"$t\"; fi\n"
        "done\n"
        "echo\n"
        "echo 'Bundled course tools on PATH (under ./tools):'\n"
        "for t in " + " ".join(_COURSE_TOOLS.keys()) + "; do\n"
        "  if [ -x \"$(dirname \"$0\")/$t\" ]; then printf '  %-10s\\n' \"$t\"; fi\n"
        "done\n"
        "echo\n"
        "echo 'Wordlists in ./wordlists : users.txt passwords.txt subdomains.txt domains.txt wordlist.txt'\n"
        "echo\n"
        "echo 'Examples:'\n"
        "echo '  gibson-scan 127.0.0.1 -sV                built-in scanner, needs no install'\n"
        "echo '  nmap -p- 127.0.0.1                       real nmap, via toolbox-setup'\n"
        "echo '  ezrecon subdomains --wordlist wordlist.txt sighberbank.com'\n"
        "echo '  phosphor 127.0.0.1 --client              TN3270 terminal (no unlock code)'\n"
        "echo '  phosphor 127.0.0.1 --scan --yes          recon/audit (needs book unlock code)'\n"
        "echo '  phosphor 127.0.0.1 --menu --yes          interactive recon menu'\n"
        "echo '  njejcl HAL GIBSON 127.0.0.1 JCL/tso.jcl RUARIV HAL123   (ch10)'\n"
        "echo '  parse_db_ptkt SYS1.RACFDS                (ch8 PassTicket)'\n"
        "echo '  unmask_passticket <masked-key>           (ch8)'\n"
        "echo '  gen_passticket -u IBMUSER -a TSO -s <key> (ch8)'\n"
        "echo\n"
        "echo 'Installed on demand (run once, needs internet):'\n"
        "echo '  toolbox-setup      the system tools the wrappers run: nmap, wget, nc ...'\n"
        "echo '  john-setup         jumbo John the Ripper: racf2john + RACF format (ch8)'\n"
        "echo '  bloodhound-setup   local BloodHound CE on 127.0.0.1:8080 (ch12)'\n"
        "echo '  racfhound-setup    RACFHound, then feed the graph to BloodHound (ch12)'\n"
        "echo\n"
        "echo 'z/OS-side toolkit (runs on the mainframe, upload it there):'\n"
        "echo '  enumeration        list the z/OS ENUM / ACCESS / APFCHECK / OMVS toolkit'\n",
        encoding="utf-8",
    )
    os.chmod(bind / "tools", 0o755)

    # z/OS enumeration toolkit (mainframed/Enumeration). These are REXX, JCL,
    # Java and C artifacts that run ON the mainframe rather than in this shell,
    # so they get a discovery helper instead of a scope-guarded launcher.
    (bind / "enumeration").write_text(
        "#!/usr/bin/env bash\n"
        "ROOT=\"$(cd \"$(dirname \"$0\")/..\" && pwd)\"\n"
        "E=\"$ROOT/tools/Enumeration\"\n"
        "echo 'z/OS ENUMERATION TOOLKIT   (mainframed/Enumeration, MIT licence)'\n"
        "echo \"Location: $E\"\n"
        "echo\n"
        "echo 'These run ON the mainframe, not in this shell. Upload them to the'\n"
        "echo 'lab host and run them there under TSO, JES batch or OMVS.'\n"
        "echo\n"
        "echo 'TSO / REXX / batch:'\n"
        "echo '  ENUM                 primary z/OS system + security enumerator (TSO)'\n"
        "echo '  ACCESS               effective SAF access helper (TSO load module)'\n"
        "echo '  APFCHECK             APF library audit job (JES batch)'\n"
        "echo '  PDSTEST.rexx         data set write test      (MODIFIES data)'\n"
        "echo '  PDSACCESSTEST.rexx   PDS member write test    (MODIFIES data)'\n"
        "echo '  Legacy/              SEARCHRX, SYS0WN, startmap, dsnsrch, exfil'\n"
        "echo\n"
        "echo 'z/OS UNIX (OMVS):'\n"
        "echo '  Unix/OMVSEnum.java      ordinary-user USS security enumeration'\n"
        "echo '  Unix/GhostWalker.java   recursive USS permission auditing'\n"
        "echo '  Unix/safauth.c          native SAF authorisation checks'\n"
        "echo '  Unix/UNIXENUM.sh        generates a deploy-and-run JCL job'\n"
        "echo '  Unix/README.md          full USS build and usage reference'\n"
        "echo\n"
        "echo 'Ready-made JCL in release/ :'\n"
        "ls \"$E/release\"/*.jcl 2>/dev/null | sed 's|.*/|  |'\n"
        "echo '  INSTALL.clist        TSO install driver'\n"
        "echo\n"
        "echo 'Transmit package: XMI/ENUM.XMI  (upload BINARY, then RECEIVE on z/OS)'\n"
        "echo 'Text members (ENUM, ACCESS, *.rexx, *.jcl) upload as ASCII.'\n"
        "echo\n"
        "echo 'Authorised training use only. PDSTEST, PDSACCESSTEST and exfil.rx'\n"
        "echo 'change or move data, so use disposable targets and read README.MD.'\n"
        "echo\n"
        "echo 'Other host-side source bundled alongside it, under ./tools :'\n"
        "echo '  CATMAP/      catalog + access mapper (GIBSON already implements'\n"
        "echo '               this: run  EX CATMAP  from the TSO READY prompt)'\n"
        "echo '  Privesc/     ELV.SVC, ELV.SELF, ELV.APF (GIBSON implements ELV.SVC'\n"
        "echo '               and ELV.SELF: run  EX ELV.SVC LIST  from READY)'\n"
        "echo '  racfhound/   RACFHound source for reference (chapter 12). It needs'\n"
        "echo '               its own pip install plus a BloodHound instance, so it'\n"
        "echo '               is not wired as a command here.'\n",
        encoding="utf-8",
    )
    os.chmod(bind / "enumeration", 0o755)

    # Scope-guarded wrappers: check the targets, then exec the REAL tool from
    # the system PATH. The wrappers enforce scope; they do not contain the
    # binaries, because shipping nmap, hydra and nikto inside a training
    # installer means shipping and signing someone else's security tools for
    # three platforms. So when one is absent the wrapper has to say what to do
    # about it, and for nmap it can do better than that: GIBSON has its own
    # connect scanner, which is enough for the chapter 6 discovery exercise, so
    # the lab is never simply dead on a machine without nmap.
    for tool in _SANDBOX_TOOLS:
        w = bind / tool
        hint = _MISSING_TOOL_HINT.get(tool, "")
        fallback = ""
        if tool == "nmap":
            fallback = (
                "  if [ -x \"$self/gibson-scan\" ]; then\n"
                "    echo '[sandbox] falling back to GIBSON built-in scanner.'\n"
                "    exec \"$self/gibson-scan\" \"$@\"\n"
                "  fi\n")
        elif tool == "wget":
            fallback = (
                "  if command -v curl >/dev/null 2>&1; then\n"
                "    echo '[sandbox] wget is missing; curl is installed and does the same job:'\n"
                "    echo '[sandbox]   curl -O <url>'\n"
                "  fi\n")
        w.write_text(
            "#!/usr/bin/env bash\n"
            f"{run_prefix} \"{bind}/scope_check.py\" \"$@\" || exit 7\n"
            "# find the real tool beyond our bin/ dir\n"
            "self=\"$(cd \"$(dirname \"$0\")\" && pwd)\"\n"
            "real=\"\"\n"
            "IFS=':' read -ra parts <<< \"$PATH\"\n"
            "for p in \"${parts[@]}\"; do\n"
            f"  if [ \"$p\" != \"$self\" ] && [ -x \"$p/{tool}\" ]; then real=\"$p/{tool}\"; break; fi\n"
            "done\n"
            "if [ -z \"$real\" ]; then\n"
            f"  echo '[sandbox] {tool} is not installed on this machine.'\n"
            f"  echo '[sandbox] Run  toolbox-setup  to install it{hint}'\n"
            + fallback +
            "  exit 127\n"
            "fi\n"
            "exec \"$real\" \"$@\"\n",
            encoding="utf-8",
        )
        os.chmod(w, 0o755)

    # Bundled course-tool launchers: scope-check the arguments, then run the
    # tool with the same Python that runs GIBSON (so the [pentest] extra deps
    # resolve). Targets are still confined to the allowlist.
    for name, relpath in _COURSE_TOOLS.items():
        w = bind / name
        target = root / "tools" / relpath
        gate = ("" if name in _OFFLINE_TOOLS
                else f"{run_prefix} \"{bind}/scope_check.py\" \"$@\" || exit 7\n")
        w.write_text(
            "#!/usr/bin/env bash\n"
            + gate
            + f"TOOL=\"{target}\"\n"
            "if [ ! -f \"$TOOL\" ]; then echo \"[sandbox] " + name + " not found at $TOOL\"; exit 127; fi\n"
            f"exec {run_prefix} \"$TOOL\" \"$@\"\n",
            encoding="utf-8",
        )
        os.chmod(w, 0o755)

    # rcfile: banner + prompt + cd into the workspace.
    rc = root / ".gibson_shellrc"
    # On a Mac, Homebrew's folders go on the end of PATH whether or not they
    # exist yet. GIBSON started from the app, or through sudo, usually has
    # neither on PATH, so tools toolbox-setup installed with Homebrew were
    # reported missing by the wrappers. Adding them unconditionally means a
    # Homebrew installed during this very session is found without reopening it.
    brew_dirs = ""
    if sys.platform == "darwin":
        brew_dirs = (
            "for d in /opt/homebrew/bin /opt/homebrew/sbin /usr/local/bin /usr/local/sbin; do\n"
            "  case \":$PATH:\" in *\":$d:\"*) ;; *) PATH=\"$PATH:$d\" ;; esac\n"
            "done\n")
    rc.write_text(
        "export PS1='\\[\\e[92m\\]gibson-pentest\\[\\e[0m\\]:\\[\\e[96m\\]\\w\\[\\e[0m\\]$ '\n"
        + brew_dirs +
        # opt/bin holds what toolbox-setup and john-setup built from GitHub. It
        # sits straight after the wrappers, so a jumbo John built there wins
        # over a distribution's core john, and the wrappers still come first.
        f"export PATH=\"{bind}:{root / 'opt' / 'bin'}:$PATH\"\n"
        f"cd \"{root}\" 2>/dev/null\n"
        "cat .gibson_banner 2>/dev/null\n",
        encoding="utf-8",
    )
    (root / ".gibson_banner").write_text(_BANNER, encoding="utf-8")

    # Setup helpers for the course tools that are installed on demand rather
    # than frozen in: jumbo John (racf2john + the RACF crack format), a local
    # BloodHound, and RACFHound. They live as assets so they stay readable.
    try:
        setup_src = Path(state.config.assets_dir) / "pentest" / "setup"
        if setup_src.is_dir():
            for src in setup_src.iterdir():
                if src.is_file():
                    dst = bind / src.name
                    shutil.copyfile(src, dst)
                    os.chmod(dst, 0o755)
    except Exception:
        pass

    # Launchers we no longer ship: remove them rather than leave a dead command
    # on PATH. Everything written above is rewritten on every start, so it
    # heals itself across an upgrade, but a launcher whose name has gone
    # (njecli became njejcl) is never rewritten and keeps pointing at a tool
    # path and a GIBSON binary that have both moved on. A manifest of what we
    # wrote this run is what lets the next run tell its own leftovers from a
    # student's own scripts, which are never touched.
    ours = set(_SANDBOX_TOOLS) | set(_COURSE_TOOLS) | {
        "scope", "scope-check", "scope_check.py", "tools", "enumeration",
    }
    try:
        ours |= {f.name for f in (Path(state.config.assets_dir) / "pentest"
                                  / "setup").iterdir() if f.is_file()}
    except Exception:
        pass
    ours |= {f"{n}.cmd" for n in ours
             if not n.endswith(".py") and not n.endswith(".cmd")}
    manifest = bind / ".gibson-launchers"
    try:
        previous = set(manifest.read_text(encoding="utf-8").split())
    except Exception:
        # First run under this scheme. Seed it with the names GIBSON has
        # shipped and since dropped, so one upgrade is enough to clear them.
        previous = {"njecli", "njecli.cmd"}
    for stale in sorted(previous - ours):
        try:
            (bind / stale).unlink()
        except Exception:
            pass
    try:
        manifest.write_text("\n".join(sorted(ours)) + "\n", encoding="utf-8")
    except Exception:
        pass

    # Windows scope artifacts (used by the ConPTY backend). Cheap to write on
    # any OS; they are only consulted when the shell runs on Windows.
    _seed_windows_scope(root, bind)
    return root


def _seed_windows_scope(root: Path, bind: Path) -> None:
    """Write the Windows-side scope enforcement: a portable Python scope check,
    .cmd wrappers (cmd.exe), a PowerShell profile with scope functions, a bash
    rcfile that works under Git Bash / BusyBox ash, and a cmd banner printer.

    The POSIX wrappers already written into bin/ cover bash and BusyBox ash.
    These add equivalent enforcement for PowerShell and cmd.exe, so the target
    allowlist holds whichever shell ConPTY ends up driving."""
    pyexe = sys.executable or "python"
    scope_list = ", ".join(SCOPE)
    # Frozen build: run bundled .py through `gibson.exe --run-tool` (see the
    # POSIX launchers above for the rationale).
    _frozen = bool(getattr(sys, "frozen", False))
    win_run_prefix = f'"{pyexe}" --run-tool' if _frozen else f'"{pyexe}"'

    # scope_check.py is already written by _seed_workspace, which every
    # platform runs, and the .cmd wrappers below invoke that same file.

    # cmd.exe wrappers: scope-check, then run the real <tool>.exe if present.
    # Same reasoning as the POSIX wrappers: the wrapper enforces scope, it does
    # not carry the binary, so a missing tool gets told how to arrive. nmap
    # falls back to GIBSON's own scanner so the chapter 6 exercise still runs.
    for tool in _SANDBOX_TOOLS:
        wfall = ""
        tail = "  exit /b 127\r\n"
        if tool == "nmap":
            # A bare "exit /b" returns the command's own ERRORLEVEL. Writing
            # "exit /b %errorlevel%" here would not: cmd.exe expands %VAR% when
            # it parses the whole parenthesised block, so the value would be
            # whatever ERRORLEVEL held BEFORE the scanner ran.
            wfall = ("  echo [sandbox] falling back to GIBSON built-in scanner.\r\n"
                     f"  {win_run_prefix} \"{root / 'tools' / _COURSE_TOOLS['gibson-scan']}\" %*\r\n"
                     "  exit /b\r\n")
            tail = ""          # the fallback always exits, so 127 is dead here
        elif tool == "wget":
            wfall = ("  echo [sandbox] curl ships with Windows and does the same job: curl -O ^<url^>\r\n")
        (bind / f"{tool}.cmd").write_text(
            "@echo off\r\n"
            "setlocal\r\n"
            f"{win_run_prefix} \"%~dp0scope_check.py\" %*\r\n"
            "if errorlevel 1 exit /b 7\r\n"
            f"where /q {tool}.exe\r\n"
            "if errorlevel 1 (\r\n"
            f"  echo [sandbox] {tool} is not installed on this machine.\r\n"
            "  echo [sandbox] Run  toolbox-setup.cmd  to install it with winget.\r\n"
            + wfall
            + tail +
            ")\r\n"
            f"{tool}.exe %*\r\n",
            encoding="utf-8",
        )
    (bind / "scope.cmd").write_text(
        "@echo off\r\n"
        f"echo AUTHORISED TARGETS: {scope_list}\r\n"
        "echo Everything else is blocked by the sandbox wrappers.\r\n",
        encoding="utf-8",
    )
    (bind / "tools.cmd").write_text(
        "@echo off\r\n"
        "echo Scope-guarded network helpers on PATH:\r\n"
        + "".join(f"echo    {t} (scope-guarded)\r\n" for t in _SANDBOX_TOOLS)
        + "echo.\r\n"
        + "echo Bundled course tools on PATH:\r\n"
        + "".join(f"echo    {t}\r\n" for t in _COURSE_TOOLS.keys())
        + "echo.\r\n"
        + "echo Wordlists in wordlists\\ : users.txt passwords.txt subdomains.txt domains.txt wordlist.txt\r\n",
        encoding="utf-8",
    )

    # cmd.exe launchers for the bundled course tools (scope-check then run with
    # the GIBSON Python interpreter).
    for name, relpath in _COURSE_TOOLS.items():
        target = str(root / "tools" / relpath)
        wgate = ("" if name in _OFFLINE_TOOLS else
                 f"{win_run_prefix} \"%~dp0scope_check.py\" %*\r\n"
                 "if errorlevel 1 exit /b 7\r\n")
        (bind / f"{name}.cmd").write_text(
            "@echo off\r\n"
            "setlocal\r\n"
            + wgate
            + f"if not exist \"{target}\" ( echo [sandbox] {name} not found & exit /b 127 )\r\n"
            + f"{win_run_prefix} \"{target}\" %*\r\n",
            encoding="utf-8",
        )

    # cmd.exe banner printer (cmd /K runs this, then stays interactive).
    (root / "gibson_banner.cmd").write_text(
        "@echo off\r\n"
        "type \"%~dp0.gibson_banner\" 2>nul\r\n",
        encoding="utf-8",
    )

    # bash/BusyBox rcfile for Windows: PATH comes from the environment and the
    # working directory is set at spawn, so this only sets the prompt and prints
    # the banner from HOME (which the backend points at the workspace).
    (root / ".gibson_shellrc_win").write_text(
        "export PS1='gibson-pentest:\\w$ '\n"
        "cat \"$HOME/.gibson_banner\" 2>/dev/null\n",
        encoding="utf-8",
    )

    # PowerShell profile: banner, PATH, and scope-enforcing wrapper functions
    # that shadow the real network tools and launch the bundled course tools.
    net_fns = "\n".join(f"function {t} {{ _Gibson-Run '{t}' $args }}" for t in _SANDBOX_TOOLS)
    course_fns = "\n".join(
        "function {n} {{ {fn} '{p}' $args }}".format(
            n=name,
            fn=("_Gibson-RunToolNoScope" if name in _OFFLINE_TOOLS else "_Gibson-RunTool"),
            p=str(root / "tools" / relpath))
        for name, relpath in _COURSE_TOOLS.items()
    )
    (root / "gibson_profile.ps1").write_text(
        "$here = Split-Path -Parent $MyInvocation.MyCommand.Path\r\n"
        "if (Test-Path \"$here\\.gibson_banner\") { Get-Content \"$here\\.gibson_banner\" }\r\n"
        f"$env:PATH = \"{bind}\" + [IO.Path]::PathSeparator + $env:PATH\r\n"
        f"$GibsonPy = \"{pyexe}\"\r\n"
        f"$GibsonFrozen = ${str(_frozen).lower()}\r\n"
        "$GibsonScope = @('127.0.0.1','localhost','::1','sighberbank.com','*.sighberbank.com')\r\n"
        "$GibsonSkipExt = @('.txt','.lst','.json','.csv','.xml','.yaml','.yml','.cfg','.conf','.log','.py','.md','.html','.xlsx','.jcl','.pcap','.crt','.key','.pem')\r\n"
        "function _Gibson-Host([string]$x) {\r\n"
        "  if ($x -match '://') { $x = ($x -split '://',2)[1] }\r\n"
        "  $x = ($x -split '/')[0]; $x = ($x -split '@')[-1]\r\n"
        "  if (($x.ToCharArray() | Where-Object { $_ -eq ':' }).Count -eq 1) { $x = ($x -split ':')[0] }\r\n"
        "  return $x.ToLower()\r\n"
        "}\r\n"
        "function _Gibson-Check([string[]]$a) {\r\n"
        "  $bad = @()\r\n"
        "  $pieces = @()\r\n"
        "  foreach ($arg in $a) { $pieces += ($arg -split '\\s+' | Where-Object { $_ -ne '' }) }\r\n"
        "  foreach ($x in $pieces) {\r\n"
        "    if ($x -match '^-') { continue }\r\n"
        "    if (Test-Path -LiteralPath $x) { continue }\r\n"
        "    $skip = $false; foreach ($e in $GibsonSkipExt) { if ($x.ToLower().EndsWith($e)) { $skip = $true; break } }\r\n"
        "    if ($skip) { continue }\r\n"
        "    $h = _Gibson-Host $x\r\n"
        "    if (-not ($h -match '\\.' -or $h -match ':' -or $h -eq 'localhost')) { continue }\r\n"
        "    $okk = $false\r\n"
        "    foreach ($s in $GibsonScope) { if ($h -eq $s -or $h -like $s) { $okk = $true; break } }\r\n"
        "    if (-not $okk) { $bad += $x }\r\n"
        "  }\r\n"
        "  return ,$bad\r\n"
        "}\r\n"
        "function _Gibson-Blocked([string[]]$a) {\r\n"
        "  $bad = _Gibson-Check $a\r\n"
        "  if ($bad.Count -gt 0) {\r\n"
        "    Write-Host \"[sandbox] BLOCKED out-of-scope target(s): $($bad -join ', ')\" -ForegroundColor Red\r\n"
        "    Write-Host '[sandbox] allowed: 127.0.0.1, localhost, sighberbank.com (+subdomains)'\r\n"
        "    return $true\r\n"
        "  }\r\n"
        "  return $false\r\n"
        "}\r\n"
        "function _Gibson-Run([string]$tool, [string[]]$a) {\r\n"
        "  if (_Gibson-Blocked $a) { return }\r\n"
        "  $exe = Get-Command \"$tool.exe\" -ErrorAction SilentlyContinue\r\n"
        "  if (-not $exe) {\r\n"
        "    Write-Host \"[sandbox] $tool is not installed on this machine.\"\r\n"
        "    Write-Host '[sandbox] Run  toolbox-setup.cmd  to install it with winget.'\r\n"
        "    if ($tool -eq 'nmap') {\r\n"
        "      Write-Host '[sandbox] falling back to GIBSON built-in scanner.'\r\n"
        f"      _Gibson-RunToolNoScope \"{root / 'tools' / _COURSE_TOOLS['gibson-scan']}\" $a\r\n"
        "    }\r\n"
        "    return\r\n"
        "  }\r\n"
        "  & $exe.Source @a\r\n"
        "}\r\n"
        "function _Gibson-RunToolNoScope([string]$path, [string[]]$a) {\r\n"
        "  if (-not (Test-Path -LiteralPath $path)) { Write-Host \"[sandbox] tool not found: $path\"; return }\r\n"
        "  if ($GibsonFrozen) { & $GibsonPy --run-tool $path @a } else { & $GibsonPy $path @a }\r\n"
        "}\r\n"
        "function _Gibson-RunTool([string]$path, [string[]]$a) {\r\n"
        "  if (_Gibson-Blocked $a) { return }\r\n"
        "  if (-not (Test-Path -LiteralPath $path)) { Write-Host \"[sandbox] tool not found: $path\"; return }\r\n"
        "  if ($GibsonFrozen) { & $GibsonPy --run-tool $path @a } else { & $GibsonPy $path @a }\r\n"
        "}\r\n"
        "function scope { Write-Host 'AUTHORISED TARGETS: 127.0.0.1, localhost, sighberbank.com (+ *.sighberbank.com)'; Write-Host 'Everything else is blocked by the sandbox wrappers.' }\r\n"
        + net_fns + "\r\n"
        + course_fns + "\r\n"
        "Set-Location $here\r\n",
        encoding="utf-8",
    )


def _auth_ok(headers) -> bool:
    user = os.getenv("GIBSON_DASHBOARD_USER", "admin")
    pw = os.getenv("GIBSON_DASHBOARD_PASSWORD", "gibsonadmin!")
    expected = "Basic " + base64.b64encode(f"{user}:{pw}".encode()).decode()
    try:
        got = headers.get("Authorization", "")
    except Exception:
        got = ""
    return got == expected


_PAGE = r"""<!doctype html>
<html><head><meta charset='utf-8'><meta name='viewport' content='width=device-width, initial-scale=1'>
<title>GIBSON Pen-Test Shell</title>
<link rel='stylesheet' href='xterm.css'/>
<style>
:root{--line:#0b5;}
*{box-sizing:border-box;}
body{margin:0;background:#020402;color:#8affa0;font-family:ui-monospace,Menlo,Consolas,monospace;}
nav{display:flex;gap:18px;align-items:center;padding:8px 18px;background:#030903;border-bottom:1px solid var(--line);}
nav .brand{color:#00ff66;font-weight:700;letter-spacing:1px;}
nav a{color:#bfffcf;text-decoration:none;} nav a.active{color:#ffd84d;}
.wrap{padding:10px;}
.bar{display:flex;gap:10px;align-items:center;margin-bottom:6px;}
.bar .status{margin-left:auto;font-size:12px;color:#9f9;}
#term{height:78vh;border:1px solid var(--line);padding:6px;background:#000;box-shadow:0 0 12px rgba(0,255,100,.08);}
.hint{color:#9f9;font-size:12px;margin:4px 0;}
</style></head><body>
<nav><span class='brand'>GIBSON</span><a id='dash'>Dashboard</a><a class='active'>&#9094; Pen-Test Shell</a></nav>
<div class='wrap'>
<div class='bar'><strong>Pen-Test Shell</strong><span style='color:#ff6ac1;font-size:12px'>scope: 127.0.0.1 + sighberbank.com</span><span class='status' id='status'>connecting...</span></div>
<div class='hint'>Authorised training use only. Targets are restricted to the lab and sighberbank.com by the sandbox. Type <b>scope</b> or <b>tools</b>.</div>
<div id='term'></div>
</div>
<script src='xterm.js'></script>
<script src='xterm-addon-fit.js'></script>
<script>
document.getElementById('dash').href = location.protocol+'//'+location.hostname+':8443/';
window.__WST__="__WS_TOKEN__";
const statusEl=document.getElementById('status');
const term=new Terminal({cursorBlink:true,fontSize:14,theme:{background:'#000000',foreground:'#8affa0',green:'#35f06a'}});
const fit=new FitAddon.FitAddon(); term.loadAddon(fit);
term.open(document.getElementById('term')); fit.fit(); term.focus();
function wsUrl(){ return (location.protocol==='https:'?'wss://':'ws://')+location.host+'/ws?t='+encodeURIComponent(window.__WST__||''); }
let ws, LINEMODE=false, ECHO=false, buf='';
function handleControl(s){
  if(s.length===0 || s[0]!=='{') return false;
  let m; try{ m=JSON.parse(s); }catch(_){ return false; }
  if(!m || typeof m!=='object' || !m.type) return false;
  if(m.type==='error'){ term.write('\r\n'+m.message+'\r\n'); return true; }
  if(m.type==='backend'){
    LINEMODE=!!m.linemode; ECHO=!!m.echo;
    statusEl.textContent='connected';
    term.write('\r\n[backend: '+(m.name||'shell')+']'+(LINEMODE?'  line mode - type a command and press Enter':'')+'\r\n');
    return true;
  }
  return false;
}
function connect(){
  ws=new WebSocket(wsUrl());
  ws.binaryType='arraybuffer';
  ws.onopen=()=>{ statusEl.textContent='connected'; sendResize(); };
  ws.onclose=()=>{ statusEl.textContent='disconnected'; term.write('\r\n[shell closed]\r\n'); };
  ws.onerror=()=>{ statusEl.textContent='error'; };
  ws.onmessage=(e)=>{ if(typeof e.data==='string'){ if(handleControl(e.data)) return; term.write(e.data);} else { term.write(new Uint8Array(e.data)); } };
}
function sendResize(){ if(ws&&ws.readyState===1 && !LINEMODE){ ws.send(JSON.stringify({type:'resize',cols:term.cols,rows:term.rows})); } }
function send(d){ if(ws&&ws.readyState===1) ws.send(JSON.stringify({type:'input',data:d})); }
term.onData(d=>{
  if(!ws||ws.readyState!==1) return;
  if(!LINEMODE){ send(d); return; }
  // Local line editor for the pipe backend (no server-side line discipline).
  if(d.charCodeAt(0)===27) return;               // ignore arrow/function keys
  for(const ch of d){
    if(ch==='\r'||ch==='\n'){ term.write('\r\n'); send(buf+'\n'); buf=''; }
    else if(ch==='\x7f'||ch==='\b'){ if(buf.length){ buf=buf.slice(0,-1); term.write('\b \b'); } }
    else if(ch==='\x03'){ term.write('^C\r\n'); send('\x03'); buf=''; }        // Ctrl+C
    else if(ch==='\x15'){ while(buf.length){ buf=buf.slice(0,-1); term.write('\b \b'); } } // Ctrl+U
    else if(ch>=' '){ buf+=ch; if(ECHO) term.write(ch); }
  }
});
window.addEventListener('resize',()=>{ try{fit.fit();}catch(_){} sendResize(); });
term.onResize(()=>sendResize());
connect();
</script>
</body></html>"""


class ToolsShellServer:
    def __init__(self, state):
        self.state = state
        self.host = "127.0.0.1"  # localhost-bound by default for safety
        self.port = _tools_port(state)
        self._server = None
        self._thread: Optional[threading.Thread] = None
        self._assets = Path(state.config.assets_dir) / "xterm"
        self._workspace = _seed_workspace(state)
        # Per-session token for the WebSocket. Browsers do not reliably send
        # HTTP Basic auth on a WebSocket handshake, so the page (which IS Basic
        # auth gated) carries this token in the /ws URL instead.
        self._token = secrets.token_urlsafe(24)

    def _asset(self, name: str):
        from websockets.http11 import Response
        from websockets.datastructures import Headers
        p = self._assets / name
        ctype = {"xterm.js": "application/javascript", "xterm-addon-fit.js": "application/javascript",
                 "xterm.css": "text/css"}.get(name, "application/octet-stream")
        try:
            body = p.read_bytes()
            return Response(200, "OK", Headers([("Content-Type", ctype), ("Cache-Control", "no-store")]), body)
        except Exception:
            return Response(404, "Not Found", Headers([("Content-Type", "text/plain")]), b"not found")

    def start(self):
        from websockets.sync.server import serve
        from websockets.http11 import Response
        from websockets.datastructures import Headers

        def _resp(code, reason, ctype, body):
            if isinstance(body, str):
                body = body.encode("utf-8")
            return Response(code, reason, Headers([("Content-Type", ctype), ("Cache-Control", "no-store")]), body)

        def _auth_challenge():
            return Response(401, "Unauthorized",
                            Headers([("WWW-Authenticate", 'Basic realm="GIBSON Tools"'),
                                     ("Content-Type", "text/plain")]), b"Authentication required")

        def process_request(conn, request):
            try:
                raw = request.path
                path = raw.split("?", 1)[0]
                query = raw.split("?", 1)[1] if "?" in raw else ""
                if path == "/ws":
                    # Browsers do not reliably send Basic auth on a WebSocket
                    # handshake, so accept the per-session token the (auth-gated)
                    # page carries, with a Basic-auth fallback.
                    tok = parse_qs(query).get("t", [""])[0]
                    if (tok and secrets.compare_digest(tok, self._token)) or _auth_ok(request.headers):
                        return None  # hand to WS handler
                    return _auth_challenge()
                # Everything else is gated by Basic auth.
                if not _auth_ok(request.headers):
                    return _auth_challenge()
                if path in ("/", "/index.html"):
                    page = _PAGE.replace("__WS_TOKEN__", self._token)
                    return _resp(200, "OK", "text/html; charset=utf-8", page)
                if path in ("/xterm.js", "/xterm.css", "/xterm-addon-fit.js"):
                    return self._asset(path.lstrip("/"))
                if path == "/health":
                    backend = "pty" if _HAS_PTY else ("conpty" if _has_winpty() else "none")
                    return _resp(200, "OK", "application/json",
                                 json.dumps({"ok": backend != "none", "backend": backend,
                                             "pty": _HAS_PTY, "windows": _IS_WINDOWS}))
                return _resp(404, "Not Found", "text/plain", "not found")
            except Exception as exc:
                return _resp(500, "Error", "text/plain", f"error: {exc}")

        self._server = serve(self._handle_ws, self.host, self.port,
                             process_request=process_request, compression=None,
                             ping_interval=20, ping_timeout=20,
                             server_header="GibsonToolsShell/1.0")
        self._thread = threading.Thread(target=self._server.serve_forever, daemon=True, name="GibsonToolsShell")
        self._thread.start()
        try:
            self.state.register_open_port(self.port, "TCP", "TOOLS")
        except Exception:
            pass
        return self

    def shutdown(self):
        try:
            if self._server:
                self._server.shutdown()
        except Exception:
            pass

    def server_close(self):
        self.shutdown()

    # ---- WebSocket dispatch: pick the PTY backend for this platform -----
    def _handle_ws(self, conn):
        # GIBSON_SHELL_BACKEND lets a user (or a test) force a backend:
        #   pty    - the POSIX pseudo-terminal (Linux/macOS)
        #   conpty - Windows ConPTY via pywinpty
        #   pipe   - the dependency-free pipe fallback (works everywhere)
        forced = os.getenv("GIBSON_SHELL_BACKEND", "").strip().lower()

        if forced == "pipe":
            return self._handle_ws_pipe(conn)
        if forced == "pty" and _HAS_PTY:
            return self._handle_ws_unix(conn)
        if forced == "conpty" and _IS_WINDOWS and _has_winpty():
            return self._handle_ws_windows(conn)

        # Default selection, best experience first, always ending at a backend
        # that works so the shell never just closes without a usable session.
        if _HAS_PTY:
            return self._handle_ws_unix(conn)
        if _IS_WINDOWS and _has_winpty():
            # Try ConPTY; if it cannot actually spawn (e.g. the native winpty
            # DLLs were not bundled), fall through to the pipe backend rather
            # than leaving the user with a dead terminal.
            if self._handle_ws_windows(conn):
                return
        # Universal fallback: a real shell over pipes, no native PTY required.
        return self._handle_ws_pipe(conn)

    def _send_err(self, conn, message: str) -> None:
        """Send an error the page will print, and give it a moment to flush
        before the handler returns and the socket closes."""
        try:
            conn.send(json.dumps({"type": "error", "message": message}))
            time.sleep(0.2)
        except Exception:
            pass

    # ---- the PTY bridge (Unix: Linux / macOS) ---------------------------
    def _handle_ws_unix(self, conn):
        env = _clean_child_env()
        env["TERM"] = "xterm-256color"
        env["HOME"] = str(self._workspace)
        env["GIBSON_SCOPE"] = ",".join(SCOPE)
        rc = str(self._workspace / ".gibson_shellrc")

        # Prefer bash with the scope rcfile; fall back to sh so a system without
        # bash still gets a working shell instead of an instant close.
        bash = shutil.which("bash")
        if bash:
            argv = [bash, "--rcfile", rc, "-i"]
            label = "bash"
        else:
            sh = shutil.which("sh") or "/bin/sh"
            argv = [sh, "-i"]
            label = "sh"
            env["ENV"] = rc  # POSIX sh sources $ENV on interactive start

        try:
            conn.send(json.dumps({"type": "backend", "name": f"PTY ({label})", "echo": False}))
        except Exception:
            pass

        pid, fd = _pty.fork()
        if pid == 0:
            try:
                os.chdir(str(self._workspace))
            except Exception:
                pass
            try:
                os.execvpe(argv[0], argv, env)
            except Exception as exc:
                # fd 1/2 are the PTY slave here, so this reaches the browser.
                os.write(2, f"[GIBSON] could not start {label}: {exc}\r\n".encode())
            os._exit(1)

        stop = threading.Event()

        def pty_to_ws():
            while not stop.is_set():
                try:
                    r, _, _ = _select.select([fd], [], [], 0.2)
                    if fd in r:
                        data = os.read(fd, 4096)
                        if not data:
                            break
                        conn.send(data.decode("utf-8", "replace"))
                except Exception:
                    break
            stop.set()
            try:
                conn.close()
            except Exception:
                pass

        t = threading.Thread(target=pty_to_ws, daemon=True)
        t.start()
        try:
            for msg in conn:
                try:
                    m = json.loads(msg) if isinstance(msg, str) else None
                except Exception:
                    m = None
                if not m:
                    continue
                if m.get("type") == "input":
                    try:
                        os.write(fd, str(m.get("data", "")).encode("utf-8"))
                    except Exception:
                        break
                elif m.get("type") == "resize":
                    try:
                        rows = int(m.get("rows", 24)); cols = int(m.get("cols", 80))
                        _fcntl.ioctl(fd, _termios.TIOCSWINSZ, _struct.pack("HHHH", rows, cols, 0, 0))
                    except Exception:
                        pass
        except Exception:
            pass
        finally:
            stop.set()
            try:
                os.close(fd)
            except Exception:
                pass
            try:
                os.kill(pid, _signal.SIGHUP)
            except Exception:
                pass
            try:
                os.waitpid(pid, 0)
            except Exception:
                pass

    # ---- shell selection for Windows ------------------------------------
    def _windows_shell(self):
        """Return (argv, env, label) for the best available Windows shell.

        Order of preference: bash (Git for Windows / WSL), BusyBox ash,
        PowerShell, then cmd.exe. bash and BusyBox reuse the POSIX scope
        wrappers; PowerShell uses the generated scope functions; cmd.exe uses
        the .cmd wrappers. In every case the target allowlist is enforced."""
        ws = self._workspace
        bindir = str(ws / "bin")
        env = dict(os.environ)
        env["TERM"] = "xterm-256color"
        env["HOME"] = str(ws)
        env["GIBSON_SCOPE"] = ",".join(SCOPE)

        def _with_bin_path(e):
            e = dict(e)
            e["PATH"] = bindir + os.pathsep + e.get("PATH", "")
            return e

        # 1. bash (Git for Windows, WSL bash, or any bash on PATH)
        bash = shutil.which("bash") or _find_git_bash()
        if bash:
            rc = str(ws / ".gibson_shellrc_win")
            return ([bash, "--rcfile", rc, "-i"], _with_bin_path(env), "bash")

        # 2. BusyBox ash (sources $ENV on interactive start)
        busybox = shutil.which("busybox")
        if busybox:
            e = _with_bin_path(env)
            e["ENV"] = str(ws / ".gibson_shellrc_win")
            return ([busybox, "sh", "-i"], e, "busybox-ash")

        # 3. PowerShell with the generated scope-enforcing profile
        ps = shutil.which("pwsh") or shutil.which("powershell")
        if ps:
            prof = str(ws / "gibson_profile.ps1")
            return ([ps, "-NoLogo", "-NoExit", "-ExecutionPolicy", "Bypass",
                     "-Command", ". '" + prof + "'"], dict(env), "powershell")

        # 4. cmd.exe last resort (.cmd wrappers on PATH, banner via /K)
        cmd = shutil.which("cmd") or os.environ.get("COMSPEC")
        if cmd:
            banner = str(ws / "gibson_banner.cmd")
            return ([cmd, "/K", banner], _with_bin_path(env), "cmd")

        return (None, env, "none")

    # ---- the ConPTY bridge (Windows, via pywinpty) ----------------------
    def _handle_ws_windows(self, conn) -> bool:
        """Returns True if a ConPTY session ran, False if ConPTY was not
        usable (so the caller can fall back to the pipe backend)."""
        try:
            from winpty import PtyProcess  # pywinpty
        except Exception:
            return False  # not importable -> let the pipe backend take over

        argv, env, label = self._windows_shell()
        if argv is None:
            return False  # no shell found -> pipe backend will report cleanly

        try:
            # pywinpty dimensions are (rows, cols).
            proc = PtyProcess.spawn(argv, cwd=str(self._workspace), env=env, dimensions=(24, 80))
        except Exception:
            # The native winpty DLLs are commonly not bundled into a frozen
            # build, so ConPTY import succeeds but spawn fails. Fall back.
            return False

        try:
            conn.send(json.dumps({"type": "backend", "name": f"ConPTY ({label})", "echo": False}))
        except Exception:
            pass

        stop = threading.Event()

        def pty_to_ws():
            while not stop.is_set():
                try:
                    data = proc.read(4096)  # returns str; blocks until data/EOF
                except EOFError:
                    break
                except Exception:
                    break
                if data:
                    try:
                        conn.send(data)
                    except Exception:
                        break
                else:
                    try:
                        if not proc.isalive():
                            break
                    except Exception:
                        break
            stop.set()
            try:
                conn.close()
            except Exception:
                pass

        t = threading.Thread(target=pty_to_ws, daemon=True)
        t.start()
        try:
            for msg in conn:
                try:
                    m = json.loads(msg) if isinstance(msg, str) else None
                except Exception:
                    m = None
                if not m:
                    continue
                if m.get("type") == "input":
                    try:
                        proc.write(str(m.get("data", "")))
                    except Exception:
                        break
                elif m.get("type") == "resize":
                    try:
                        rows = int(m.get("rows", 24)); cols = int(m.get("cols", 80))
                        proc.setwinsize(rows, cols)
                    except Exception:
                        pass
        except Exception:
            pass
        finally:
            stop.set()
            try:
                proc.close(force=True)
            except Exception:
                pass
        return True

    # ---- the dependency-free pipe backend (works everywhere) ------------
    def _handle_ws_pipe(self, conn):
        """A real interactive shell over OS pipes, needing no pseudo-terminal
        and no native libraries, so it works in any frozen build including
        Windows without pywinpty. The browser runs a local line editor (echo,
        backspace, history-free) and submits a whole line at a time, which is
        all the course tools need. Full-screen TUIs want the PTY/ConPTY backend
        instead."""
        if _IS_WINDOWS:
            argv, env, label = self._windows_shell()
            if argv is None:
                self._send_err(conn, "No usable shell found. Install Git for Windows "
                                     "(bash), or make sure powershell or cmd.exe is available.")
                return
        else:
            env = _clean_child_env()
            env["TERM"] = "dumb"
            env["HOME"] = str(self._workspace)
            env["GIBSON_SCOPE"] = ",".join(SCOPE)
            bash = shutil.which("bash")
            if bash:
                rc = str(self._workspace / ".gibson_shellrc")
                argv, label = [bash, "--rcfile", rc, "-i"], "bash"
            else:
                sh = shutil.which("sh") or "/bin/sh"
                argv, label = [sh, "-i"], "sh"
                env["ENV"] = str(self._workspace / ".gibson_shellrc")

        popen_kw = dict(cwd=str(self._workspace), env=env,
                        stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                        stderr=subprocess.STDOUT, bufsize=0)
        if _IS_WINDOWS:
            # Do not pop a console window for the child.
            popen_kw["creationflags"] = getattr(subprocess, "CREATE_NO_WINDOW", 0)

        _dbg(f"pipe: spawning {argv} label={label}")
        try:
            proc = subprocess.Popen(argv, **popen_kw)
        except Exception as exc:
            _dbg(f"pipe: Popen failed: {exc}")
            self._send_err(conn, f"Could not start the shell ({label}): {exc}")
            return

        # If the shell dies at once, read whatever it said and report it rather
        # than closing the socket with no explanation.
        time.sleep(0.4)
        _dbg(f"pipe: poll after 0.4s = {proc.poll()}")
        if proc.poll() is not None:
            tail = b""
            try:
                tail = proc.stdout.read() or b""
            except Exception:
                pass
            self._send_err(conn, f"The shell ({label}) exited immediately (code "
                                 f"{proc.returncode}). {tail.decode('utf-8', 'replace')[:400]}")
            return

        try:
            conn.send(json.dumps({"type": "backend", "name": f"pipe ({label})",
                                  "echo": True, "linemode": True}))
        except Exception:
            pass

        stop = threading.Event()
        out_fd = proc.stdout.fileno()

        def reader():
            while not stop.is_set():
                try:
                    data = os.read(out_fd, 4096)
                except Exception as exc:
                    _dbg(f"pipe reader: os.read error: {exc}")
                    break
                if not data:
                    _dbg("pipe reader: EOF from shell stdout")
                    break
                try:
                    conn.send(data.decode("utf-8", "replace"))
                except Exception as exc:
                    _dbg(f"pipe reader: conn.send error: {exc}")
                    break
            stop.set()
            try:
                conn.close()
            except Exception:
                pass
            _dbg("pipe reader: thread exit")

        t = threading.Thread(target=reader, daemon=True)
        t.start()
        try:
            for msg in conn:
                try:
                    m = json.loads(msg) if isinstance(msg, str) else None
                except Exception:
                    m = None
                if not m:
                    continue
                if m.get("type") == "input":
                    data = str(m.get("data", ""))
                    if _IS_WINDOWS:
                        data = data.replace("\n", "\r\n")
                    try:
                        proc.stdin.write(data.encode("utf-8"))
                        proc.stdin.flush()
                    except Exception:
                        break
                # resize is a no-op without a PTY
        except Exception:
            pass
        finally:
            stop.set()
            try:
                proc.stdin.close()
            except Exception:
                pass
            try:
                proc.terminate()
            except Exception:
                pass
            try:
                proc.wait(timeout=3)
            except Exception:
                try:
                    proc.kill()
                except Exception:
                    pass


def _find_git_bash() -> Optional[str]:
    """Locate Git for Windows' bash.exe in the usual install locations."""
    if not _IS_WINDOWS:
        return None
    candidates = []
    for base in (os.environ.get("ProgramFiles"), os.environ.get("ProgramFiles(x86)"),
                 os.environ.get("ProgramW6432"), r"C:\Program Files", r"C:\Program Files (x86)"):
        if not base:
            continue
        candidates.append(os.path.join(base, "Git", "bin", "bash.exe"))
        candidates.append(os.path.join(base, "Git", "usr", "bin", "bash.exe"))
    local = os.environ.get("LOCALAPPDATA")
    if local:
        candidates.append(os.path.join(local, "Programs", "Git", "bin", "bash.exe"))
    for c in candidates:
        try:
            if c and os.path.isfile(c):
                return c
        except Exception:
            continue
    return None


def serve_tools_shell(state) -> ToolsShellServer:
    return ToolsShellServer(state).start()
